/* =========================================================
   TEXT (neues Format: fett, Großbuchstaben, aktives Wort gelb)
   ========================================================= */
const SANS = '"Arial Black", "Helvetica Neue", Arial, system-ui, sans-serif', SERIF = SANS;
const band = document.createElement('canvas'); band.width = 8; band.height = 512;
(function(){ const x = band.getContext('2d'), g = x.createLinearGradient(0, 0, 0, 512); g.addColorStop(0, 'rgba(10,14,24,0)'); g.addColorStop(0.5, 'rgba(10,14,24,0.42)'); g.addColorStop(1, 'rgba(10,14,24,0)'); x.fillStyle = g; x.fillRect(0, 0, 8, 512); })();
function boldLines(words, cy, size, maxW, act, pop, col){
  g2.save(); g2.font = `900 ${size}px ${SANS}`; g2.textBaseline = 'middle'; g2.lineJoin = 'round';
  const spc = size * 0.28, lines = [[]]; let lw = 0;
  words.forEach((w, i) => { const wd = g2.measureText(w).width; if (lw + wd > maxW && lines[lines.length - 1].length){ lines.push([]); lw = 0; } lines[lines.length - 1].push({ w, wd, i }); lw += wd + spc; });
  const lh = size * 1.12, y0 = cy - (lines.length - 1) * lh / 2;
  lines.forEach((ln, li) => { const tw = ln.reduce((a, b) => a + b.wd, 0) + spc * (ln.length - 1); let x = W / 2 - tw / 2;
    ln.forEach(tk => { const on = tk.i === act, s = on ? 1 + 0.08 * pop : 1, y = y0 + li * lh;
      g2.save(); g2.translate(x + tk.wd / 2, y); g2.scale(s, s);
      g2.lineWidth = size * 0.2; g2.strokeStyle = '#0b1220'; g2.strokeText(tk.w, -tk.wd / 2, 0);
      g2.fillStyle = on ? '#ffd23c' : (col || '#ffffff'); g2.fillText(tk.w, -tk.wd / 2, 0); g2.restore(); x += tk.wd + spc; }); });
  g2.restore();
}
function fitSize(text, size, maxW){ g2.font = `900 ${size}px ${SANS}`; const w = g2.measureText(text).width; return w > maxW ? size * maxW / w : size; }
function drawHook(a, sc){
  if (a <= 0) return; g2.save(); g2.globalAlpha = a; g2.drawImage(band, 0, 340, W, 520);
  const s1 = fitSize('SEIL REISST', 120, 960), s2 = fitSize('SPRINGEN?', 120, 900);
  g2.translate(W / 2, 600); g2.scale(sc, sc); g2.translate(-W / 2, -600);
  boldLines(['SEIL', 'REISST'], 535, s1, 1000, -1, 0); boldLines(['SPRINGEN?'], 670, s2, 940, -1, 0, '#ffd23c');
  g2.restore();
}
function drawSubs(){
  let cur = null; for (const s of SUBS) if (T >= s.s && T < s.e) cur = s; if (!cur) return;
  let act = 0; cur.w.forEach((w, i) => { if (T >= w[1]) act = i; });
  const pop = clamp01(1 - (T - cur.w[act][1]) / 0.18), age = T - cur.s, a = E.out(clamp01(age / 0.08));
  g2.save(); g2.globalAlpha = a; g2.drawImage(band, 0, 1060, W, 400);
  const yy = 1260 + (1 - a) * 14;
  if (cur.ben){ boldLines(cur.w.map(w => w[0]), yy, 112, 880, act, pop, '#ffffff'); g2.font = `900 34px ${SANS}`; g2.textAlign = 'center'; g2.fillStyle = '#ffd23c'; g2.strokeStyle = '#0b1220'; g2.lineWidth = 8; g2.strokeText('— BEN', W / 2, yy + 100); g2.fillText('— BEN', W / 2, yy + 100); }
  else boldLines(cur.w.map(w => w[0]), yy, 78, 880, act, pop);
  g2.restore();
}
function drawHud(h){
  if (!h) return; g2.save(); g2.textAlign = 'center'; g2.textBaseline = 'middle'; g2.lineJoin = 'round';
  const big = fitSize(h[0], 140, 880); g2.font = `900 ${big}px ${SANS}`; g2.lineWidth = 24; g2.strokeStyle = '#0b1220'; g2.strokeText(h[0], W / 2, 400); g2.fillStyle = '#ffffff'; g2.fillText(h[0], W / 2, 400);
  if (h[1]){ g2.font = `900 40px ${SANS}`; g2.lineWidth = 10; g2.strokeText(h[1], W / 2, 500); g2.fillStyle = '#ffd23c'; g2.fillText(h[1], W / 2, 500); }
  g2.restore();
}
function glowDot(x, y, r, col, a){ if (a <= 0) return; const g = g2.createRadialGradient(x, y, 0, x, y, r); g.addColorStop(0, 'rgba(255,255,255,' + Math.min(1, a) + ')'); g.addColorStop(0.25, col.replace('A', Math.min(1, a) * 0.9)); g.addColorStop(1, col.replace('A', 0)); g2.fillStyle = g; g2.fillRect(x - r, y - r, 2 * r, 2 * r); }
function wp(x, y, z){ return proj(new THREE.Vector3(x, y, z)); }
function txt(s, x, y, size, col, al){ g2.font = `900 ${size}px ${SANS}`; g2.textAlign = al || 'center'; g2.textBaseline = 'middle'; g2.lineJoin = 'round'; g2.lineWidth = size * 0.22; g2.strokeStyle = '#0b1220'; g2.strokeText(s, x, y); g2.fillStyle = col; g2.fillText(s, x, y); }
const _p = new THREE.Vector3();
function wl(o, x, y, z){ o.updateWorldMatrix(true, false); return proj(o.localToWorld(_p.set(x, y, z))); }
function along(P, f){ let L = 0; const sg = []; for (let i = 1; i < P.length; i++){ const q = Math.hypot(P[i][0] - P[i - 1][0], P[i][1] - P[i - 1][1]); sg.push(q); L += q; } let r = f * L;
  for (let i = 0; i < sg.length; i++){ if (r <= sg[i]){ const k = r / sg[i]; return [lerp(P[i][0], P[i + 1][0], k), lerp(P[i][1], P[i + 1][1], k)]; } r -= sg[i]; } return P[P.length - 1]; }
function path(P){ g2.beginPath(); g2.moveTo(P[0][0], P[0][1]); for (let i = 1; i < P.length; i++) g2.lineTo(P[i][0], P[i][1]); }
function star(x, y, r){ g2.beginPath(); for (let k = 0; k < 3; k++){ const a = k * PI / 3; g2.moveTo(x - Math.cos(a) * r, y - Math.sin(a) * r); g2.lineTo(x + Math.cos(a) * r, y + Math.sin(a) * r); } g2.stroke(); }
function flame(x, y, s, a){ g2.save(); g2.globalAlpha = a; g2.translate(x, y); const w = 1 + 0.08 * Math.sin(T * 14);
  g2.beginPath(); g2.moveTo(0, -1.1 * s * w); g2.bezierCurveTo(0.7 * s, -0.4 * s, 0.6 * s, 0.5 * s, 0, 0.55 * s); g2.bezierCurveTo(-0.6 * s, 0.5 * s, -0.7 * s, -0.4 * s, 0, -1.1 * s * w); g2.fillStyle = '#ff5a1f'; g2.fill();
  g2.beginPath(); g2.moveTo(0, -0.5 * s * w); g2.bezierCurveTo(0.35 * s, -0.1 * s, 0.3 * s, 0.4 * s, 0, 0.45 * s); g2.bezierCurveTo(-0.3 * s, 0.4 * s, -0.35 * s, -0.1 * s, 0, -0.5 * s * w); g2.fillStyle = '#ffd23c'; g2.fill(); g2.restore(); }

function arrow(x, y0, y1, w, col, lbl, lbl2){ const dir = Math.sign(y1 - y0), hd = Math.min(Math.abs(y1 - y0) * 0.5, w * 1.6);
  g2.beginPath(); g2.moveTo(x - w / 2, y0); g2.lineTo(x + w / 2, y0); g2.lineTo(x + w / 2, y1 - dir * hd); g2.lineTo(x + w * 1.1, y1 - dir * hd); g2.lineTo(x, y1); g2.lineTo(x - w * 1.1, y1 - dir * hd); g2.lineTo(x - w / 2, y1 - dir * hd); g2.closePath();
  g2.lineWidth = 12; g2.strokeStyle = '#0b1220'; g2.lineJoin = 'round'; g2.stroke(); g2.fillStyle = col; g2.fill(); }
function chip(x, y, w, h){ g2.fillStyle = 'rgba(11,18,32,0.62)'; g2.beginPath(); g2.roundRect(x - w / 2, y - h / 2, w, h, 26); g2.fill(); }
const kmh = t => Math.round(70 * E.out(seg(t, 1.45, 4.2)));
function drawSpd(a){ if (a <= 0) return; g2.save(); g2.globalAlpha = a; chip(W - 175, 660, 270, 150); txt(kmh(T) + ' KM/H', W - 175, 640, 52, '#ff6a4a'); txt('ZEITLUPE', W - 175, 700, 28, '#ffd23c'); g2.restore(); }
function drawSame(a){ if (a <= 0) return; g2.save(); g2.globalAlpha = a; const L = 300 * E.out(a);
  [[175, 'KABINE'], [W - 175, 'BEN']].forEach(([x, l]) => { chip(x, 900, 250, 470); arrow(x, 720, 720 + L, 60, '#ff6a4a'); txt(l, x, 1090, 44, '#ffffff'); });
  txt('=', W / 2, 760, 120, '#ffd23c'); g2.restore(); }
function drawJump(a){ if (a <= 0) return; g2.save(); g2.globalAlpha = a; const k = E.out(seg(T, 7.4, 7.8)), r = seg(T, 8.4, 8.7);
  chip(190, 900, 300, 500); arrow(190, 690, 690 + 320 * k, 64, '#ff6a4a'); txt('FALL', 190, 1065, 40, '#ffffff'); txt('70 KM/H', 190, 1115, 40, '#ff6a4a');
  chip(W - 190, 900, 300, 500); if (k > 0.3){ arrow(W - 190, 950, 950 - 70 * E.out(seg(T, 7.7, 8.0)), 64, '#3bd16f'); } txt('SPRUNG', W - 190, 1065, 40, '#ffffff'); txt('3 KM/H', W - 190, 1115, 40, '#3bd16f');
  if (r > 0){ g2.globalAlpha = a * r; chip(W / 2, 640, 520, 120); txt('= 67 KM/H', W / 2, 640, 64, '#ffd23c'); } g2.restore(); }
const _hp = new THREE.Vector3();
function drawStars(a){ if (a <= 0) return; ben.head.updateWorldMatrix(true, false); const p = proj(ben.head.localToWorld(_hp.set(0, 1.25, 0))); if (!p) return; g2.save(); g2.globalAlpha = a; g2.lineCap = 'round';
  for (let i = 0; i < 5; i++){ const an = T * 3 + i * 2 * PI / 5, x = p[0] + Math.cos(an) * 170, y = p[1] - 20 + Math.sin(an) * 50; g2.lineWidth = 14; g2.strokeStyle = '#0b1220'; star(x, y, 26); g2.lineWidth = 7; g2.strokeStyle = '#ffd23c'; star(x, y, 26); }
  txt('BONK!', p[0], p[1] - 130, 70, '#ffffff'); g2.restore(); }
function drawCount(a){ if (a <= 0) return; const p = wp(0, 9.6, 0); if (!p) return; const n = 6 - [12.3, 12.75, 13.2, 13.65, 14.1].filter(x => T >= x).length;
  g2.save(); g2.globalAlpha = a; chip(p[0], p[1], 470, 110); txt(n === 1 ? '1 SEIL HÄLT!' : n + ' SEILE', p[0], p[1], 58, n === 1 ? '#3bd16f' : '#ffffff'); g2.restore(); }
function drawSnap(ts, s){ ts.forEach((t0, i) => { const u = T - t0; if (u < 0 || u > 0.45) return; const p = wp(CX[i], 7.0 + s, 0); if (!p) return; glowDot(p[0], p[1], 90, 'rgba(255,220,140,A)', 0.85 * (u < 0.06 ? u / 0.06 : 1 - (u - 0.06) / 0.39)); }); }
function drawSparks(a){ if (a <= 0) return; [-1, 1].forEach(k => { const p = wp(3.08, 0.2, k * 0.2); if (!p) return;
  for (let i = 0; i < 5; i++){ const ph = (T * 1.6 + i / 5) % 1, x = p[0] + k * 30 + (i - 2) * 22 * ph, y = p[1] + 160 * ph * ph - 20 * ph; glowDot(x, y, 34, 'rgba(255,190,80,A)', a * 0.8 * Math.sin(PI * ph)); } }); }
function drawGauge(a){ if (a <= 0) return; const cx = W / 2, cy = 960, R = 250, v = 100 * E.io(seg(T, 17.4, 18.1)) + 15 * E.io(seg(T, 18.4, 19.0)), ang = q => PI + PI * q / 130;
  g2.save(); g2.globalAlpha = a; chip(cx, cy - 70, 640, 400); g2.lineCap = 'butt';
  g2.lineWidth = 34; g2.beginPath(); g2.arc(cx, cy, R, ang(0), ang(100)); g2.strokeStyle = '#3bd16f'; g2.stroke(); g2.beginPath(); g2.arc(cx, cy, R, ang(100), ang(115)); g2.strokeStyle = '#ffd23c'; g2.stroke(); g2.beginPath(); g2.arc(cx, cy, R, ang(115), ang(130)); g2.strokeStyle = '#ff4a3a'; g2.stroke();
  const m = ang(115); g2.lineWidth = 8; g2.strokeStyle = '#ffffff'; g2.beginPath(); g2.moveTo(cx + Math.cos(m) * (R - 40), cy + Math.sin(m) * (R - 40)); g2.lineTo(cx + Math.cos(m) * (R + 40), cy + Math.sin(m) * (R + 40)); g2.stroke();
  txt('115 %', cx + Math.cos(m) * (R + 30) + 40, cy + Math.sin(m) * (R + 30) - 34, 36, '#ff4a3a');
  const n = ang(v); g2.lineCap = 'round'; g2.lineWidth = 18; g2.strokeStyle = '#0b1220'; g2.beginPath(); g2.moveTo(cx, cy); g2.lineTo(cx + Math.cos(n) * (R - 30), cy + Math.sin(n) * (R - 30)); g2.stroke();
  g2.lineWidth = 10; g2.strokeStyle = '#ffffff'; g2.stroke(); g2.beginPath(); g2.arc(cx, cy, 20, 0, 7); g2.fillStyle = '#ffffff'; g2.fill();
  txt(Math.round(v) + ' %', cx, cy - 90, 60, v >= 114.5 ? '#ff4a3a' : '#ffffff'); txt(v >= 114.5 ? 'BREMSE!' : 'NORMALES TEMPO = 100 %', cx, cy + 50, v >= 114.5 ? 46 : 30, v >= 114.5 ? '#ffd23c' : '#9fd8ff'); g2.restore(); }
function drawSpread(a){ if (a <= 0) return; g2.save(); g2.globalAlpha = a; const L = 90 * E.out(seg(T, 21.98, 22.3));
  for (let i = 0; i < 7; i++){ const z = lerp(1.45, -1.55, i / 6), p = wp(0, 0.0, z); if (!p) continue; arrow(p[0] + (i % 2 ? 150 : -150) * 0 , p[1] + 70, p[1] + 70 - L, 26, '#ffd23c'); }
  const p = wp(0, 0.0, 2.1); if (p) txt('STOSS ÜBERALL GLEICH', p[0], p[1] + 140, 44, '#ffd23c'); g2.restore(); }

function heart(x, y, s){ g2.beginPath(); g2.moveTo(x, y + 0.35 * s); g2.bezierCurveTo(x - 1.1 * s, y - 0.35 * s, x - 0.45 * s, y - 1.0 * s, x, y - 0.45 * s); g2.bezierCurveTo(x + 0.45 * s, y - 1.0 * s, x + 1.1 * s, y - 0.35 * s, x, y + 0.35 * s); g2.closePath(); }
function drawHeart(a){ if (a <= 0) return; const ph = (T * 2.5) % 1, beat = ph < 0.15 ? Math.sin(ph / 0.15 * PI) : 0, s = 70 * (1 + 0.22 * beat);
  g2.save(); g2.globalAlpha = a; heart(W / 2, 660, s); g2.fillStyle = '#ff3b3b'; g2.fill(); g2.lineWidth = 10; g2.strokeStyle = '#0b1220'; g2.stroke(); g2.restore(); }
const vig = document.createElement('canvas'); vig.width = 270; vig.height = 480;
(function(){ const x = vig.getContext('2d'), g = x.createRadialGradient(135, 240, 120, 135, 240, 330); g.addColorStop(0, 'rgba(0,0,0,0)'); g.addColorStop(1, 'rgba(0,0,0,0.38)'); x.fillStyle = g; x.fillRect(0, 0, 270, 480); })();
function draw2D(sc, lt, dur){
  g2.globalAlpha = 1; g2.globalCompositeOperation = 'source-over'; g2.drawImage(renderer.domElement, 0, 0, W, H);
  g2.globalAlpha = 1; g2.globalCompositeOperation = 'source-over'; g2.drawImage(vig, 0, 0, W, H);
  if (flashA > 0){ g2.fillStyle = `rgba(255,250,240,${Math.min(1, flashA)})`; g2.fillRect(0, 0, W, H); }
  if (fadeBlk > 0){ g2.fillStyle = `rgba(0,0,0,${fadeBlk})`; g2.fillRect(0, 0, W, H); }
  drawSnap(SNAPS(), 0); drawSparks(sparkK); drawSame(sameK); drawJump(jumpK); drawStars(starK); drawCount(cntK); drawGauge(gaugeK); drawSpread(spreadK); if (!sc.hook) drawSpd(spdK);
  if (sc.hud) drawHud(sc.hud());
  if (sc.hook) drawHook(clamp01((dur - lt) / 0.15), 1);
  if (sc.loopin){ const k = clamp01((T - (END - 0.14)) / 0.14); drawHook(k, 1 + 0.25 * (1 - k)); }
  if (!sc.hook) drawSubs();
}
