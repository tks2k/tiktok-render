/* =========================================================
   STIMMUNG (Aufzugschacht, Schnittmodell)
   ========================================================= */
function sky(stops){
  const c = document.createElement('canvas'); c.width = 4; c.height = 256; const x = c.getContext('2d'), g = x.createLinearGradient(0, 0, 0, 256);
  stops.forEach(s => g.addColorStop(s[0], s[1])); x.fillStyle = g; x.fillRect(0, 0, 4, 256); const t = new THREE.CanvasTexture(c); t.encoding = THREE.sRGBEncoding; return t;
}
const MOOD = { shaft: { sky: sky([[0, '#2b3140'], [1, '#1a1e28']]), fog: [0x222733, 40, 140], hemi: [0xf4f1ea, 0x5a5a62, 1.0], sun: [0xfff4e0, 1.05], env: 1 } };
const SR = 9; { const c = sun.shadow.camera; c.left = -SR; c.right = SR; c.top = SR; c.bottom = -SR; c.near = 1; c.far = 80; c.updateProjectionMatrix(); }
sun.target.position.set(0, 2, 0); sun.position.set(0, 20, 16);
function setMood(m){
  scene.background = m.sky; scene.fog.color.set(m.fog[0]); scene.fog.near = m.fog[1]; scene.fog.far = m.fog[2]; scene.environment = m.env ? envDay : envNight;
  hemi.color.set(m.hemi[0]); hemi.groundColor.set(m.hemi[1]); hemi.intensity = m.hemi[2]; sun.color.set(m.sun[0]); sun.intensity = m.sun[1];
  fill.color.set(0xffffff); fill.intensity = 0.4; fill.position.set(-20, 10, 30);
}

/* =========================================================
   SET: Kabine fest im Ursprung, Schacht scrollt (Fall = Schacht fährt hoch)
   ========================================================= */
const world = new THREE.Group(); scene.add(world);
const CAB = new THREE.Group(); world.add(CAB);
const SHAFT = new THREE.Group(); world.add(SHAFT);   // statisch: Wände, Schienen
const SCR = new THREE.Group(); world.add(SCR);       // wiederholt alle 6 Einheiten
const LND = new THREE.Group(); world.add(LND);       // Etage (Flur) bei s = 0
const BTN = new THREE.Vector3(2.47, 1.95, 0.55);
const BL = [], BR = [];   // Fangbremsen-Backen (links / rechts), je [vorn, hinten]
let btnM = null;
(function(){
  const wall = mat(0xd9ccb2, { roughness: 0.7 }), steel = mat(0xb9bec6, { roughness: 0.35, metalness: 0.5, envMapIntensity: 1 }), dark = mat(0x2a2d33, { roughness: 0.5 });
  // Kabine
  P(CAB, rbox(5.3, 0.3, 4.1, 0.04, 1), mat(0x6f747c, { roughness: 0.8 }), 0, -0.15, 0);
  P(CAB, rbox(5.3, 0.22, 4.1, 0.04, 1), steel, 0, 4.71, 0);
  const lp = new THREE.Mesh(new THREE.BoxGeometry(3.0, 0.04, 2.0), new THREE.MeshStandardMaterial({ color: 0xfff6e0, emissive: 0xfff2d6, emissiveIntensity: 0.7 })); lp.position.set(0, 4.58, 0); CAB.add(lp);
  [-1, 1].forEach(s => P(CAB, rbox(0.12, 4.6, 4.1, 0.03, 1), wall, s * 2.59, 2.3, 0));
  P(CAB, rbox(5.3, 4.6, 0.12, 0.03, 1), wall, 0, 2.3, -1.99);
  P(CAB, rbox(4.2, 0.09, 0.09, 0.03, 1), steel, 0, 1.6, -1.84);
  [-1, 1].forEach(s => P(CAB, rbox(0.14, 4.6, 0.14, 0.04, 1), steel, s * 2.6, 2.3, 2.02));
  P(CAB, rbox(5.34, 0.14, 0.14, 0.04, 1), steel, 0, 0.0, 2.02);
  // Bedienfeld rechts innen
  P(CAB, rbox(0.04, 1.3, 0.5, 0.01, 1), dark, 2.52, 1.9, 0.55);
  [1.5, 1.75, 2.2].forEach(y => P(CAB, rbox(0.04, 0.13, 0.13, 0.02, 1), mat(0xdfe3e8, { roughness: 0.4 }), 2.49, y, 0.55));
  btnM = new THREE.MeshStandardMaterial({ color: 0xe8e2c8, emissive: 0xffc83a, emissiveIntensity: 0, roughness: 0.4 });
  P(CAB, rbox(0.04, 0.13, 0.13, 0.02, 1), btnM, 2.49, 1.95, 0.55);
  // Dach: Querträger + Seilaufhängung
  P(CAB, rbox(5.6, 0.3, 0.5, 0.05, 1), mat(0x4a4f58, { roughness: 0.5, metalness: 0.3 }), 0, 4.97, 0);
  P(CAB, rbox(1.9, 0.18, 0.5, 0.04, 1), mat(0x4a4f58, { roughness: 0.5, metalness: 0.3 }), 0, 5.2, 0);
  // Fangvorrichtung unten an beiden Seiten
  const hous = mat(0xc8362c, { roughness: 0.5 }), jaw = mat(0x3a3d44, { roughness: 0.4, metalness: 0.4 });
  [-1, 1].forEach(s => { P(CAB, rbox(0.32, 0.5, 0.8, 0.04, 1), hous, s * 2.8, 0.2, 0);
    const A = s < 0 ? BL : BR; [-1, 1].forEach(k => { const j = P(CAB, rbox(0.26, 0.34, 0.12, 0.02, 1), jaw, s * 3.07, 0.2, k * 0.25); j.userData.k = k; A.push(j); }); });
  // Schacht: Rückwand, Seitenwände (vorne aufgeschnitten), Führungsschienen
  const conc = mat(0x666a72, { roughness: 0.95 });
  P(SHAFT, new THREE.BoxGeometry(8.4, 220, 0.4), conc, 0, 0, -2.8);
  [-1, 1].forEach(s => { P(SHAFT, new THREE.BoxGeometry(0.4, 220, 2.6), conc, s * 3.85, 0, -1.6);
    P(SHAFT, new THREE.BoxGeometry(0.34, 220, 0.09), mat(0x8e949c, { roughness: 0.4, metalness: 0.5 }), s * 3.09, 0, 0);
    P(SHAFT, new THREE.BoxGeometry(0.08, 220, 0.42), mat(0x8e949c, { roughness: 0.4, metalness: 0.5 }), s * 3.28, 0, 0); });
  // wiederholte Geschossdecken-Kanten + Schienenhalter
  const slab = mat(0x8c9097, { roughness: 0.9 }), band = mat(0xd9a628, { roughness: 0.6 });
  for (let k = -5; k <= 5; k++){ const y = k * 6;
    P(SCR, new THREE.BoxGeometry(8.4, 0.45, 0.3), slab, 0, y, -2.48); P(SCR, new THREE.BoxGeometry(8.4, 0.1, 0.02), band, 0, y + 0.18, -2.32);
    [-1, 1].forEach(s => { P(SCR, new THREE.BoxGeometry(0.3, 0.45, 2.6), slab, s * 3.52, y, -1.6); P(SCR, new THREE.BoxGeometry(0.3, 0.22, 0.5), mat(0x3a3d44), s * 3.45, y + 1.5, 0); }); }
  // Flur (Etage): Boden-Kante, Wandstücke mit Türöffnung, Ruftaster
  const fl = mat(0xa8957a, { roughness: 0.85 }), hw = mat(0xe4ddd0, { roughness: 0.8 });
  P(LND, new THREE.BoxGeometry(8, 0.5, 4.2), fl, 0, -0.25, 4.4);
  [-1, 1].forEach(s => P(LND, new THREE.BoxGeometry(9, 5.1, 0.3), hw, s * 7.1, 2.55, 2.45));
  P(LND, new THREE.BoxGeometry(5.2, 0.5, 0.3), hw, 0, 4.85, 2.45);
  [-1, 1].forEach(s => P(LND, rbox(0.16, 4.7, 0.36, 0.03, 1), steel, s * 2.68, 2.35, 2.45));
  P(LND, rbox(0.36, 0.6, 0.06, 0.03, 1), steel, 3.4, 1.9, 2.62); P(LND, rbox(0.14, 0.14, 0.06, 0.04, 1), mat(0xdfe3e8), 3.4, 1.9, 2.66);
})();
// 6 Tragseile: Stummel (an der Kabine, kippt nach dem Riss) + oberes Stück (gehört zum Schacht)
const CX = [-0.75, -0.45, -0.15, 0.15, 0.45, 0.75], CBL = [], CUP = [];
(function(){ const cm = mat(0x5c6068, { roughness: 0.45, metalness: 0.6 });
  CX.forEach(x => { const g = new THREE.Group(); g.position.set(x, 5.3, 0); CAB.add(g); P(g, new THREE.CylinderGeometry(0.05, 0.05, 1.7, 8), cm, 0, 0.85, 0); CBL.push(g);
    const u = P(world, new THREE.CylinderGeometry(0.05, 0.05, 60, 8), cm, x, 37, 0); CUP.push(u); }); })();
const SETS = [world];

/* =========================================================
   FIGUREN
   ========================================================= */
const SCAR = new THREE.Group(); ben.head.add(SCAR);
(function(){ const m = mat(0xa8463f, { roughness: 0.7 }); const s = new THREE.Mesh(rbox(0.075, 0.72, 0.03, 0.012, 1), m); s.position.set(0.25, 0.55, 0.522); s.rotation.z = -0.13; SCAR.add(s);
  for (const y of [0.36, 0.55, 0.74]){ const c = new THREE.Mesh(rbox(0.16, 0.035, 0.03, 0.01, 1), m); c.position.set(0.25 + (y - 0.55) * 0.13, y, 0.528); c.rotation.z = -0.13; SCAR.add(c); } })();
const pro = boxer({ top: 0x3cae6a, pants: 0x1f2a44, shoe: 0x1c1c22, hair: 0x8a5a2a, skin: 0xf2c6a2 }); ALL.push(pro); scene.add(pro.root);
[ben, pro].forEach(r => { r.L1 = 0.46; r.L2 = 0.56; });
const _ia = new THREE.Vector3(), _ib = new THREE.Vector3(), _ic = new THREE.Vector3(), _id = new THREE.Vector3(), _ie = new THREE.Vector3(), _if = new THREE.Vector3(), _ig = new THREE.Vector3(), _ih = new THREE.Vector3();
const _iq = new THREE.Quaternion(), _qa = new THREE.Quaternion(), _qb = new THREE.Quaternion(), _dn = new THREE.Vector3(0, -1, 0);
function ik(r, i, tw, pw){
  r.torso.updateWorldMatrix(true, false);
  const tl = r.torso.worldToLocal(_ia.copy(tw)); r.torso.getWorldQuaternion(_iq); const pl = _ib.copy(pw).applyQuaternion(_iq.invert());
  const S = _ic.set(i ? 0.67 : -0.67, 0.92, 0), D = _id.subVectors(tl, S), L1 = r.L1, L2 = r.L2;
  const d = Math.min(Math.max(D.length(), 0.15), L1 + L2 - 0.002); D.normalize();
  const a = Math.acos(Math.max(-1, Math.min(1, (L1 * L1 + d * d - L2 * L2) / (2 * L1 * d))));
  const n = _ie.crossVectors(D, pl).normalize(), e = _if.copy(D).applyAxisAngle(n, a);
  _qa.setFromUnitVectors(_dn, e); r.sh[i].quaternion.copy(_qa);
  const f = _ih.subVectors(tl, _ig.copy(S).addScaledVector(e, L1)).normalize().applyQuaternion(_qb.copy(_qa).invert());
  r.el[i].quaternion.setFromUnitVectors(_dn, f);
}
const POLE = new THREE.Vector3(0.2, -1, 0.6), BX = 0.4, BZ = 0.4, PX = 1.05, PZ = 0.45;
// Taster drücken (Haltung wie im ersten Bild)
function pressPose(k){ place(ben, PX, 0, PZ, 0.9); bRest(ben, T, 0); ik(ben, 1, _ih.copy(BTN).add(new THREE.Vector3(-0.1, 0, 0)), POLE); }
// Schweben: Arme raus, Beine locker
function floatPose(fy, w){ ben.root.position.y = fy; ben.sh[0].rotation.set(-0.2 + 0.15 * Math.sin(T * 2.1), 0, -1.15 - 0.1 * Math.sin(T * 1.7)); ben.sh[1].rotation.set(-0.2 + 0.15 * Math.cos(T * 2.0), 0, 1.15 + 0.1 * Math.sin(T * 1.9));
  ben.el[0].rotation.set(-0.4, 0, 0); ben.el[1].rotation.set(-0.4, 0, 0); ben.legs[0].rotation.set(0.2 * w + 0.08 * Math.sin(T * 1.6), 0, -0.1); ben.legs[1].rotation.set(-0.15 * w + 0.08 * Math.cos(T * 1.5), 0, 0.1); }

/* =========================================================
   KAMERA + Zustand
   ========================================================= */
const cL = new THREE.Vector3();
let blurAmt = 0, fadeBlk = 0, T = 0, flashA = 0, eyeS = 1, talk = 0, dT = 0;
let sameK = 0, jumpK = 0, starK = 0, cntK = 0, sparkK = 0, gaugeK = 0, spreadK = 0, spdK = 0, SCROLL = 0;
function camW(p, a, b){ cam.position.set(lerp(a[0], b[0], p), lerp(a[1], b[1], p), lerp(a[2], b[2], p)); cL.set(lerp(a[3], b[3], p), lerp(a[4], b[4], p), lerp(a[5], b[5], p)); cam.fov = lerp(a[6], b[6], p); }
function camFin(sh){ cam.position.x += Math.sin(dT * 0.7) * 0.012; cam.position.y += Math.sin(dT * 0.9 + 1) * 0.008; if (sh){ cam.position.x += Math.sin(T * 23) * sh; cam.position.y += Math.cos(T * 17) * sh; } cam.up.set(0, 1, 0); cam.lookAt(cL); cam.updateProjectionMatrix(); cam.updateMatrixWorld(); }
const imp = at => T >= at ? Math.exp(-(T - at) * 3) : 0;
// Fallweg s(t) = Integral der Geschwindigkeit (Tabelle)
function mkS(v, t0, t1){ const dt = 1 / 240, n = Math.ceil((t1 - t0) / dt) + 1, a = new Float32Array(n); for (let i = 1; i < n; i++) a[i] = a[i - 1] + v(t0 + (i - 0.5) * dt) * dt;
  return t => { const x = (t - t0) / dt; if (x <= 0) return 0; if (x >= n - 1) return a[n - 1]; const i = Math.floor(x); return lerp(a[i], a[i + 1], x - i); }; }
const S1 = mkS(t => 12 * E.io(seg(t, 1.45, 3.0)), 0, 12);
const S5 = mkS(t => 10 * seg(t, 15.35, 16.3) * (1 - E.out(seg(t, 16.44, 17.0))), 15, 18);
const S7 = mkS(t => t < 21.98 ? 9 : 0, 20, 24);
function setScroll(s){ SCROLL = s; SCR.position.y = ((s % 6) + 6) % 6; LND.position.y = s; LND.visible = s < 30; CUP.forEach((u, i) => u.userData.s = s); }
// Seile: Rissmoment je Seil
let SNAPT = [99, 99, 99, 99, 99, 99]; const SNAPS = () => SNAPT;
function cables(ts){ SNAPT = ts; CBL.forEach((g, i) => { const u = T - ts[i], side = CX[i] < 0 ? 1 : -1;
    g.rotation.z = u > 0 ? side * (1.25 + 0.1 * i / 5) * E.out(Math.min(1, u / 0.6)) : 0;
    CUP[i].position.y = 37 + SCROLL + (u > 0 ? 3 * Math.min(u, 1.5) : 0); }); }
const NONE = [99, 99, 99, 99, 99, 99], ALLSNAP = [1.45, 1.45, 1.45, 1.45, 1.45, 1.45], S4SNAP = [12.3, 12.75, 13.2, 13.65, 14.1, 15.35];
function brake(k){ [BL, BR].forEach((A, s) => A.forEach(j => { j.position.z = j.userData.k * lerp(0.25, 0.115, k); })); }
const HOOK = [[0, 2.4, 13.0, 0.4, 2.2, 0, 40], [0.2, 2.5, 12.2, 0.4, 2.3, 0, 40]];
// Ben im Fall (Hook bis Szene 3): schweben, abstoßen, Decke
function fyFall(t){ if (t < 6.3) return 0.12 * E.io(seg(t, 1.6, 2.6)) + 0.03 * Math.sin(t * 2.3) * seg(t, 1.6, 2.6);
  if (t < 6.6) return 0.12 * (1 - E.io(seg(t, 6.3, 6.5)));
  if (t < 10.95) return Math.min(1.31, 0.274 * (t - 6.6) * Math.min(1, (t - 6.6) / 0.15 + 0.4));
  return 1.31 - 0.12 * (t - 10.95); }
function base(){ show(ben); CAB.position.y = 0; brake(0); btnM.emissiveIntensity = 0; pro.root.visible = false; }
function hookPose(t){ base(); setScroll(0); cables(NONE); pressPose(1); btnM.emissiveIntensity = 1; eyeS = 1; bFace(ben, 0.2, 0.15); ben.head.rotation.y = -0.6; }
function fallBen(t){ const tw = E.io(seg(t, 0.4, 1.0)), st = E.io(seg(t, 0.5, 1.2));
  bRest(ben, T, 0); place(ben, lerp(PX, BX, st), 0, lerp(PZ, BZ, st), lerp(0.9, 0.12, tw));
  if (t < 0.7){ const k = 1 - E.io(seg(t, 0.3, 0.7)); if (k > 0.001) ik(ben, 1, _ih.copy(BTN).add(new THREE.Vector3(-0.1 - 0.6 * (1 - k), -0.8 * (1 - k), 0)), POLE); }
  if (t > 0.5 && t < 1.25) wlk(ben, (t - 0.5) * 9, 0.5 * Math.sin(PI * seg(t, 0.5, 1.25)));
  ben.head.rotation.y = lerp(-0.6, 0, tw);
  const fl = seg(t, 1.5, 1.9);
  if (fl > 0){ floatPose(fyFall(t), fl); ben.head.rotation.x = -0.15; }
  btnM.emissiveIntensity = 1 - seg(t, 1.45, 1.6); }

/* =========================================================
   SZENEN (gekürzte Sprecherspur, Tempo 1,32)
   ========================================================= */
const SCN = [
  { t: 0, set: world, mood: MOOD.shaft, hook: 1,
    upd(lt){ dT = T; base(); setScroll(S1(T)); cables(ALLSNAP); fallBen(T); btnM.emissiveIntensity = T < 1.45 ? 1 : 0;
      eyeS = T < 1.45 ? 1 : 1.45; if (T < 1.45) bFace(ben, 0.2, 0.15); else bFace(ben, -0.8, 0.9 * E.out(seg(T, 1.45, 1.7)));
      camW(E.io(seg(lt, 0, 3.75)), HOOK[0], HOOK[1]); camFin(0.03 * imp(1.47)); } },
  { t: 3.75, set: world, mood: MOOD.shaft, hud: () => ['SCHWERELOS', 'KABINE + BEN FALLEN GLEICH'],
    upd(lt){ dT = T; base(); setScroll(S1(T)); cables(ALLSNAP); fallBen(T); eyeS = 1.45; bFace(ben, -0.8, 0.8);
      sameK = E.out(seg(T, 4.7, 5.0)) * (1 - seg(T, 6.05, 6.25)); spdK = 1;
      camW(E.io(seg(lt, 0, 2.5)), [3.6, 3.2, 14.6, 0.3, 2.2, 0, 40], [5.4, 4.4, 15.4, 0.2, 2.0, 0, 40]); camFin(); } },
  { t: 6.25, set: world, mood: MOOD.shaft, hud: () => ['SPRINGEN?', 'BRINGT FAST NICHTS'],
    upd(lt){ dT = T; base(); setScroll(S1(T)); cables(ALLSNAP); fallBen(T); eyeS = 1.3;
      const c = bump(T, 6.25, 6.6); ben.sh[0].rotation.x += 0.9 * c; ben.sh[1].rotation.x += 0.9 * c; ben.legs[0].rotation.x -= 0.5 * c; ben.legs[1].rotation.x += 0.3 * c; ben.torso.rotation.x = 0.25 * c;
      bFace(ben, T < 6.6 ? 0.6 : -0.5, T < 6.6 ? 0.1 : 0.5); jumpK = E.out(seg(T, 7.3, 7.6)) * (1 - seg(T, 9.25, 9.45)); spdK = 1;
      camW(E.io(seg(lt, 0, 3.2)), [3.2, 1.6, 11.6, 0.4, 1.8, 0, 40], [2.6, 2.0, 10.8, 0.4, 2.1, 0, 40]); camFin(); } },
  { t: 9.45, set: world, mood: MOOD.shaft, hud: () => ['AUTSCH!', 'SCHWERELOS = AB AN DIE DECKE'],
    upd(lt){ dT = T; base(); setScroll(S1(T)); cables(ALLSNAP); fallBen(T); const b = imp(10.95);
      ben.sh[0].rotation.set(-2.6, 0, -0.3); ben.sh[1].rotation.set(-2.6, 0, 0.3); ben.head.rotation.x = -0.25 + 0.35 * b * Math.sin((T - 10.95) * 18);
      eyeS = T < 10.95 ? 1.4 : 0.15; bFace(ben, T < 10.95 ? -0.7 : 0.9, T < 10.95 ? 0.6 : 0.3); starK = E.out(seg(T, 10.95, 11.1)) * (1 - seg(T, 11.5, 11.65)); spdK = 1;
      camW(E.io(seg(lt, 0, 2.2)), [2.4, 3.3, 10.2, 0.4, 3.4, 0, 40], [2.0, 3.7, 9.4, 0.4, 3.7, 0, 40]); camFin(0.02 * b); } },
  { t: 11.65, set: world, mood: MOOD.shaft, hud: () => T < 13.5 ? ['MEHRERE SEILE', '6 STAHLSEILE TRAGEN'] : ['1 SEIL REICHT', 'JEDES HÄLT DIE VOLLE KABINE'],
    upd(lt){ dT = T; base(); setScroll(0); cables(S4SNAP); bRest(ben, T, 0); place(ben, BX, 0, BZ, 0.1); ben.head.rotation.x = -0.35; eyeS = 1; bFace(ben, 0.3, 0.1);
      cntK = E.out(seg(T, 11.9, 12.2)) * (1 - seg(T, 14.9, 15.1)); let jo = 0; S4SNAP.slice(0, 5).forEach(a => jo += 0.025 * imp(a) * Math.sin((T - a) * 20));
      CAB.position.y = jo; camW(E.io(seg(lt, 0, 3.45)), [6.6, 10.4, 15.6, 0, 5.8, 0, 38], [5.4, 9.6, 14.0, 0, 6.2, 0, 38]); camFin(); } },
  { t: 15.1, set: world, mood: MOOD.shaft, hud: () => T < 16.4 ? ['ALLE REISSEN?', 'DANN …'] : ['FANGBREMSE!', 'KEILE KRALLEN SICH IN DIE SCHIENE'],
    upd(lt){ dT = T; base(); setScroll(S5(T)); cables(S4SNAP); bRest(ben, T, 0); place(ben, BX, 0, BZ, 0.1);
      const fl = seg(T, 15.4, 15.8) * (1 - E.out(seg(T, 16.44, 16.7))); ben.root.position.y = 0.08 * fl; eyeS = 1.4; bFace(ben, -0.7, 0.7);
      const bk = E.out(seg(T, 16.44, 16.6)); brake(bk); sparkK = bk * (1 - seg(T, 16.95, 17.3));
      camW(E.io(seg(lt, 0, 1.15)), [5.4, 9.6, 14.0, 0, 6.2, 0, 38], [4.7, 2.5, 3.4, 3.0, 0.25, 0, 38]); camFin(0.03 * imp(16.44)); } },
  { t: 17.15, set: world, mood: MOOD.shaft, hud: () => ['AB +15 % TEMPO', 'GREIFT DIE FANGBREMSE'],
    upd(lt){ dT = T; base(); setScroll(S5(T)); cables(S4SNAP); bRest(ben, T, 0); place(ben, BX, 0, BZ, 0.1); brake(1); eyeS = 1; bFace(ben, 0.2, 0.1);
      sparkK = 1 - seg(T, 16.95, 17.3); gaugeK = E.out(seg(T, 17.25, 17.55)) * (1 - seg(T, 19.85, 20.05));
      camW(E.io(seg(lt, 0, 2.95)), [4.7, 2.5, 3.4, 3.0, 0.25, 0, 38], [5.3, 3.0, 4.4, 3.0, 0.3, 0, 38]); camFin(); } },
  { t: 20.1, set: world, mood: MOOD.shaft, hud: () => ['PROFI', 'FLACH AUF DEN BODEN LEGEN'],
    upd(lt){ dT = T; base(); ben.root.visible = false; pro.root.visible = true; setScroll(40 + S7(T)); cables(ALLSNAP);
      bRest(pro, T, 2); const hit = imp(21.98), fly = T < 21.98 ? 0.12 + 0.02 * Math.sin(T * 2.4) : 0.02 * Math.max(0, Math.sin((T - 21.98) * 14)) * hit;
      pro.root.position.set(0, 0.29 + fly, 1.6); pro.root.rotation.set(-PI / 2, 0, 0); pro.sh[0].rotation.set(0, 0, -0.35); pro.sh[1].rotation.set(0, 0, 0.35); bFace(pro, 0.3, 0.05);
      spreadK = E.out(seg(T, 21.98, 22.2)) * (1 - seg(T, 23.45, 23.65));
      camW(E.io(seg(lt, 0, 3.6)), [0.6, 8.2, 11.0, 0, 0.4, -0.1, 42], [0.2, 7.6, 10.2, 0, 0.5, -0.1, 42]); camFin(0.04 * hit); } },
  { t: 23.7, set: world, mood: MOOD.shaft, hud: () => ['UND BEN?', 'NÄCHSTE FAHRT'],
    upd(lt){ dT = T; base(); setScroll(0); cables(NONE); const st = E.io(seg(T, 24.25, 24.6)), rk = E.io(seg(T, 24.45, 24.82));
      bRest(ben, T, 0); place(ben, lerp(0.55, PX, st), 0, lerp(1.0, PZ, st), lerp(-0.15, 0.9, E.io(seg(T, 24.2, 24.55))));
      if (T > 24.25 && T < 24.6) wlk(ben, (T - 24.25) * 12, 0.5 * Math.sin(PI * st));
      if (rk > 0) ik(ben, 1, _ih.copy(BTN).add(new THREE.Vector3(-0.1 - 0.6 * (1 - rk), -0.8 * (1 - rk), 0)), POLE);
      btnM.emissiveIntensity = E.out(seg(T, 24.8, 24.9)); ben.head.rotation.y = -0.6 * E.io(seg(T, 24.3, 24.7)); eyeS = 1; bFace(ben, 0.2, 0.15);
      camW(E.io(seg(lt, 0, 1.4)), [2.2, 3.0, 12.4, 0.5, 2.2, 0, 40], HOOK[0]); camFin(); } },
  { t: 25.1, set: world, mood: MOOD.shaft, loopin: 1,
    upd(lt){ dT = T - END; hookPose(0); camW(0, HOOK[0], HOOK[1]); camFin(); } },
];
const SUBS = __SUBS__;
