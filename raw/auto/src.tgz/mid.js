/* =========================================================
   STIMMUNG: praller Sommer (Parkplatz)
   ========================================================= */
function sky(a, b, c){
  const cv = document.createElement('canvas'); cv.width = 4; cv.height = 512; const x = cv.getContext('2d'), g = x.createLinearGradient(0, 0, 0, 512);
  g.addColorStop(0, a); g.addColorStop(0.6, b); g.addColorStop(1, c); x.fillStyle = g; x.fillRect(0, 0, 4, 512);
  const t = new THREE.CanvasTexture(cv); t.encoding = THREE.sRGBEncoding; return t;
}
const MOOD = { sun: { sky: sky('#3f86d8', '#8cc4f0', '#e8f2f6'), fog: [0xdfeaf0, 60, 220], hemi: [0xffffff, 0x8a7a60, 0.85], sun: [0xfff0d0, 1.5], sp: [10, 22, 6] } };
const SR = 12; { const c = sun.shadow.camera; c.left = -SR; c.right = SR; c.top = SR; c.bottom = -SR; c.near = 1; c.far = 70; c.updateProjectionMatrix(); }
function setMood(m){
  scene.background = m.sky; scene.fog.color.set(m.fog[0]); scene.fog.near = m.fog[1]; scene.fog.far = m.fog[2]; scene.environment = envDay || envNight;
  hemi.color.set(m.hemi[0]); hemi.groundColor.set(m.hemi[1]); hemi.intensity = m.hemi[2]; sun.color.set(m.sun[0]); sun.intensity = m.sun[1];
  sun.position.set(m.sp[0], m.sp[1], m.sp[2]); sun.target.position.set(0, 0, 0); fill.color.set(0xffffff); fill.intensity = 0.35; fill.position.set(-6, 5, 8);
}

/* =========================================================
   SET: Parkplatz, Bens Auto (offen gebaut), Eisstand
   ========================================================= */
const LOT = new THREE.Group(); scene.add(LOT); const SETS = [LOT];
(function(){
  const gr = new THREE.Mesh(new THREE.PlaneGeometry(500, 500), mat(0x55565a, { roughness: 1 })); gr.rotation.x = -PI / 2; gr.receiveShadow = true; LOT.add(gr);
  const wl = mat(0xf2f2ee, { roughness: 0.9 }); [-1.9, 1.9, -5.7, 5.7].forEach(z => P(LOT, rbox(6.4, 0.02, 0.14, 0.005, 1), wl, 0, 0.012, z));
  P(LOT, rbox(0.14, 0.02, 11.4, 0.005, 1), wl, -3.4, 0.012, 0);
  const curb = mat(0xb8b6ae, { roughness: 1 }); P(LOT, rbox(40, 0.25, 0.5, 0.04, 1), curb, 0, 0.12, -9);
  const gb = mat(0x5f8a3a, { roughness: 1 }); P(LOT, rbox(40, 0.2, 6, 0.04, 1), gb, 0, 0.1, -12.3);
  [-8, 2, 12].forEach((x, i) => { P(LOT, new THREE.CylinderGeometry(0.25, 0.35, 3, 8), mat(0x6a4a30), x, 1.5, -12); P(LOT, new THREE.IcosahedronGeometry(2.2, 0), mat(0x4e7a32, { flatShading: true }), x, 4.2, -12); });
  // Eisstand
  const K = new THREE.Group(); K.position.set(-4.7, 0, 3.6); K.rotation.y = PI; LOT.add(K);
  P(K, rbox(1.6, 1.9, 2.4, 0.05), mat(0xf6f2ea), 0, 0.95, 0); P(K, rbox(1.7, 0.1, 2.5, 0.02, 1), mat(0x8fd0e8), 0, 1.15, 0);
  const aw = (function(){ const c = document.createElement('canvas'); c.width = 128; c.height = 32; const x = c.getContext('2d'); for (let i = 0; i < 8; i++){ x.fillStyle = i % 2 ? '#ffffff' : '#ff6a8a'; x.fillRect(i * 16, 0, 16, 32); } const t = new THREE.CanvasTexture(c); t.encoding = THREE.sRGBEncoding; return t; })();
  const a = new THREE.Mesh(new THREE.BoxGeometry(2.2, 0.1, 2.9), new THREE.MeshStandardMaterial({ map: aw, roughness: 0.8 })); a.position.set(-0.4, 2.6, 0); a.rotation.z = 0.25; a.castShadow = true; K.add(a);
  [[-1.3, -1.3], [-1.3, 1.3], [0.7, -1.3], [0.7, 1.3]].forEach(([x, z]) => P(K, new THREE.CylinderGeometry(0.04, 0.04, 2.6, 6), mat(0xdddddd), x, 1.3, z));
  const sg = (function(){ const c = document.createElement('canvas'); c.width = 256; c.height = 96; const x = c.getContext('2d'); x.fillStyle = '#ff6a8a'; x.fillRect(0, 0, 256, 96); x.font = '900 72px sans-serif'; x.textAlign = 'center'; x.textBaseline = 'middle'; x.fillStyle = '#ffffff'; x.fillText('EIS', 128, 52); const t = new THREE.CanvasTexture(c); t.encoding = THREE.sRGBEncoding; return t; })();
  const s = new THREE.Mesh(new THREE.PlaneGeometry(1.2, 0.45), new THREE.MeshBasicMaterial({ map: sg })); s.position.set(-0.82, 1.55, 0); s.rotation.y = -PI / 2; K.add(s);
})();
function carShell(par, col, x, z){ const g = new THREE.Group(); g.position.set(x, 0, z); par.add(g); const cm = mat(col, { roughness: 0.35, metalness: 0.2 }), tr = mat(0x1c1c1c), gl = mat(0x3a5060, { roughness: 0.1, metalness: 0.4 });
  P(g, rbox(5.5, 1.0, 2.6, 0.2), cm, 0, 0.85, 0); P(g, rbox(3.0, 1.3, 2.4, 0.25), gl, -0.3, 2.0, 0); P(g, rbox(3.1, 0.12, 2.5, 0.05), cm, -0.3, 2.7, 0);
  [[-1.8, -1.25], [1.8, -1.25], [-1.8, 1.25], [1.8, 1.25]].forEach(([wx, wz]) => { const w = P(g, new THREE.CylinderGeometry(0.45, 0.45, 0.35, 14), tr, wx, 0.45, wz); w.rotation.x = PI / 2; }); return g; }
carShell(LOT, 0x2f6fb5, 0, -3.8); carShell(LOT, 0xe8e8e8, -7, 0);

// Bens Auto: offen gebaut, damit man hineinsieht (Glas transparent)
const CAR = new THREE.Group(); LOT.add(CAR);
const DOOR = new THREE.Group(); DOOR.position.set(1.0, 0, 1.3); CAR.add(DOOR); const DGLASS = new THREE.Group(); DOOR.add(DGLASS);
const SWEAT = []; const CONE = new THREE.Group();
(function(){ const cm = mat(0xd23a2e, { roughness: 0.35, metalness: 0.2 }), tr = mat(0x1c1c1c), it = mat(0x2e2e34, { roughness: 0.8 }), st = mat(0x3a3a44, { roughness: 0.9 });
  const glm = new THREE.MeshStandardMaterial({ color: 0xbfe0f0, roughness: 0.05, metalness: 0.1, transparent: true, opacity: 0.18, depthWrite: false, side: THREE.DoubleSide });
  P(CAR, rbox(5.5, 0.3, 2.6, 0.05), cm, 0, 0.5, 0);                    // Boden
  P(CAR, rbox(1.75, 1.0, 2.6, 0.2), cm, 1.875, 0.85, 0);               // Front
  P(CAR, rbox(2.15, 1.0, 2.6, 0.2), cm, -1.675, 0.85, 0);              // Heck
  P(CAR, rbox(1.6, 1.0, 0.15, 0.04), cm, 0.2, 0.85, -1.225);           // Beifahrerseite
  P(DOOR, rbox(1.6, 1.0, 0.15, 0.04), cm, -0.8, 0.85, -0.075);         // Fahrertür (Scharnier vorn)
  P(DOOR, rbox(0.06, 0.06, 0.25, 0.02, 1), mat(0x222222), -1.3, 1.2, 0.05);
  const gd = new THREE.Mesh(new THREE.PlaneGeometry(1.5, 1.35), glm); gd.position.set(-0.8, 2.05, -0.075); DGLASS.add(gd);
  const gp = new THREE.Mesh(new THREE.PlaneGeometry(1.5, 1.35), glm); gp.position.set(0.2, 2.05, -1.25); CAR.add(gp);
  const gr = new THREE.Mesh(new THREE.PlaneGeometry(1.7, 1.4), glm); gr.position.set(-1.65, 2.05, 1.25); CAR.add(gr);
  const gr2 = gr.clone(); gr2.position.z = -1.25; CAR.add(gr2);
  const ws = new THREE.Mesh(new THREE.PlaneGeometry(2.5, 1.7), glm); ws.position.set(1.35, 2.1, 0); ws.rotation.set(0, PI / 2, 0); ws.rotateX(-0.45); CAR.add(ws);
  const rw = new THREE.Mesh(new THREE.PlaneGeometry(2.5, 1.5), glm); rw.position.set(-2.55, 2.05, 0); rw.rotation.set(0, PI / 2, 0); rw.rotateX(0.4); CAR.add(rw);
  P(CAR, rbox(3.7, 0.12, 2.6, 0.05), cm, -0.65, 2.9, 0);                // Dach
  [[1.7, -1.22], [1.7, 1.22], [-2.45, -1.22], [-2.45, 1.22]].forEach(([x, z]) => { const p = P(CAR, rbox(0.12, 1.6, 0.12, 0.03, 1), cm, x, 2.1, z); p.rotation.z = x > 0 ? 0.45 : -0.4; });
  P(CAR, rbox(0.1, 1.55, 0.1, 0.03, 1), cm, -0.65, 2.1, 1.22); P(CAR, rbox(0.1, 1.55, 0.1, 0.03, 1), cm, -0.65, 2.1, -1.22);
  P(CAR, rbox(0.5, 0.35, 2.5, 0.08), it, 1.3, 1.5, 0);                  // Armaturenbrett
  const sw = P(CAR, new THREE.TorusGeometry(0.34, 0.05, 8, 24), mat(0x1a1a1a), 0.95, 1.85, 0.55); sw.rotation.set(0, PI / 2, 0); sw.rotateX(0.35);
  [0.55, -0.55].forEach(z => { P(CAR, rbox(1.0, 0.3, 0.95, 0.08), st, 0.1, 0.8, z); const b = P(CAR, rbox(0.25, 1.35, 0.9, 0.08), st, -0.48, 1.6, z); b.rotation.z = 0.12; });
  [[-1.8, -1.25], [1.8, -1.25], [-1.8, 1.25], [1.8, 1.25]].forEach(([wx, wz]) => { const w = P(CAR, new THREE.CylinderGeometry(0.45, 0.45, 0.35, 14), tr, wx, 0.45, wz); w.rotation.x = PI / 2; });
  const dm = new THREE.MeshStandardMaterial({ color: 0xa8dcff, roughness: 0.05, metalness: 0.2, transparent: true, opacity: 0.85 });
  for (let i = 0; i < 3; i++){ const d = new THREE.Mesh(new THREE.SphereGeometry(0.055, 10, 8), dm); ben.head.add(d); SWEAT.push(d); }
  ben.el[0].add(CONE); CONE.position.set(0, -0.72, 0.12); const cn = new THREE.Mesh(new THREE.ConeGeometry(0.13, 0.4, 12), mat(0xd2a05a)); cn.rotation.x = PI; CONE.add(cn);
  const sc = new THREE.Mesh(new THREE.SphereGeometry(0.15, 14, 10), mat(0xff8aa8, { roughness: 0.6 })); sc.position.y = 0.24; CONE.add(sc);
})();
function sweat(k){ SWEAT.forEach((d, i) => { const ph = (dT * 0.7 + i / 3) % 1; d.visible = k > 0.01; d.scale.setScalar(Math.max(0.01, k * Math.sin(PI * ph))); d.position.set([-0.38, 0.4, 0.05][i], 0.95 - ph * 0.55, [0.35, 0.3, 0.52][i]); }); }

/* =========================================================
   BEN
   ========================================================= */
const SCAR = new THREE.Group(); ben.head.add(SCAR);
(function(){ const m = mat(0xa8463f, { roughness: 0.7 }); const s = new THREE.Mesh(rbox(0.075, 0.72, 0.03, 0.012, 1), m); s.position.set(0.25, 0.55, 0.522); s.rotation.z = -0.13; SCAR.add(s);
  for (const y of [0.36, 0.55, 0.74]){ const c = new THREE.Mesh(rbox(0.16, 0.035, 0.03, 0.01, 1), m); c.position.set(0.25 + (y - 0.55) * 0.13, y, 0.528); c.rotation.z = -0.13; SCAR.add(c); } })();
// Ben auf dem Fahrersitz (Blick nach +x), fächelt sich Luft zu
function seatBen(t, k){ bRest(ben, t, 0); place(ben, 0.15, 0, 0.55, PI / 2); sit(ben, 0.95); ben.torso.rotation.x = -0.05 + 0.1 * k; ben.head.rotation.y = -0.5 * (1 - k * 0.4);
  ben.sh[1].rotation.set(-2.1, 0, 0.35 + 0.35 * Math.sin(t * 12)); ben.el[1].rotation.x = -1.3; ben.sh[0].rotation.set(-0.6, 0, -0.1); ben.el[0].rotation.x = -0.4; }

/* =========================================================
   KAMERA + Zustand
   ========================================================= */
const cL = new THREE.Vector3();
let blurAmt = 0, fadeBlk = 0, T = 0, flashA = 0, eyeS = 1, talk = 0, dT = 0;
let thK = 0, thV = 28, thM = 0, warmK = 0, warnK = 0, glareK = 0;
function camW(p, a, b){ cam.position.set(lerp(a[0], b[0], p), lerp(a[1], b[1], p), lerp(a[2], b[2], p)); cL.set(lerp(a[3], b[3], p), lerp(a[4], b[4], p), lerp(a[5], b[5], p)); cam.fov = lerp(a[6], b[6], p); }
function camFin(sh){ cam.position.x += Math.sin(dT * 0.7) * 0.015; cam.position.y += Math.sin(dT * 0.9 + 1) * 0.01; if (sh){ cam.position.x += Math.sin(T * 23) * sh; cam.position.y += Math.cos(T * 17) * sh; } cam.up.set(0, 1, 0); cam.lookAt(cL); cam.updateProjectionMatrix(); cam.updateMatrixWorld(); }
const HOOK = [[3.0, 2.3, 6.0, 0.2, 1.75, 0.5, 45], [2.6, 2.25, 5.2, 0.2, 1.75, 0.5, 45]];
function base(){ show(ben); CONE.visible = false; DOOR.rotation.y = 0; DGLASS.position.y = 0; glareK = 1; }
function hookBen(t){ seatBen(t, 0.3); eyeS = 0.9; bFace(ben, -0.5, 0.25); sweat(0.6); }

/* =========================================================
   SZENEN (Sprecherspur Tempo 1,2)
   ========================================================= */
const SCN = [
  { t: 0, set: LOT, mood: MOOD.sun, hook: 1,
    upd(lt){ dT = T; base(); warmK = 0.25; hookBen(T); camW(E.io(seg(lt, 0, 3.33)), HOOK[0], HOOK[1]); camFin(); } },
  { t: 3.33, set: LOT, mood: MOOD.sun, hud: () => ['DRAUSSEN 28 °C', 'SOMMER, PRALLE SONNE'],
    upd(lt){ dT = T; base(); warmK = 0.2; seatBen(T, 0.3); eyeS = 0.9; bFace(ben, -0.4, 0.2); sweat(0.5); thK = E.out(seg(T, 3.5, 3.8)) * (1 - seg(T, 5.25, 5.42)); thV = 28; thM = 0;
      camW(E.io(seg(lt, 0, 2.09)), [9.5, 4.2, 11.5, 0, 1.0, 0, 45], [8.2, 3.6, 10.2, 0, 1.1, 0, 45]); camFin(); } },
  { t: 5.42, set: LOT, mood: MOOD.sun, hud: () => ['NACH 10 MINUTEN', 'FAST 38 °C IM AUTO'],
    upd(lt){ dT = T; base(); const h = seg(T, 5.5, 7.2); warmK = 0.25 + 0.3 * h; seatBen(T, 0.5); eyeS = 0.75; bFace(ben, -0.7, 0.35); sweat(0.8);
      thK = E.out(seg(T, 5.5, 5.8)) * (1 - seg(T, 10.0, 10.2)); thV = lerp(28, 38, E.io(h)); thM = 1;
      camW(E.io(seg(lt, 0, 4.78)), [1.55, 2.3, -0.9, 0.15, 2.0, 0.55, 55], [1.35, 2.25, -0.7, 0.15, 2.0, 0.55, 55]); camFin(); } },
  { t: 10.2, set: LOT, mood: MOOD.sun, hud: () => ['NACH 30 MINUTEN', 'RUND 50 °C'],
    upd(lt){ dT = T; base(); const h = seg(T, 10.3, 12.0); warmK = 0.55 + 0.35 * h; seatBen(T, 1); ben.head.rotation.x = 0.3 * h; ben.head.rotation.y = -0.2; ben.sh[1].rotation.set(-0.2, 0, 0.15); ben.el[1].rotation.x = -0.2;
      eyeS = lerp(0.7, 0.35, h); bFace(ben, -0.6, 0.45); sweat(1); thK = E.out(seg(T, 10.3, 10.6)) * (1 - seg(T, 12.9, 13.07)); thV = lerp(38, 50, E.io(h)); thM = 2;
      camW(E.io(seg(lt, 0, 2.87)), [1.65, 2.05, 0.05, 0.1, 2.05, 0.55, 55], [1.5, 2.05, 0.15, 0.1, 2.05, 0.55, 55]); camFin(); } },
  { t: 13.07, set: LOT, mood: MOOD.sun, hud: () => ['FENSTER-SPALT?', 'BRINGT KAUM WAS'],
    upd(lt){ dT = T; base(); DGLASS.position.y = -0.3 * E.io(seg(T, 13.3, 13.9)); warmK = 0.8; seatBen(T, 0.8); ben.head.rotation.y = 0.3; eyeS = 0.6; bFace(ben, -0.7, 0.3); sweat(1);
      thK = E.out(seg(T, 14.2, 14.5)) * (1 - seg(T, 16.7, 16.87)); thV = 48; thM = 3;
      camW(E.io(seg(lt, 0, 3.8)), [2.3, 2.25, 4.4, 0.0, 2.0, 0.8, 45], [2.0, 2.2, 3.9, 0.0, 2.0, 0.8, 45]); camFin(); } },
  { t: 16.87, set: LOT, mood: MOOD.sun, hud: () => ['WICHTIG!', 'AUCH NICHT KURZ'],
    upd(lt){ dT = T; base(); DGLASS.position.y = -0.3; warmK = 0.6; seatBen(T, 0.9); eyeS = 0.6; bFace(ben, -0.7, 0.3); sweat(1);
      warnK = E.out(seg(T, 17.0, 17.3)) * (1 - seg(T, 20.65, 20.85)); camW(E.io(seg(lt, 0, 3.98)), [7.5, 3.6, 9.5, 0, 1.2, 0, 45], [6.4, 3.2, 8.4, 0, 1.2, 0, 45]); camFin(); } },
  { t: 20.85, set: LOT, mood: MOOD.sun, hud: () => ['UND BEN?', 'STEIGT AUS – EIS!'],
    upd(lt){ dT = T; base(); DGLASS.position.y = -0.3; warmK = 0.3 * (1 - seg(T, 21, 21.8)); const op = E.io(seg(T, 20.9, 21.2)); DOOR.rotation.y = 1.45 * op;
      const out = E.io(seg(T, 21.1, 21.5)), up = E.io(seg(T, 21.45, 21.75)), wk = seg(T, 21.75, 22.5), tn = E.io(seg(T, 22.45, 22.8));
      bRest(ben, T, 0); const x = lerp(0.15, 0.1, out) - lerp(0, 3.0, E.io(wk)), z = lerp(0.55, 2.3, out) + lerp(0, 0.6, E.io(wk)); place(ben, x, 0, z, lerp(lerp(PI / 2, 0, out), -PI / 2, seg(T, 21.65, 21.85)) * (1 - tn) + 0.3 * tn);
      if (up < 1){ sit(ben, 0.95); ben.body.position.y = lerp(1.13, 1.0, up); ben.legs[0].rotation.x = -1.5 * (1 - up); ben.legs[1].rotation.x = -1.5 * (1 - up); }
      if (wk > 0 && wk < 1) wlk(ben, T * 13, 1);
      CONE.visible = T > 22.45; if (T > 22.45){ ben.sh[0].rotation.set(-1.7, 0, -0.1); ben.el[0].rotation.x = -1.2 - 0.25 * Math.max(0, Math.sin(T * 6)); }
      sweat(0.6 * (1 - seg(T, 21.5, 22.2))); eyeS = lerp(0.8, 1.15, tn); bFace(ben, lerp(-0.4, 0.7, tn), lerp(0.2, 0.15, tn));
      camW(E.io(seg(lt, 0, 2.6)), [3.6, 2.7, 10.2, -1.2, 1.5, 2.2, 50], [2.8, 2.6, 9.4, -1.8, 1.6, 2.6, 50]); camFin(); } },
  { t: 23.45, set: LOT, mood: MOOD.sun, loopin: 1,
    upd(lt){ dT = T - END; base(); warmK = 0.25; hookBen(T - END); camW(0, HOOK[0], HOOK[1]); camFin(); } },
];
const SUBS = __SUBS__;
