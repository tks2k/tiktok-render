/* =========================================================
   STIMMUNG: Wald am Tag
   ========================================================= */
function sky(a, b, c){
  const cv = document.createElement('canvas'); cv.width = 4; cv.height = 512; const x = cv.getContext('2d'), g = x.createLinearGradient(0, 0, 0, 512);
  g.addColorStop(0, a); g.addColorStop(0.6, b); g.addColorStop(1, c); x.fillStyle = g; x.fillRect(0, 0, 4, 512);
  const t = new THREE.CanvasTexture(cv); t.encoding = THREE.sRGBEncoding; return t;
}
const MOOD = { wood: { sky: sky('#6aa8d8', '#b4d8ec', '#e4efe0'), fog: [0xbcd0b4, 30, 120], hemi: [0xf4fff0, 0x5a6a3a, 0.9], sun: [0xfff0d0, 1.2], sp: [8, 16, 10] } };
const SR = 14; { const c = sun.shadow.camera; c.left = -SR; c.right = SR; c.top = SR; c.bottom = -SR; c.near = 1; c.far = 60; c.updateProjectionMatrix(); }
function setMood(m){
  scene.background = m.sky; scene.fog.color.set(m.fog[0]); scene.fog.near = m.fog[1]; scene.fog.far = m.fog[2]; scene.environment = envDay || envNight;
  hemi.color.set(m.hemi[0]); hemi.groundColor.set(m.hemi[1]); hemi.intensity = m.hemi[2]; sun.color.set(m.sun[0]); sun.intensity = m.sun[1];
  sun.position.set(m.sp[0], m.sp[1], m.sp[2]); sun.target.position.set(0, 0, -2); fill.color.set(0xffffff); fill.intensity = 0.35; fill.position.set(-5, 6, 10);
}

/* =========================================================
   SET: Waldweg, Bäume, Büsche, Felsen
   ========================================================= */
const WOOD = new THREE.Group(); scene.add(WOOD); const SETS = [WOOD];
(function(){ const gr = new THREE.Mesh(new THREE.PlaneGeometry(400, 400), mat(0x5a7a3a, { roughness: 1 })); gr.rotation.x = -PI / 2; gr.receiveShadow = true; WOOD.add(gr);
  const pth = new THREE.Mesh(new THREE.PlaneGeometry(3.2, 120), mat(0xa88a5a, { roughness: 1 })); pth.rotation.x = -PI / 2; pth.position.set(0, 0.01, -20); pth.receiveShadow = true; WOOD.add(pth);
  const tk = mat(0x5a3e28, { roughness: 1 }), lf = [mat(0x2e5a2a, { flatShading: true }), mat(0x3a6a30, { flatShading: true }), mat(0x24482a, { flatShading: true })];
  const TREES = [[-3.2, -6.5], [3.8, -4], [-4.5, 2], [4.6, 3.5], [-5.5, -12], [5.2, -11], [-3.6, -18], [4.2, -17], [-7, -3], [7.5, -8], [-8, 7], [8.5, 9], [-4, 9], [6, 14], [-6, -24], [6, -26], [-9, -16], [10, -20]];
  TREES.forEach(([x, z], i) => { const h = 5 + hsh(i) * 3; P(WOOD, new THREE.CylinderGeometry(0.35, 0.5, h, 8), tk, x, h / 2, z);
    if (i % 2) P(WOOD, new THREE.ConeGeometry(2.2 + hsh(i + 3), 5 + hsh(i + 5) * 2, 8), lf[i % 3], x, h + 1.5, z); else P(WOOD, new THREE.IcosahedronGeometry(2.4 + hsh(i + 3) * 0.8, 0), lf[i % 3], x, h + 1, z); });
  [[-2.4, 0.5], [2.6, -1.5], [-2.8, -9], [2.5, -14], [-2.2, 5]].forEach(([x, z], i) => P(WOOD, new THREE.IcosahedronGeometry(0.9 + hsh(i) * 0.4, 0), lf[(i + 1) % 3], x, 0.6, z));
  [[2.4, 1.8], [-2.6, -4]].forEach(([x, z], i) => P(WOOD, new THREE.DodecahedronGeometry(0.6, 0), mat(0x8a8a84, { flatShading: true }), x, 0.4, z));
})();
// Bär: Körper mit Drehpunkt an der Hüfte (zum Aufrichten), vier Beine
const BEAR = new THREE.Group(); WOOD.add(BEAR); const BB = new THREE.Group(); BEAR.add(BB); BB.position.set(0, 1.3, -1.1);
const BL = [];
(function(){ const fm = mat(0x6a4428, { roughness: 0.95 }), dk = mat(0x3a2414, { roughness: 0.9 }), sn = mat(0xb08860, { roughness: 0.9 }), ey = mat(0x111111, { roughness: 0.3 });
  P(BB, rbox(1.7, 1.5, 2.8, 0.35), fm, 0, 0.1, 1.1); P(BB, rbox(1.4, 0.5, 1.0, 0.2), fm, 0, 0.75, 1.6);
  const H = new THREE.Group(); H.position.set(0, 0.45, 2.75); BB.add(H); P(H, rbox(1.0, 0.95, 0.95, 0.25), fm, 0, 0, 0); P(H, rbox(0.55, 0.45, 0.5, 0.12), sn, 0, -0.15, 0.62); P(H, rbox(0.22, 0.16, 0.12, 0.05), dk, 0, -0.02, 0.88);
  P(H, rbox(0.3, 0.3, 0.16, 0.08), fm, -0.4, 0.55, -0.1); P(H, rbox(0.3, 0.3, 0.16, 0.08), fm, 0.4, 0.55, -0.1); P(H, rbox(0.11, 0.11, 0.05, 0.03), ey, -0.24, 0.17, 0.48); P(H, rbox(0.11, 0.11, 0.05, 0.03), ey, 0.24, 0.17, 0.48);
  [[-0.55, 2.1, 1], [0.55, 2.1, 1], [-0.55, 0.2, 0], [0.55, 0.2, 0]].forEach(([x, z, fr]) => { const g = new THREE.Group(); g.position.set(x, -0.1, z); (fr ? BB : BEAR).add(g); if (!fr) g.position.set(x, 1.2, z - 1.1);
    P(g, rbox(0.5, 1.3, 0.55, 0.15), fm, 0, -0.6, 0); P(g, rbox(0.55, 0.18, 0.7, 0.06), dk, 0, -1.22, 0.08); BL.push(g); });
})();
// bearPose: Position, Blickrichtung, Aufrichten (0..1), Laufphase
function bearPose(x, z, yaw, rear, ph, gait){ BEAR.position.set(x, 0, z); BEAR.rotation.set(0, yaw, 0); BB.rotation.x = -1.15 * rear; BB.position.y = 1.3 + 0.12 * Math.abs(Math.sin(ph)) * gait;
  BL.forEach((g, i) => { g.rotation.x = 0.55 * gait * Math.sin(ph + (i % 2 ? PI : 0) + (i > 1 ? PI / 2 : 0)) + (i < 2 ? 0.9 * rear : 0); }); }
// Bärenspray am Gürtel
const SPRAY = new THREE.Group(); ben.torso.add(SPRAY); SPRAY.position.set(0.62, 0.05, 0.15); P(SPRAY, new THREE.CylinderGeometry(0.1, 0.1, 0.42, 10), mat(0xd03a22, { roughness: 0.4 }), 0, 0, 0); P(SPRAY, rbox(0.12, 0.08, 0.14, 0.02, 1), mat(0x222222), 0, 0.25, 0);

/* =========================================================
   BEN
   ========================================================= */
const SCAR = new THREE.Group(); ben.head.add(SCAR);
(function(){ const m = mat(0xa8463f, { roughness: 0.7 }); const s = new THREE.Mesh(rbox(0.075, 0.72, 0.03, 0.012, 1), m); s.position.set(0.25, 0.55, 0.522); s.rotation.z = -0.13; SCAR.add(s);
  for (const y of [0.36, 0.55, 0.74]){ const c = new THREE.Mesh(rbox(0.16, 0.035, 0.03, 0.01, 1), m); c.position.set(0.25 + (y - 0.55) * 0.13, y, 0.528); c.rotation.z = -0.13; SCAR.add(c); } })();

/* =========================================================
   KAMERA + Zustand
   ========================================================= */
const cL = new THREE.Vector3();
let blurAmt = 0, fadeBlk = 0, T = 0, flashA = 0, eyeS = 1, talk = 0, dT = 0;
let spdK = 0, xK = 0, calmK = 0, deadK = 0, sprayK = 0;
function camW(p, a, b){ cam.position.set(lerp(a[0], b[0], p), lerp(a[1], b[1], p), lerp(a[2], b[2], p)); cL.set(lerp(a[3], b[3], p), lerp(a[4], b[4], p), lerp(a[5], b[5], p)); cam.fov = lerp(a[6], b[6], p); }
function camFin(sh){ cam.position.x += Math.sin(dT * 0.7) * 0.02; cam.position.y += Math.sin(dT * 0.9 + 1) * 0.015; if (sh){ cam.position.x += Math.sin(T * 23) * sh; cam.position.y += Math.cos(T * 17) * sh; } cam.up.set(0, 1, 0); cam.lookAt(cL); cam.updateProjectionMatrix(); cam.updateMatrixWorld(); }
const HOOK = [[2.6, 3.4, 10.5, 0, 2.6, -2.0, 50], [2.2, 3.3, 9.6, 0, 2.6, -2.0, 50]];
function base(){ show(ben); BEAR.visible = true; SPRAY.visible = false; }
function hookBen(t){ bRest(ben, t, 0); const w = seg(t, 0, 2.6); place(ben, 0, 0, lerp(1.2, 2.4, w), 0); if (t < 2.6) wlk(ben, t * 8, 0.7); eyeS = 1; bFace(ben, 0.5, 0.1);
  if (t > 3.0){ const s = E.io(seg(t, 3.0, 3.5)); ben.head.rotation.y = 1.2 * s; eyeS = lerp(1, 1.45, s); bFace(ben, lerp(0.5, -1, s), 0.4 * s); }
  const bw = seg(t, 0.6, 2.6), rr = E.io(seg(t, 2.8, 3.6)); bearPose(lerp(-4.2, 0.4, bw), lerp(-7.2, -7.6, bw), lerp(PI / 2, 0.05, E.io(seg(t, 1.8, 2.8))), rr, t * 7, bw > 0 && bw < 1 ? 1 : 0); }

/* =========================================================
   SZENEN (Sprecherspur Tempo 1,15)
   ========================================================= */
const SCN = [
  { t: 0, set: WOOD, mood: MOOD.wood, hook: 1,
    upd(lt){ dT = T; base(); hookBen(T); camW(E.io(seg(lt, 0, 4.38)), HOOK[0], HOOK[1]); camFin(0.03 * bump(T, 3.1, 3.7)); } },
  { t: 4.38, set: WOOD, mood: MOOD.wood, hud: () => ['WEGRENNEN?', 'KEINE CHANCE!'],
    upd(lt){ dT = T; base(); bRest(ben, T, 0); const tn = E.io(seg(T, 4.4, 4.9)), rn = seg(T, 4.9, 5.5); place(ben, 0, 0, 2.4 + 0.6 * E.out(rn), lerp(0, PI, tn) * (1 - E.io(seg(T, 4.9, 5.1))) + 0); if (rn > 0 && rn < 1) wlk(ben, T * 14, 1);
      if (T > 5.5){ const s = E.io(seg(T, 5.5, 5.9)); place(ben, 0, 0, 3.0, lerp(0, PI, s)); ben.sh[0].rotation.set(0, 0, -0.9 * s); ben.sh[1].rotation.set(0, 0, 0.9 * s); }
      eyeS = 1.45; bFace(ben, -1, 0.4); bearPose(0.4, -7.6, 0.05, 1 - E.io(seg(T, 4.6, 5.3)), T * 6, 0);
      spdK = E.out(seg(T, 6.7, 7.0)) * (1 - seg(T, 9.68, 9.86)); xK = E.out(seg(T, 5.6, 5.9)) * (1 - seg(T, 6.55, 6.71));
      camW(E.io(seg(lt, 0, 5.48)), [9.0, 3.2, 0.0, 0.0, 2.0, -2.4, 50], [8.4, 3.0, -1.0, 0.0, 2.0, -2.6, 50]); camFin(); } },
  { t: 9.86, set: WOOD, mood: MOOD.wood, hud: () => ['BESSER:', 'RUHIG & LANGSAM ZURÜCK'],
    upd(lt){ dT = T; base(); bRest(ben, T, 0); const bk = seg(T, 12.9, 15.2); place(ben, 0, 0, 3.0 + 1.6 * bk, PI); if (bk > 0 && bk < 1) wlk(ben, -T * 4, 0.35);
      ben.sh[0].rotation.set(-0.9, 0, -0.5); ben.sh[1].rotation.set(-0.9, 0, 0.5); ben.el[0].rotation.x = -0.6; ben.el[1].rotation.x = -0.6; eyeS = 1.15; bFace(ben, -0.4, 0.12 + 0.12 * Math.max(0, Math.sin(T * 7)) * seg(T, 11.6, 12.9) * (1 - seg(T, 12.9, 13.0)));
      bearPose(0.4, -7.6, 0.05 + 0.2 * Math.sin(T * 0.8), 0, T * 6, 0); calmK = E.out(seg(T, 10.0, 10.3)) * (1 - seg(T, 15.05, 15.22));
      camW(E.io(seg(lt, 0, 5.36)), [2.6, 3.8, 9.5, 0, 2.2, -3.0, 50], [2.2, 3.7, 10.8, 0, 2.2, -2.5, 50]); camFin(); } },
  { t: 15.22, set: WOOD, mood: MOOD.wood, hud: () => ['GREIFT ER AN:', 'TOTSTELLEN'],
    upd(lt){ dT = T; base(); bRest(ben, T, 0); const dn = E.io(seg(T, 16.5, 17.1)); place(ben, 0, 0.42 * dn, 4.6, 0); ben.root.rotation.x = 1.57 * dn;
      const nk = E.io(seg(T, 17.6, 18.0)); ben.sh[0].rotation.set(-3.0 * nk, 0, -0.5 * nk); ben.sh[1].rotation.set(-3.0 * nk, 0, 0.5 * nk); ben.el[0].rotation.x = -1.5 * nk; ben.el[1].rotation.x = -1.5 * nk; ben.head.rotation.x = 0.3 * nk;
      eyeS = lerp(1.45, 0.1, dn); bFace(ben, -0.8, 0.2);
      const ch = seg(T, 15.3, 16.4), lv = seg(T, 18.9, 20.2), z = lerp(-7.6, 1.4, E.out(ch)) - 9 * lv; bearPose(0.4 + 0.3 * Math.sin(T * 2) * seg(T, 16.6, 18.8), z, lv > 0 ? PI : 0.05, 0, T * (ch < 1 ? 12 : 7), (ch > 0 && ch < 1) || lv > 0 ? 1 : 0.2 * seg(T, 16.6, 18.8));
      BEAR.rotation.y = lerp(0.05, PI, E.io(seg(T, 18.7, 19.2))); deadK = E.out(seg(T, 16.6, 16.9)) * (1 - seg(T, 20.0, 20.19));
      camW(E.io(seg(lt, 0, 4.97)), [8.5, 5.5, 8.5, 0, 0.8, 1.5, 52], [7.6, 5.0, 7.6, 0, 0.8, 2.0, 52]); camFin(0.04 * bump(T, 16.0, 16.5)); } },
  { t: 20.19, set: WOOD, mood: MOOD.wood, hud: () => ['UND BEN?', 'BÄRENSPRAY & LÄRM'],
    upd(lt){ dT = T; base(); BEAR.visible = false; SPRAY.visible = true; bRest(ben, T, 0); place(ben, 0, 0, lerp(-2, 1.5, seg(T, 20.19, 24.5)), 0); wlk(ben, T * 8, 0.7);
      if (T > 22.9){ const c = Math.max(0, Math.sin(T * 14)); ben.sh[0].rotation.set(-1.4, 0, 0.35 + 0.3 * c); ben.sh[1].rotation.set(-1.4, 0, -0.35 - 0.3 * c); ben.el[0].rotation.x = -0.4; ben.el[1].rotation.x = -0.4; }
      eyeS = 1; bFace(ben, 0.7, 0.12); sprayK = E.out(seg(T, 21.8, 22.1));
      camW(E.io(seg(lt, 0, 3.9)), [2.6, 3.0, 9.6, 0, 2.6, 0, 48], [2.2, 2.9, 9.0, 0, 2.6, 0.5, 48]); camFin(); } },
  { t: 24.15, set: WOOD, mood: MOOD.wood, loopin: 1,
    upd(lt){ dT = T - END; base(); hookBen(T - END); camW(0, HOOK[0], HOOK[1]); camFin(); } },
];
const SUBS = __SUBS__;
