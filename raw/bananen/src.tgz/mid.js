/* =========================================================
   STIMMUNG: Küche (warm, hell)
   ========================================================= */
const MOOD = { kit: { bg: 0xf2e6d2, fog: [0xf2e6d2, 40, 120], hemi: [0xfff6ea, 0x9a8a70, 0.95], sun: [0xfff0dc, 1.0] } };
const SR = 10; { const c = sun.shadow.camera; c.left = -SR; c.right = SR; c.top = SR; c.bottom = -SR; c.near = 1; c.far = 80; c.updateProjectionMatrix(); }
function setMood(m){
  scene.background = new THREE.Color(m.bg); scene.fog.color.set(m.fog[0]); scene.fog.near = m.fog[1]; scene.fog.far = m.fog[2]; scene.environment = envDay;
  hemi.color.set(m.hemi[0]); hemi.groundColor.set(m.hemi[1]); hemi.intensity = m.hemi[2]; sun.color.set(m.sun[0]); sun.intensity = m.sun[1];
  sun.position.set(6, 16, 12); sun.target.position.set(0, 0, 0); fill.color.set(0xffffff); fill.intensity = 0.35; fill.position.set(-8, 6, 14);
}

/* =========================================================
   SET: Küche mit Tisch, Ofen, Bananenberg
   ========================================================= */
const KIT = new THREE.Group(); scene.add(KIT); const SETS = [KIT];
const TY = 1.45;   // Tischhöhe
(function(){
  const fl = new THREE.Mesh(new THREE.PlaneGeometry(60, 60), mat(0xc8a878, { roughness: 0.8 })); fl.rotation.x = -PI / 2; fl.receiveShadow = true; KIT.add(fl);
  for (let i = -6; i <= 6; i++) P(KIT, rbox(0.03, 0.01, 30, 0.004, 1), mat(0xa88a60), i * 1.2, 0.006, 0);
  P(KIT, rbox(24, 10, 0.3, 0.02, 1), mat(0xe8eef2, { roughness: 1 }), 0, 5, -4.5);
  for (let i = 0; i < 10; i++) P(KIT, rbox(24, 0.04, 0.05, 0.01, 1), mat(0xd0d8de), 0, 2.2 + i * 0.4, -4.33);
  const cb = mat(0x5a8ab0, { roughness: 0.6 }); P(KIT, rbox(9, 1.9, 1.4, 0.06), cb, 0, 0.95, -3.7); P(KIT, rbox(9.2, 0.12, 1.5, 0.03, 1), mat(0xf2f2f2), 0, 1.95, -3.7);
  P(KIT, rbox(1.9, 1.6, 0.06, 0.03, 1), mat(0x1a1a20, { roughness: 0.2, metalness: 0.3 }), 2.4, 0.95, -2.98); P(KIT, rbox(1.4, 0.06, 0.06, 0.02, 1), mat(0xc8c8cc, { metalness: 0.7 }), 2.4, 1.7, -2.93);
  P(KIT, rbox(1.9, 1.4, 1.0, 0.1), mat(0x2a2a30, { metalness: 0.3, roughness: 0.4 }), -2.6, 2.7, -3.9);
  const tb = mat(0xb07a48, { roughness: 0.7 }); P(KIT, rbox(4.4, 0.14, 1.8, 0.04), tb, 0, TY - 0.07, 0.9);
  [[-2.0, 0.15], [2.0, 0.15], [-2.0, 1.65], [2.0, 1.65]].forEach(([x, z]) => P(KIT, rbox(0.14, TY - 0.14, 0.14, 0.03), tb, x, (TY - 0.14) / 2, z));
})();
const bCurve = new THREE.QuadraticBezierCurve3(new THREE.Vector3(-0.36, 0.05, 0), new THREE.Vector3(0, -0.13, 0), new THREE.Vector3(0.36, 0.05, 0));
const BGEO = new THREE.TubeGeometry(bCurve, 14, 0.075, 7, false);
const BYM = mat(0xf2d23a, { roughness: 0.55 }), BTM = mat(0x5a4020), PEELM = mat(0xd8b02a, { roughness: 0.8 });
function banana(par, m){ const g = new THREE.Group(); const b = new THREE.Mesh(BGEO, m || BYM); b.castShadow = true; g.add(b); [-1, 1].forEach(s => { const t = new THREE.Mesh(new THREE.SphereGeometry(0.06, 6, 4), BTM); t.position.set(s * 0.36, 0.05, 0); g.add(t); }); par.add(g); return g; }
const PILE = new THREE.Group(); KIT.add(PILE); PILE.position.set(-1.05, TY, 0.95);
const PB = [];
for (let k = 0; k < 100; k++){ const h = Math.pow(hsh(k * 3 + 1), 1.3), r = (1 - h) * 0.95 * Math.sqrt(hsh(k * 5 + 2)), a = hsh(k * 7 + 3) * PI * 2;
  const b = banana(PILE); b.position.set(Math.cos(a) * r, 0.08 + h * 1.0, Math.sin(a) * r * 0.75); b.rotation.set((hsh(k) - 0.5) * 0.5, hsh(k + 11) * PI, (hsh(k + 13) - 0.5) * 0.6); PB.push(b); }
const PEELS = []; for (let k = 0; k < 10; k++){ const p = banana(KIT, PEELM); p.scale.set(1, 0.5, 1.4); p.position.set(0.9 + (k % 4) * 0.28, TY + 0.05 + Math.floor(k / 4) * 0.07, 0.6 + (k % 3) * 0.3); p.rotation.y = hsh(k + 40) * PI; PEELS.push(p); }
const LOAF = new THREE.Group(); KIT.add(LOAF); LOAF.position.set(-1.0, TY, 0.95);
(function(){ const lb = mat(0x8a5428, { roughness: 0.8 }), lt = mat(0x5a3418, { roughness: 0.9 });
  for (let i = 0; i < 3; i++){ const g = new THREE.Group(); g.position.set(-0.55 + i * 0.55, 0, (i % 2) * 0.35); g.rotation.y = 0.2 * (i - 1); LOAF.add(g); P(g, rbox(0.5, 0.42, 1.1, 0.12), lb, 0, 0.21, 0); P(g, rbox(0.42, 0.1, 1.0, 0.05), lt, 0, 0.43, 0); } })();
const PLATE = P(KIT, new THREE.CylinderGeometry(0.55, 0.45, 0.06, 24), mat(0xf6f6f6, { roughness: 0.4 }), 0.25, TY + 0.03, 1.1);

/* =========================================================
   BEN: Narbe, Banane in der Hand, Bauch
   ========================================================= */
const SCAR = new THREE.Group(); ben.head.add(SCAR);
(function(){ const m = mat(0xa8463f, { roughness: 0.7 }); const s = new THREE.Mesh(rbox(0.075, 0.72, 0.03, 0.012, 1), m); s.position.set(0.25, 0.55, 0.522); s.rotation.z = -0.13; SCAR.add(s);
  for (const y of [0.36, 0.55, 0.74]){ const c = new THREE.Mesh(rbox(0.16, 0.035, 0.03, 0.01, 1), m); c.position.set(0.25 + (y - 0.55) * 0.13, y, 0.528); c.rotation.z = -0.13; SCAR.add(c); } })();
const GLOWM = new THREE.MeshStandardMaterial({ color: 0xf2d23a, roughness: 0.5, emissive: 0x6aff4a, emissiveIntensity: 0 });
const HB = banana(ben.el[1], GLOWM); HB.position.set(0, -0.62, 0.2); HB.rotation.set(0, PI / 2, 1.2);
const SLC = P(ben.el[1], rbox(0.18, 0.4, 0.5, 0.05), mat(0x8a5428), 0, -0.66, 0.2);
const BELLY = P(ben.torso, new THREE.SphereGeometry(0.44, 20, 14), mat(0xE8B21F), 0, 0.36, 0.2);
function belly(k){ BELLY.visible = k > 0.01; BELLY.scale.set(1 + 0.35 * k, 0.9 + 0.35 * k, 0.15 + 1.1 * k); }

/* =========================================================
   KAMERA + Zustand
   ========================================================= */
const cL = new THREE.Vector3();
let blurAmt = 0, fadeBlk = 0, T = 0, flashA = 0, eyeS = 1, talk = 0, dT = 0;
let radK = 0, cmpK = 0, wgtK = 0, stoK = 0, brdK = 0, nEat = 0;
function camW(p, a, b){ cam.position.set(lerp(a[0], b[0], p), lerp(a[1], b[1], p), lerp(a[2], b[2], p)); cL.set(lerp(a[3], b[3], p), lerp(a[4], b[4], p), lerp(a[5], b[5], p)); cam.fov = lerp(a[6], b[6], p); }
function camFin(sh){ cam.position.x += Math.sin(dT * 0.7) * 0.03; cam.position.y += Math.sin(dT * 0.9 + 1) * 0.02; if (sh){ cam.position.x += Math.sin(T * 23) * sh; cam.position.y += Math.cos(T * 17) * sh; } cam.up.set(0, 1, 0); cam.lookAt(cL); cam.updateProjectionMatrix(); cam.updateMatrixWorld(); }
const HOOK = [[1.4, 3.4, 7.8, -0.3, 2.3, 0.2, 46], [1.3, 3.3, 7.5, -0.3, 2.3, 0.2, 46]];
// n: wie viele Bananen schon gegessen (Berg schrumpft oben, Schalen wachsen)
function base(n, loaf){ show(ben); PILE.visible = !loaf; LOAF.visible = !!loaf; PB.forEach((b, i) => b.visible = i < 100 - n); PEELS.forEach((p, i) => p.visible = i < n); HB.visible = !loaf; SLC.visible = !!loaf; GLOWM.emissiveIntensity = 0; belly(0); }
function benAt(){ bRest(ben, T, 0); place(ben, 0.25, 0, -0.55, 0); }
function eat(t, a){ ben.sh[1].rotation.set(-2.0 + 0.25 * Math.sin(t * 6) * a, 0, 0.35); ben.el[1].rotation.x = -1.3; bFace(ben, 0.5, 0.3 + 0.45 * Math.max(0, Math.sin(t * 6)) * a); }
function hookBen(t){ benAt(); eat(t, 0.4); ben.sh[0].rotation.set(-0.6, 0, -0.3); eyeS = 1.15; }

/* =========================================================
   SZENEN (Sprecherspur Tempo 1,12)
   ========================================================= */
const SCN = [
  { t: 0, set: KIT, mood: MOOD.kit, hook: 1,
    upd(lt){ dT = T; base(0); hookBen(T); camW(E.io(seg(lt, 0, 3.58)), HOOK[0], [1.0, 3.0, 6.6, -0.3, 2.3, 0.2, 46]); camFin(); } },
  { t: 3.58, set: KIT, mood: MOOD.kit, hud: () => ['LEICHT RADIOAKTIV', 'WEGEN KALIUM-40'],
    upd(lt){ dT = T; base(1); benAt(); ben.sh[1].rotation.set(-1.5, 0, 0.2); ben.el[1].rotation.x = -0.7; ben.head.rotation.x = 0.25; eyeS = 1.4; bFace(ben, -0.6, 0.35);
      GLOWM.emissiveIntensity = 0.45 + 0.15 * Math.sin(T * 2.4); radK = E.out(seg(T, 3.8, 4.1)) * (1 - seg(T, 6.8, 6.96));
      camW(E.io(seg(lt, 0, 3.38)), [1.6, 3.0, 4.4, 0.4, 2.4, 0.4, 44], [1.2, 2.9, 3.8, 0.4, 2.4, 0.4, 42]); camFin(); } },
  { t: 6.96, set: KIT, mood: MOOD.kit, hud: () => ['100 BANANEN', 'WENIGER ALS EIN FLUG'],
    upd(lt){ dT = T; base(1); benAt(); ben.sh[1].rotation.set(-0.9, 0, 0.3); ben.el[1].rotation.x = -0.4; eyeS = 1.0; bFace(ben, 0.8, 0.15); GLOWM.emissiveIntensity = 0.2;
      cmpK = E.out(seg(T, 7.2, 7.5)) * (1 - seg(T, 11.1, 11.28));
      camW(E.io(seg(lt, 0, 4.32)), [-3.6, 3.4, 6.6, -0.5, 2.1, 0.4, 46], [-2.4, 3.2, 6.4, -0.3, 2.1, 0.4, 46]); camFin(); } },
  { t: 11.28, set: KIT, mood: MOOD.kit, hud: () => ['DAS ECHTE PROBLEM', 'SEIN MAGEN'],
    upd(lt){ dT = T; const n = 1 + Math.floor(4 * seg(T, 11.4, 13.9)); base(n); benAt(); eat(T, 1); eyeS = 1.0; belly(0.35 * seg(T, 11.4, 13.9));
      camW(E.io(seg(lt, 0, 2.7)), [2.8, 2.6, 5.4, 0.1, 2.2, 0, 44], [2.4, 2.5, 4.8, 0.1, 2.2, 0, 44]); camFin(); } },
  { t: 13.98, set: KIT, mood: MOOD.kit, hud: () => ['12 KILO BANANEN', '100 × CA. 120 GRAMM'],
    upd(lt){ dT = T; base(5); benAt(); eat(T, 0.5); belly(0.35); eyeS = 1.0; wgtK = E.out(seg(T, 14.2, 14.5)) * (1 - seg(T, 16.5, 16.68));
      camW(E.io(seg(lt, 0, 2.7)), [-2.6, 2.6, 4.6, -1.0, 2.1, 0.8, 46], [-2.2, 2.5, 4.2, -1.0, 2.1, 0.8, 46]); camFin(); } },
  { t: 16.68, set: KIT, mood: MOOD.kit, hud: () => T < 19.5 ? ['MAGEN VOLL', 'NACH CA. 10 BANANEN'] : ['RANDVOLL', 'NICHTS GEHT MEHR'],
    upd(lt){ dT = T; const n = 5 + Math.floor(5 * seg(T, 16.8, 19.4)); base(n); benAt(); const f = seg(T, 19.4, 19.9);
      if (f <= 0) eat(T, 1); else { ben.sh[1].rotation.set(-1.4 * (1 - f) - 0.3, 0, 0.6 * f); ben.el[1].rotation.x = -0.3; HB.visible = false; ben.sh[0].rotation.set(-0.6 * f, 0, -0.2); bFace(ben, -0.8, 0.5); }
      belly(0.35 + 0.65 * seg(T, 16.8, 19.4)); eyeS = 1.0 + 0.3 * f; ben.torso.rotation.x = -0.08 * f; stoK = E.out(seg(T, 16.9, 17.2)) * (1 - seg(T, 20.55, 20.7));
      camW(E.io(seg(lt, 0, 4.02)), [1.8, 2.9, 6.6, 0.3, 2.1, 0.2, 46], [1.4, 2.8, 5.8, 0.3, 2.1, 0.2, 46]); camFin(); } },
  { t: 20.7, set: KIT, mood: MOOD.kit, hud: () => ['UND DER REST?', 'BANANENBROT!'],
    upd(lt){ dT = T; base(10, T > 21.4); benAt(); belly(1); if (T > 21.4){ eat(T, 0.6); bFace(ben, 1, 0.3); } else { ben.sh[1].rotation.set(-0.3, 0, 0.3); bFace(ben, 0.3, 0.2); } eyeS = 1.1;
      brdK = E.out(seg(T, 21.6, 21.9)) * (1 - seg(T, 23.15, 23.3));
      camW(E.io(seg(lt, 0, 2.6)), [0.9, 3.0, 6.6, -0.4, 2.0, 0.5, 46], [0.7, 2.9, 6.0, -0.4, 2.0, 0.5, 46]); camFin(); } },
  { t: 23.3, set: KIT, mood: MOOD.kit, loopin: 1,
    upd(lt){ dT = T - END; base(0); hookBen(T - END); camW(0, HOOK[0], HOOK[1]); camFin(); } },
];
const SUBS = __SUBS__;
