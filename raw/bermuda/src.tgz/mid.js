/* =========================================================
   STIMMUNG: Atlantik (Tag), Sturm, Sonne am Ende
   ========================================================= */
const MOOD = {
  sea: { bg: 0x7ab0d8, fog: [0x8ab8dc, 40, 160], hemi: [0xeef6ff, 0x2a5a7a, 0.85], sun: [0xfff2dc, 1.1] },
  myth: { bg: 0x5a6a7a, fog: [0x6a7a88, 18, 90], hemi: [0xd8e0e8, 0x2a3a4a, 0.8], sun: [0xe0e8f0, 0.6] },
  storm: { bg: 0x3a4652, fog: [0x46525e, 16, 80], hemi: [0xc0ccd8, 0x1a2a3a, 0.75], sun: [0xc8d0d8, 0.45] },
  sunny: { bg: 0x6ab8f0, fog: [0x8ac8f0, 50, 180], hemi: [0xfff8ee, 0x3a6a6a, 0.95], sun: [0xfff2d8, 1.25] } };
const SR = 16; { const c = sun.shadow.camera; c.left = -SR; c.right = SR; c.top = SR; c.bottom = -SR; c.near = 1; c.far = 120; c.updateProjectionMatrix(); }
function setMood(m){
  scene.background = new THREE.Color(m.bg); scene.fog.color.set(m.fog[0]); scene.fog.near = m.fog[1]; scene.fog.far = m.fog[2]; scene.environment = envDay;
  hemi.color.set(m.hemi[0]); hemi.groundColor.set(m.hemi[1]); hemi.intensity = m.hemi[2]; sun.color.set(m.sun[0]); sun.intensity = m.sun[1];
  sun.position.set(-10, 28, 16); sun.target.position.set(0, 0, 0); fill.color.set(0xffffff); fill.intensity = 0.3; fill.position.set(10, 8, 20);
}

/* =========================================================
   SET: Ozean mit Wellen, Segelboot, Schiffe, Flugzeug, Insel
   ========================================================= */
const SEA = new THREE.Group(); scene.add(SEA); const SETS = [SEA];
const OG = new THREE.PlaneGeometry(240, 240, 90, 90); OG.rotateX(-PI / 2);
const OCEAN = new THREE.Mesh(OG, mat(0x2a7ab0, { roughness: 0.35, flatShading: true })); OCEAN.receiveShadow = true; SEA.add(OCEAN);
const OP = OG.attributes.position, OX = Float32Array.from(OP.array);
let waveA = 1;
function wh(x, z, t){ return waveA * (0.22 * Math.sin(x * 0.35 + t * 1.3) + 0.16 * Math.sin(z * 0.42 - t * 1.1) + 0.08 * Math.sin((x + z) * 0.9 + t * 2.0)); }
function waves(t){ for (let i = 0; i < OP.count; i++){ const x = OX[i * 3], z = OX[i * 3 + 2]; OP.array[i * 3 + 1] = wh(x, z, t); } OP.needsUpdate = true; OG.computeVertexNormals(); }
// Segelboot
const BOAT = new THREE.Group(); SEA.add(BOAT);
(function(){ const hw = mat(0xf2f2f2, { roughness: 0.5 }), hb = mat(0x2a4a8a, { roughness: 0.5 }), wd = mat(0xb08050);
  P(BOAT, rbox(4.2, 0.6, 1.8, 0.25), hw, 0, 0.15, 0); P(BOAT, rbox(4.0, 0.25, 1.7, 0.1), hb, 0, -0.12, 0); P(BOAT, rbox(1.2, 0.5, 1.3, 0.2), hw, 2.0, 0.15, 0).rotation.y = PI / 4;
  P(BOAT, rbox(3.6, 0.06, 1.5, 0.02, 1), wd, -0.1, 0.47, 0); P(BOAT, new THREE.CylinderGeometry(0.07, 0.08, 5.6, 8), mat(0xd8d8d8, { metalness: 0.5 }), 0.6, 3.2, 0);
  const s = new THREE.Shape(); s.moveTo(0, 0); s.lineTo(0, 4.8); s.lineTo(-2.4, 0); s.closePath(); const sl = new THREE.Mesh(new THREE.ShapeGeometry(s), mat(0xfaf6ee, { side: THREE.DoubleSide, roughness: 0.8 })); sl.position.set(0.5, 0.8, 0.02); BOAT.add(sl);
  P(BOAT, rbox(2.6, 0.08, 0.08, 0.02, 1), mat(0xd8d8d8), -0.7, 0.85, 0); })();
// Frachter (Vorlage)
function freighter(par, op){ const g = new THREE.Group(); const o = op ? { transparent: true, opacity: 1, depthWrite: false } : {};
  const m1 = new THREE.MeshStandardMaterial(Object.assign({ color: 0x8a2a24, roughness: 0.6 }, o)), m2 = new THREE.MeshStandardMaterial(Object.assign({ color: 0x1a1a20, roughness: 0.6 }, o)), m3 = new THREE.MeshStandardMaterial(Object.assign({ color: 0xf2f2f2, roughness: 0.5 }, o));
  P(g, rbox(14, 1.6, 3.0, 0.3), m1, 0, 0.6, 0); P(g, rbox(14, 0.6, 3.0, 0.1), m2, 0, -0.3, 0); P(g, rbox(2.2, 2.6, 2.6, 0.1), m3, -5.6, 2.6, 0);
  const cc = [0x2a6ab0, 0xd8a030, 0x3a8a4a, 0xc84a3a];
  for (let i = 0; i < 6; i++) for (let j = 0; j < 2; j++) P(g, rbox(1.4, 1.0, 1.2, 0.04), new THREE.MeshStandardMaterial(Object.assign({ color: cc[(i + j) % 4], roughness: 0.7 }, o)), -3.2 + i * 1.6, 1.9 + j * 1.0, (j ? 0.6 : -0.6));
  par.add(g); g.userData.mats = [m1, m2, m3]; g.traverse(c => { if (c.material && c.material.transparent && !g.userData.mats.includes(c.material)) g.userData.mats.push(c.material); }); return g; }
function plane(par, op){ const g = new THREE.Group(); const o = op ? { transparent: true, opacity: 1, depthWrite: false } : {};
  const m = new THREE.MeshStandardMaterial(Object.assign({ color: 0xe8e8ee, roughness: 0.4, metalness: 0.2 }, o)), t = new THREE.MeshStandardMaterial(Object.assign({ color: 0x2a5aa0, roughness: 0.5 }, o));
  const f = P(g, new THREE.CylinderGeometry(0.5, 0.4, 7, 12), m, 0, 0, 0); f.rotation.z = PI / 2; P(g, rbox(1.8, 0.12, 8.0, 0.05), m, 0.2, -0.1, 0); P(g, rbox(0.9, 0.1, 2.8, 0.04), m, -3.0, 0.1, 0); P(g, rbox(1.0, 1.6, 0.12, 0.04), t, -3.1, 0.9, 0);
  par.add(g); g.userData.mats = [m, t]; return g; }
const GHOST = freighter(SEA, true), GPLANE = plane(SEA, true);
const SHIPS = []; [[-30, -40, 0.2], [26, -55, -0.4], [-8, -75, 0.9], [40, -20, 1.6], [-45, -10, -1.2], [12, 25, 0.5]].forEach(([x, z, r]) => { const s = freighter(SEA); s.position.set(x, 0, z); s.rotation.y = r; s.userData.base = [x, z, r]; SHIPS.push(s); });
const PLANES = []; for (let i = 0; i < 3; i++){ const p = plane(SEA); p.scale.setScalar(1.3); PLANES.push(p); }
// Strömungspfeile (Golfstrom)
const ARR = []; { const am = new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.55, fog: false, depthWrite: false });
  for (let i = 0; i < 12; i++){ const s = new THREE.Shape(); s.moveTo(0, 0.5); s.lineTo(1.6, 0); s.lineTo(0, -0.5); s.lineTo(0.4, 0); s.closePath(); const a = new THREE.Mesh(new THREE.ShapeGeometry(s), am); a.rotation.x = -PI / 2; SEA.add(a); ARR.push(a); } }
function arrows(on, t){ ARR.forEach((a, i) => { a.visible = on; if (!on) return; const x = -14 + ((t * 2.4 + i * 9.3) % 28), z = -3 - (i % 4) * 2.6 + (i % 2) * 1.2; a.position.set(x, wh(x, z, t) + 0.15, z); }); }
// Sturmwolken
const CLOUDS = new THREE.Group(); SEA.add(CLOUDS); { const cm = new THREE.MeshStandardMaterial({ color: 0x4a525a, roughness: 1, fog: false }); for (let i = 0; i < 24; i++){ const c = new THREE.Mesh(new THREE.SphereGeometry(4 + hsh(i) * 4, 12, 8), cm); c.position.set((hsh(i + 2) - 0.5) * 70, 20 + hsh(i + 3) * 5, -10 - hsh(i + 4) * 50); c.scale.y = 0.45; CLOUDS.add(c); } }
// Insel Bermuda: Steg, Pastellhäuser mit weißen Dächern, Palmen
const ISLE = new THREE.Group(); SEA.add(ISLE); ISLE.position.set(-3, 0, -6);
(function(){ const sd = mat(0xe8d8a8, { roughness: 1 }), gr = mat(0x5aa04a, { roughness: 1 }), wd = mat(0x9a7048);
  P(ISLE, new THREE.CylinderGeometry(12, 13, 1.2, 28), sd, -9, 0.1, -12); P(ISLE, new THREE.CylinderGeometry(10, 11, 1.4, 28), gr, -10, 0.3, -13);
  P(ISLE, rbox(1.6, 0.2, 7, 0.04), wd, 1.2, 0.7, -1.6); for (let i = 0; i < 4; i++) [-1, 1].forEach(s => P(ISLE, new THREE.CylinderGeometry(0.1, 0.1, 1.6, 6), wd, 1.2 + s * 0.7, 0.0, 1.2 - i * 2));
  const pc = [0xf2a8c0, 0x8ad0e8, 0xf2e08a, 0xa8e0a8]; [[-6, -8], [-9, -6], [-12, -10], [-8, -13]].forEach(([x, z], i) => { P(ISLE, rbox(2.4, 1.8, 2.2, 0.06), mat(pc[i], { roughness: 0.8 }), x, 1.9, z); const r = P(ISLE, new THREE.ConeGeometry(1.9, 1.0, 4), mat(0xffffff, { roughness: 0.7 }), x, 3.3, z); r.rotation.y = PI / 4; });
  const tk = mat(0x8a6a44), lf = mat(0x2f8a3a, { roughness: 0.8, flatShading: true }); [[-3, -8], [-14, -8]].forEach(([x, z]) => { for (let k = 0; k < 6; k++) P(ISLE, new THREE.CylinderGeometry(0.18, 0.22, 0.8, 6), tk, x + k * k * 0.03, 1.4 + k * 0.78, z);
    for (let k = 0; k < 5; k++){ const l = P(ISLE, rbox(0.5, 0.08, 2.4, 0.04), lf, x + 0.75 + Math.cos(k * 1.26), 5.9, z + Math.sin(k * 1.26)); l.rotation.y = -k * 1.26 + PI / 2; l.rotation.x = 0.35; } });
})();

/* =========================================================
   BEN: Narbe, Fernglas
   ========================================================= */
const SCAR = new THREE.Group(); ben.head.add(SCAR);
(function(){ const m = mat(0xa8463f, { roughness: 0.7 }); const s = new THREE.Mesh(rbox(0.075, 0.72, 0.03, 0.012, 1), m); s.position.set(0.25, 0.55, 0.522); s.rotation.z = -0.13; SCAR.add(s);
  for (const y of [0.36, 0.55, 0.74]){ const c = new THREE.Mesh(rbox(0.16, 0.035, 0.03, 0.01, 1), m); c.position.set(0.25 + (y - 0.55) * 0.13, y, 0.528); c.rotation.z = -0.13; SCAR.add(c); } })();
const BINO = new THREE.Group(); ben.head.add(BINO); { const bm = mat(0x1a1a20, { roughness: 0.4 }); [-1, 1].forEach(s => { const c = P(BINO, new THREE.CylinderGeometry(0.12, 0.14, 0.42, 10), bm, s * 0.22, 0.58, 0.74); c.rotation.x = PI / 2; }); }

/* =========================================================
   KAMERA + Zustand
   ========================================================= */
const cL = new THREE.Vector3();
let blurAmt = 0, fadeBlk = 0, T = 0, flashA = 0, eyeS = 1, talk = 0, dT = 0;
let statK = 0, mapK = 0, gefK = 0, mythK = 0;
function camW(p, a, b){ cam.position.set(lerp(a[0], b[0], p), lerp(a[1], b[1], p), lerp(a[2], b[2], p)); cL.set(lerp(a[3], b[3], p), lerp(a[4], b[4], p), lerp(a[5], b[5], p)); cam.fov = lerp(a[6], b[6], p); }
function camFin(sh){ cam.position.x += Math.sin(dT * 0.7) * 0.03; cam.position.y += Math.sin(dT * 0.9 + 1) * 0.02; if (sh){ cam.position.x += Math.sin(T * 5.3) * sh; cam.position.y += Math.cos(T * 4.1) * sh; } cam.up.set(0, 1, 0); cam.lookAt(cL); cam.updateProjectionMatrix(); cam.updateMatrixWorld(); }
const HOOK = [[5.6, 3.4, 8.8, 0, 2.0, 0, 48], [5.3, 3.3, 8.4, 0, 2.0, 0, 48]];
function base(t, amp){ show(ben); waveA = amp; waves(t); const y = wh(0, 0, t); BOAT.position.set(0, y + 0.05, 0); BOAT.rotation.set(0.05 * Math.sin(t * 1.1) * amp, 0, 0.04 * Math.sin(t * 1.3 + 1) * amp);
  GHOST.visible = false; GPLANE.visible = false; SHIPS.forEach(s => s.visible = false); PLANES.forEach(p => p.visible = false); arrows(false, t); CLOUDS.visible = false; ISLE.visible = false; BINO.visible = false; }
function benBoat(t){ bRest(ben, t, 0); ben.root.position.set(-0.6, BOAT.position.y + 0.5, 0.1); ben.root.rotation.set(BOAT.rotation.x, 0.15, BOAT.rotation.z); }
function hookBen(t){ benBoat(t); BINO.visible = true; ben.sh[0].rotation.set(-2.3, 0, 0.5); ben.sh[1].rotation.set(-2.3, 0, -0.5); ben.el[0].rotation.x = -1.4; ben.el[1].rotation.x = -1.4; ben.head.rotation.y = 0.4 * Math.sin(t * 0.8); bFace(ben, -0.5, 0.15); CLOUDS.visible = true; }

/* =========================================================
   SZENEN (Sprecherspur Tempo 1,05)
   ========================================================= */
const SCN = [
  { t: 0, set: SEA, mood: MOOD.myth, hook: 1,
    upd(lt){ dT = T; base(T, 1); hookBen(T); camW(E.io(seg(lt, 0, 3.78)), HOOK[0], [4.6, 3.0, 7.4, 0, 2.2, 0, 48]); camFin(); } },
  { t: 3.78, set: SEA, mood: MOOD.myth, hud: () => ['DER MYTHOS', 'SCHIFFE UND FLUGZEUGE WEG?'],
    upd(lt){ dT = T; base(T, 1); benBoat(T); ben.root.rotation.y = -0.6; eyeS = 1.4; bFace(ben, -0.9, 0.5); ben.sh[1].rotation.set(-1.4, 0, -0.2);
      GHOST.visible = true; GHOST.position.set(10 - T * 0.4, wh(10, -24, T), -24); GHOST.rotation.y = 0.1; const go = 1 - seg(T, 5.0, 6.6); GHOST.userData.mats.forEach(m => m.opacity = go); GHOST.visible = go > 0.01;
      GPLANE.visible = true; GPLANE.position.set(-16 + T * 3.0, 15, -30); const po = 1 - seg(T, 5.8, 7.1); GPLANE.userData.mats.forEach(m => m.opacity = po); GPLANE.visible = po > 0.01; CLOUDS.visible = true;
      camW(E.io(seg(lt, 0, 3.54)), [-4.0, 3.2, 6.4, 2.0, 5.0, -24, 50], [-3.4, 3.0, 6.0, 2.0, 5.5, -24, 50]); camFin(); } },
  { t: 7.32, set: SEA, mood: MOOD.sea, hud: () => ['DIE STATISTIK', 'NICHT MEHR UNFÄLLE ALS ANDERSWO'],
    upd(lt){ dT = T; base(T, 0.8); benBoat(T); ben.sh[0].rotation.set(-0.3, 0, -1.0); ben.sh[1].rotation.set(-0.3, 0, 1.0); ben.el[0].rotation.x = -1.2; ben.el[1].rotation.x = -1.2; bFace(ben, 0.6, 0.15); eyeS = 1;
      statK = E.out(seg(T, 7.5, 7.8)) * (1 - seg(T, 11.0, 11.18));
      camW(E.io(seg(lt, 0, 3.86)), [3.4, 3.0, 6.2, -0.4, 2.4, 0, 46], [2.8, 2.9, 5.6, -0.4, 2.4, 0, 46]); camFin(); } },
  { t: 11.18, set: SEA, mood: MOOD.sea, hud: () => ['VIEL VERKEHR', 'EINE DER MEISTBEFAHRENEN ZONEN'],
    upd(lt){ dT = T; base(T, 0.8); benBoat(T); bFace(ben, 0.2, 0.1); SHIPS.forEach((s, i) => { const [x, z, r] = s.userData.base, v = 1.6; s.visible = true; s.position.set(x + Math.cos(r) * v * (T - 11), wh(x, z, T) * 0.3, z - Math.sin(r) * v * (T - 11)); });
      PLANES.forEach((p, i) => { p.visible = true; p.position.set(-40 + (T - 11) * 9 + i * 22, 22 + i * 3, -30 + i * 14); });
      mapK = E.out(seg(T, 11.4, 11.7)) * (1 - seg(T, 14.55, 14.72));
      camW(E.io(seg(lt, 0, 3.54)), [16, 28, 34, -2, 0, -14, 50], [12, 30, 30, -2, 0, -16, 50]); camFin(); } },
  { t: 14.72, set: SEA, mood: MOOD.storm, hud: () => ['ECHTE GEFAHR', 'STÜRME UND GOLFSTROM'],
    upd(lt){ dT = T; base(T, 2.2); benBoat(T); CLOUDS.visible = true; arrows(true, T); ben.sh[0].rotation.set(-0.9, 0, -0.6); ben.sh[1].rotation.set(-0.9, 0, 0.6); eyeS = 1.3; bFace(ben, -0.8, 0.4);
      gefK = E.out(seg(T, 14.9, 15.2)) * (1 - seg(T, 17.9, 18.06));
      camW(E.io(seg(lt, 0, 3.34)), [5.6, 3.6, 9.0, 0, 1.8, -1, 50], [4.8, 3.2, 8.2, 0, 1.8, -1, 50]); camFin(0.05); } },
  { t: 18.06, set: SEA, mood: MOOD.sunny, hud: () => T < 20.4 ? ['UND BEN?', 'KOMMT GANZ NORMAL AN'] : ['ETWAS ENTTÄUSCHT', 'KEIN MYSTERIUM'],
    upd(lt){ dT = T; base(T, 0.4); ISLE.visible = true; benBoat(T); ben.root.rotation.y = 0.4; const sh = seg(T, 20.5, 20.9) * (1 - seg(T, 21.9, 22.3));
      ben.sh[0].rotation.set(-0.3 * sh, 0, -0.07 - 0.9 * sh); ben.sh[1].rotation.set(-0.3 * sh, 0, 0.07 + 0.9 * sh); ben.el[0].rotation.x = -1.2 * sh; ben.el[1].rotation.x = -1.2 * sh; ben.head.rotation.z = 0.15 * sh;
      bFace(ben, T < 20.4 ? 0.6 : -0.3, 0.1); eyeS = T < 20.4 ? 1 : 0.7; mythK = E.out(seg(T, 20.6, 20.9)) * (1 - seg(T, 22.25, 22.4));
      camW(E.io(seg(lt, 0, 4.34)), [5.6, 3.4, 8.0, -1.2, 2.0, -1.5, 50], [4.6, 3.0, 6.8, -1.0, 2.0, -1.0, 48]); camFin(); } },
  { t: 22.4, set: SEA, mood: MOOD.myth, loopin: 1,
    upd(lt){ dT = T - END; base(T - END, 1); hookBen(T - END); camW(0, HOOK[0], HOOK[1]); camFin(); } },
];
const SUBS = __SUBS__;
