/* =========================================================
   STIMMUNG: Schlafzimmer (warm) + Park (Tag)
   ========================================================= */
const MOOD = { room: { bg: 0xe8dcc8, fog: [0xe8dcc8, 30, 100], hemi: [0xfff4e4, 0x8a7a68, 0.95], sun: [0xfff0d8, 0.9] },
  park: { bg: 0x8ac4f0, fog: [0x9ad0f4, 40, 160], hemi: [0xf4faff, 0x5a7a40, 0.9], sun: [0xfff2dc, 1.15] } };
const SR = 12; { const c = sun.shadow.camera; c.left = -SR; c.right = SR; c.top = SR; c.bottom = -SR; c.near = 1; c.far = 80; c.updateProjectionMatrix(); }
function setMood(m){
  scene.background = new THREE.Color(m.bg); scene.fog.color.set(m.fog[0]); scene.fog.near = m.fog[1]; scene.fog.far = m.fog[2]; scene.environment = envDay;
  hemi.color.set(m.hemi[0]); hemi.groundColor.set(m.hemi[1]); hemi.intensity = m.hemi[2]; sun.color.set(m.sun[0]); sun.intensity = m.sun[1];
  sun.position.set(8, 18, 10); sun.target.position.set(0, 0, 0); fill.color.set(0xffffff); fill.intensity = 0.35; fill.position.set(-8, 6, 14);
}

/* =========================================================
   SETS: Schlafzimmer mit Bett + Kalender, Park mit Weg
   ========================================================= */
const ROOM = new THREE.Group(); scene.add(ROOM);
const CAL = new THREE.Vector3(-1.6, 3.9, -2.75);
(function(){ const fl = new THREE.Mesh(new THREE.PlaneGeometry(40, 40), mat(0xa8784a, { roughness: 0.8 })); fl.rotation.x = -PI / 2; fl.receiveShadow = true; ROOM.add(fl);
  P(ROOM, rbox(16, 8, 0.3, 0.02, 1), mat(0xb8d0e0, { roughness: 1 }), 0, 4, -3); P(ROOM, rbox(0.3, 8, 16, 0.02, 1), mat(0xc8dcea, { roughness: 1 }), -4.5, 4, 3);
  const fr = mat(0x7a5232, { roughness: 0.7 }); P(ROOM, rbox(2.6, 0.5, 4.0, 0.06), fr, 0, 0.45, -0.6); P(ROOM, rbox(2.6, 2.2, 0.2, 0.06), fr, 0, 1.1, -2.6); P(ROOM, rbox(2.6, 1.0, 0.2, 0.06), fr, 0, 0.75, 1.4);
  P(ROOM, rbox(2.4, 0.4, 3.8, 0.12), mat(0xf4f4f0, { roughness: 0.9 }), 0, 0.9, -0.6); P(ROOM, rbox(1.4, 0.3, 0.8, 0.14), mat(0xffffff, { roughness: 0.9 }), 0, 1.25, -2.05);
  P(ROOM, rbox(1.3, 1.6, 0.06, 0.02, 1), mat(0xffffff), CAL.x, CAL.y, CAL.z - 0.05); P(ROOM, rbox(1.3, 0.35, 0.07, 0.02, 1), mat(0xd04030), CAL.x, CAL.y + 0.65, CAL.z - 0.04);
  P(ROOM, rbox(1.0, 1.1, 0.9, 0.05), fr, 2.2, 0.55, -2.0); P(ROOM, new THREE.CylinderGeometry(0.2, 0.25, 0.5, 12), mat(0xf2e2a0), 2.2, 1.35, -2.0);
  P(ROOM, rbox(2.2, 2.6, 0.12, 0.03, 1), mat(0x8ac8f0), 1.8, 4.2, -2.82); P(ROOM, rbox(2.4, 0.12, 0.16, 0.03, 1), mat(0xffffff), 1.8, 2.9, -2.8);
})();
const BLANKET = P(ROOM, rbox(2.5, 0.25, 2.6, 0.12), mat(0x3a6ab0, { roughness: 0.9 }), 0, 1.38, 0.1);
const WEB = new THREE.Group(); ROOM.add(WEB); { const wm = new THREE.LineBasicMaterial({ color: 0xf2f2f2, transparent: true, opacity: 0.7 }); const pts = []; for (let i = 0; i < 7; i++){ const a = i / 6 * PI / 2; pts.push(new THREE.Vector3(0, 0, 0), new THREE.Vector3(Math.cos(a) * 0.9, Math.sin(a) * 0.9, 0)); }
  for (let r = 0.25; r < 0.95; r += 0.22) for (let i = 0; i < 6; i++){ const a = i / 6 * PI / 2, b = (i + 1) / 6 * PI / 2; pts.push(new THREE.Vector3(Math.cos(a) * r, Math.sin(a) * r, 0), new THREE.Vector3(Math.cos(b) * r, Math.sin(b) * r, 0)); }
  const l = new THREE.LineSegments(new THREE.BufferGeometry().setFromPoints(pts), wm); WEB.add(l); WEB.position.set(-1.3, 0.75, -2.48); }
const PARK = new THREE.Group(); scene.add(PARK);
(function(){ const g = new THREE.Mesh(new THREE.PlaneGeometry(200, 200), mat(0x6aa850, { roughness: 1 })); g.rotation.x = -PI / 2; g.receiveShadow = true; PARK.add(g);
  const pm = new THREE.Mesh(new THREE.PlaneGeometry(200, 2.6), mat(0xd8c49a, { roughness: 1 })); pm.rotation.x = -PI / 2; pm.position.y = 0.01; PARK.add(pm);
  const tr = mat(0x5a3e28), lf = mat(0x3f8a3a, { roughness: 0.9, flatShading: true });
  for (let i = 0; i < 24; i++){ const x = -60 + i * 5 + hsh(i) * 2, z = (i % 2 ? -1 : 1) * (5 + hsh(i + 3) * 6); P(PARK, new THREE.CylinderGeometry(0.25, 0.35, 3, 6), tr, x, 1.5, z); P(PARK, new THREE.DodecahedronGeometry(1.7 + hsh(i) * 0.8, 0), lf, x, 3.7, z); }
  for (let i = 0; i < 8; i++){ const x = -30 + i * 8; P(PARK, rbox(2.0, 0.12, 0.6, 0.04), mat(0x9a6a3a), x, 0.8, -2.4); P(PARK, rbox(2.0, 0.6, 0.1, 0.03), mat(0x9a6a3a), x, 1.15, -2.7); }
})();
const SETS = [ROOM, PARK];

/* =========================================================
   BEN: Narbe, Handy
   ========================================================= */
const SCAR = new THREE.Group(); ben.head.add(SCAR);
(function(){ const m = mat(0xa8463f, { roughness: 0.7 }); const s = new THREE.Mesh(rbox(0.075, 0.72, 0.03, 0.012, 1), m); s.position.set(0.25, 0.55, 0.522); s.rotation.z = -0.13; SCAR.add(s);
  for (const y of [0.36, 0.55, 0.74]){ const c = new THREE.Mesh(rbox(0.16, 0.035, 0.03, 0.01, 1), m); c.position.set(0.25 + (y - 0.55) * 0.13, y, 0.528); c.rotation.z = -0.13; SCAR.add(c); } })();
const PHONE = P(ben.el[1], rbox(0.3, 0.06, 0.55, 0.04), mat(0x15151a, { roughness: 0.3 }), 0, -0.66, 0.15);
function thin(k){ [0, 1].forEach(i => { ben.sh[i].scale.set(1 - 0.3 * k, 1, 1 - 0.3 * k); ben.legs[i].scale.set(1 - 0.25 * k, 1, 1 - 0.25 * k); }); }
// Ben liegt auf dem Rücken, Kopf Richtung Kissen (−z)
function lie(t){ bRest(ben, t, 0); place(ben, 0, 1.38, 1.15, 0); ben.root.rotation.x = -PI / 2; ben.head.rotation.x = 0.35; ben.sh[0].rotation.set(0.2, 0, -0.15); ben.sh[1].rotation.set(0.2, 0, 0.15); }
function phoneUp(t){ ben.sh[1].rotation.set(-0.9, 0, 0.25); ben.el[1].rotation.x = -1.5; PHONE.visible = true; }

/* =========================================================
   KAMERA + Zustand
   ========================================================= */
const cL = new THREE.Vector3();
let blurAmt = 0, fadeBlk = 0, T = 0, flashA = 0, eyeS = 1, talk = 0, dT = 0;
let musK = 0, boneK = 0, hrtK = 0, dizK = 0, walkK = 0, calK = 0, calTxt = '';
function camW(p, a, b){ cam.position.set(lerp(a[0], b[0], p), lerp(a[1], b[1], p), lerp(a[2], b[2], p)); cL.set(lerp(a[3], b[3], p), lerp(a[4], b[4], p), lerp(a[5], b[5], p)); cam.fov = lerp(a[6], b[6], p); }
function camFin(sh){ cam.position.x += Math.sin(dT * 0.7) * 0.03; cam.position.y += Math.sin(dT * 0.9 + 1) * 0.02; if (sh){ cam.position.x += Math.sin(T * 5) * sh; cam.position.y += Math.cos(T * 4) * sh; } cam.up.set(0, 1, 0); cam.lookAt(cL); cam.updateProjectionMatrix(); cam.updateMatrixWorld(); }
const HOOK = [[4.4, 4.6, 4.6, -0.2, 1.6, -0.4, 50], [4.2, 4.5, 4.4, -0.2, 1.6, -0.4, 50]];
function base(){ show(ben); PHONE.visible = false; thin(0); WEB.visible = false; BLANKET.visible = true; calK = 1; }
function hookBen(t){ lie(t); phoneUp(t); eyeS = 0.9; bFace(ben, 0.3, 0.1); calTxt = 'TAG 1'; }

/* =========================================================
   SZENEN (Sprecherspur Tempo 1,0)
   ========================================================= */
const SCN = [
  { t: 0, set: ROOM, mood: MOOD.room, hook: 1,
    upd(lt){ dT = T; base(); hookBen(T); camW(E.io(seg(lt, 0, 3.9)), HOOK[0], [3.6, 4.2, 3.8, -0.2, 1.6, -0.6, 50]); camFin(); } },
  { t: 3.9, set: ROOM, mood: MOOD.room, hud: () => ['1 WOCHE', 'DIE MUSKELN SCHWINDEN'],
    upd(lt){ dT = T; base(); lie(T); const k = seg(T, 4.2, 6.4); thin(0.5 * k); eyeS = 1; bFace(ben, -0.3, 0.1); calTxt = 'TAG ' + (1 + Math.round(6 * k)); musK = E.out(seg(T, 4.1, 4.4)) * (1 - seg(T, 6.55, 6.7));
      camW(E.io(seg(lt, 0, 2.8)), [2.6, 3.2, 2.6, 0, 1.5, 0.2, 46], [2.3, 3.0, 2.2, 0, 1.5, 0.0, 46]); camFin(); } },
  { t: 6.7, set: ROOM, mood: MOOD.room, hud: () => T < 10.1 ? ['KNOCHEN', 'CA. 1 % WENIGER PRO MONAT'] : ['WIE IM ALL', 'ASTRONAUTEN GEHT ES GENAUSO'],
    upd(lt){ dT = T; base(); lie(T); thin(0.6); phoneUp(T); eyeS = 0.8; bFace(ben, 0, 0.05); calTxt = 'MONAT ' + (1 + Math.floor(5.99 * seg(T, 6.9, 12.2))); boneK = E.out(seg(T, 6.9, 7.2)) * (1 - seg(T, 12.4, 12.56));
      camW(E.io(seg(lt, 0, 5.86)), [-2.8, 4.4, 4.6, 0, 1.4, -0.6, 50], [-1.8, 4.0, 4.2, 0, 1.4, -0.6, 50]); camFin(); } },
  { t: 12.56, set: ROOM, mood: MOOD.room, hud: () => ['DAS HERZ', 'WIRD KLEINER UND SCHWÄCHER'],
    upd(lt){ dT = T; base(); lie(T); thin(0.75); eyeS = 0.7; bFace(ben, -0.4, 0.05); calTxt = 'MONAT 9'; WEB.visible = true; hrtK = E.out(seg(T, 12.7, 13.0)) * (1 - seg(T, 15.0, 15.16));
      camW(E.io(seg(lt, 0, 2.6)), [1.6, 3.4, 3.6, 0, 1.6, -1.0, 44], [1.3, 3.2, 3.2, 0, 1.6, -1.2, 44]); camFin(); } },
  { t: 15.16, set: ROOM, mood: MOOD.room, hud: () => ['NACH 1 JAHR', 'KAUM NOCH STEHEN'],
    upd(lt){ dT = T; base(); WEB.visible = true; thin(0.85); bRest(ben, T, 0); calTxt = 'TAG 365';
      const up = bump(T, 15.7, 17.3) ; place(ben, 1.55 + 0.25 * up, 0, -0.6, PI / 2); if (up < 0.5){ sit(ben, 1.1 - 0.0); } ben.body.position.y = lerp(1.28, 1.0, up); ben.legs[0].rotation.x = lerp(-1.5, -0.25, up); ben.legs[1].rotation.x = lerp(-1.5, -0.15, up);
      ben.torso.rotation.z = 0.18 * Math.sin(T * 6) * up; ben.torso.rotation.x = 0.25 * (1 - up) + 0.1 * up; ben.sh[0].rotation.set(-0.3, 0, -0.7 * up); ben.sh[1].rotation.set(-0.3, 0, 0.7 * up);
      eyeS = 1.3; bFace(ben, -0.9, 0.35); dizK = E.out(seg(T, 15.4, 15.7)) * (1 - seg(T, 17.9, 18.06));
      camW(E.io(seg(lt, 0, 2.9)), [6.4, 3.4, 4.2, 1.6, 2.0, -0.6, 48], [5.8, 3.2, 3.6, 1.6, 2.0, -0.6, 48]); camFin(0.02 * up); } },
  { t: 18.06, set: PARK, mood: MOOD.park, hud: () => ['UND BEN?', 'GEHT JEDEN TAG SPAZIEREN'],
    upd(lt){ dT = T; show(ben); PHONE.visible = false; thin(0); calK = 0; bRest(ben, T, 0); const x = -4 + (T - 18.06) * 1.8; place(ben, x, 0, 0.2, PI / 2); wlk(ben, T * 7, 1); eyeS = 1; bFace(ben, 1, 0.2);
      walkK = E.out(seg(T, 18.4, 18.7)) * (1 - seg(T, 20.95, 21.1));
      camW(E.io(seg(lt, 0, 3.04)), [x - 1.2, 2.8, 7.0, x + 0.6, 2.0, 0, 46], [x - 0.6, 2.8, 6.8, x + 0.8, 2.0, 0, 46]); camFin(); } },
  { t: 21.1, set: ROOM, mood: MOOD.room, loopin: 1,
    upd(lt){ dT = T - END; base(); hookBen(T - END); camW(0, HOOK[0], HOOK[1]); camFin(); } },
];
const SUBS = __SUBS__;
