/* =========================================================
   STIMMUNG: Flughafen, Tag
   ========================================================= */
function sky(stops){
  const c = document.createElement('canvas'); c.width = 4; c.height = 256; const x = c.getContext('2d'), g = x.createLinearGradient(0, 0, 0, 256);
  stops.forEach(s => g.addColorStop(s[0], s[1])); x.fillStyle = g; x.fillRect(0, 0, 4, 256); const t = new THREE.CanvasTexture(c); t.encoding = THREE.sRGBEncoding; return t;
}
const MOOD = { day: { sky: sky([[0, '#3a86d8'], [0.6, '#92c6f0'], [1, '#e2f0fa']]), fog: [0xd8eaf6, 80, 320], hemi: [0xeaf4ff, 0x707060, 0.85], sun: [0xfff2e0, 1.3] } };
const SR = 30; { const c = sun.shadow.camera; c.left = -SR; c.right = SR; c.top = SR; c.bottom = -SR; c.near = 1; c.far = 200; c.updateProjectionMatrix(); }
function setMood(m){
  scene.background = m.sky; scene.fog.color.set(m.fog[0]); scene.fog.near = m.fog[1]; scene.fog.far = m.fog[2]; scene.environment = envDay;
  hemi.color.set(m.hemi[0]); hemi.groundColor.set(m.hemi[1]); hemi.intensity = m.hemi[2]; sun.color.set(m.sun[0]); sun.intensity = m.sun[1];
  sun.position.set(-30, 60, 40); sun.target.position.set(0, 0, -8); fill.color.set(0xffffff); fill.intensity = 0.3; fill.position.set(20, 10, 40);
}

/* =========================================================
   SET: Vorfeld (Ben bei z = 0), Startbahn entlang x bei z = -16
   ========================================================= */
const AIR = new THREE.Group(); scene.add(AIR); const SETS = [AIR];
const RZ = -16;
(function(){
  const gr = mat(0x6f9a48, { roughness: 1 }), ap = mat(0x9a9a96, { roughness: 0.95 }), rw = mat(0x4a4a4e, { roughness: 0.9 }), wh = mat(0xf2f2f2), ye = mat(0xf2c21a);
  const g = new THREE.Mesh(new THREE.PlaneGeometry(800, 800), gr); g.rotation.x = -PI / 2; g.receiveShadow = true; AIR.add(g);
  const a = new THREE.Mesh(new THREE.PlaneGeometry(800, 16), ap); a.rotation.x = -PI / 2; a.position.set(0, 0.01, 2); a.receiveShadow = true; AIR.add(a);
  const r = new THREE.Mesh(new THREE.PlaneGeometry(800, 12), rw); r.rotation.x = -PI / 2; r.position.set(0, 0.015, RZ); r.receiveShadow = true; AIR.add(r);
  for (let i = -40; i <= 40; i++) P(AIR, new THREE.BoxGeometry(5, 0.02, 0.4), wh, i * 10, 0.03, RZ);
  [RZ - 5.6, RZ + 5.6].forEach(z => P(AIR, new THREE.BoxGeometry(800, 0.02, 0.25), wh, 0, 0.03, z));
  P(AIR, new THREE.BoxGeometry(800, 0.02, 0.2), ye, 0, 0.03, -5.9);
  // Terminal + Tower weit hinten
  const tm = mat(0xdadfe6, { roughness: 0.6 }), gl = mat(0x6aa8d8, { roughness: 0.1, metalness: 0.4 });
  P(AIR, new THREE.BoxGeometry(160, 14, 20), tm, 40, 7, -110); P(AIR, new THREE.BoxGeometry(160, 5, 0.4), gl, 40, 8, -99.8);
  P(AIR, new THREE.CylinderGeometry(2.5, 3.2, 40, 10), tm, -40, 20, -100); P(AIR, new THREE.CylinderGeometry(6, 4, 6, 10), gl, -40, 42, -100);
  // Pylonen + Befeuerung am Bahnrand
  const cn = mat(0xf26a1a); for (let i = -6; i <= 6; i++) P(AIR, new THREE.ConeGeometry(0.25, 0.8, 8), cn, i * 3.5, 0.4, -4.2);
  const lm = new THREE.MeshBasicMaterial({ color: 0xfff6c0 }); for (let i = -40; i <= 40; i++) P(AIR, new THREE.SphereGeometry(0.15, 6, 4), lm, i * 6, 0.2, RZ + 6.3);
})();
// Düsenjet (Länge ~32 Einheiten), Nase zeigt nach +x
const JET = new THREE.Group(); AIR.add(JET); const JB = new THREE.Group(); JET.add(JB);
(function(){ const w = mat(0xf4f6f8, { roughness: 0.35, metalness: 0.2 }), bl = mat(0x1f4fa0, { roughness: 0.4 }), dk = mat(0x2a2e36, { metalness: 0.5, roughness: 0.4 }), win = mat(0x1a2436, { roughness: 0.1 });
  const f = new THREE.Mesh(new THREE.CylinderGeometry(1.9, 1.9, 26, 20), w); f.rotation.z = PI / 2; JB.add(f);
  const n = new THREE.Mesh(new THREE.SphereGeometry(1.9, 20, 14, 0, PI * 2, 0, PI / 2), w); n.rotation.z = -PI / 2; n.scale.set(1, 2.2, 1); n.position.x = 13; JB.add(n);
  const tl = new THREE.Mesh(new THREE.ConeGeometry(1.9, 6, 20), w); tl.rotation.z = PI / 2; tl.position.set(-16, 0.5, 0); JB.add(tl);
  P(JB, new THREE.BoxGeometry(24, 0.3, 0.05), win, 0, 0.7, 1.9); P(JB, new THREE.BoxGeometry(24, 0.3, 0.05), win, 0, 0.7, -1.9); P(JB, new THREE.BoxGeometry(26, 0.5, 0.05), bl, 0, -0.2, 1.91);
  const wg = new THREE.Shape(); wg.moveTo(0, 0); wg.lineTo(-4.5, 15); wg.lineTo(-7, 15); wg.lineTo(-6.5, 0); const wgeo = new THREE.ExtrudeGeometry(wg, { depth: 0.35, bevelEnabled: false });
  [1, -1].forEach(s => { const m = new THREE.Mesh(wgeo, w); m.rotation.x = s > 0 ? -PI / 2 : PI / 2; m.position.set(3, -0.9, 0); m.castShadow = true; JB.add(m);
    const e = new THREE.Mesh(new THREE.CylinderGeometry(0.95, 0.85, 4.2, 16), dk); e.rotation.z = PI / 2; e.position.set(0.5, -2.0, s * 5.2); JB.add(e);
    const h = new THREE.Mesh(new THREE.CircleGeometry(0.75, 16), new THREE.MeshBasicMaterial({ color: 0xffa040 })); h.rotation.y = -PI / 2; h.position.set(-1.62, -2.0, s * 5.2); JB.add(h); });
  const fin = new THREE.Shape(); fin.moveTo(0, 0); fin.lineTo(-4, 7); fin.lineTo(-6, 7); fin.lineTo(-5, 0); const fm = new THREE.Mesh(new THREE.ExtrudeGeometry(fin, { depth: 0.3, bevelEnabled: false }), bl); fm.position.set(-13, 1.5, -0.15); JB.add(fm);
  [1, -1].forEach(s => { const m = new THREE.Mesh(new THREE.BoxGeometry(3, 0.25, 5), w); m.position.set(-17, 1.0, s * 2.5); JB.add(m); });
  [[7, 0], [0, 3], [0, -3]].forEach(([x, z]) => { rod(JB, dk, [x, -1.8, z], [x, -2.9, z], 0.18); P(JB, new THREE.CylinderGeometry(0.55, 0.55, 0.45, 12), dk, x, -3.2, z).rotation.x = PI / 2; });
  JB.traverse(o => { if (o.isMesh) o.castShadow = true; }); JB.position.y = 3.75; })();
// Start: x(t) = X0 + v0 t + a/2 t², ab XL hebt die Nase und steigt
function jetAt(t, X0, v0, acc){ const x = X0 + v0 * t + 0.5 * acc * t * t, XL = 30, k = Math.max(0, x - XL);
  JET.position.set(x, k * 0.09 + k * k * 0.0016, RZ); JET.rotation.z = Math.min(0.14, k * 0.004); return x; }

/* =========================================================
   BEN: Narbe, Gehörschutz
   ========================================================= */
const SCAR = new THREE.Group(); ben.head.add(SCAR);
(function(){ const m = mat(0xa8463f, { roughness: 0.7 }); const s = new THREE.Mesh(rbox(0.075, 0.72, 0.03, 0.012, 1), m); s.position.set(0.25, 0.55, 0.522); s.rotation.z = -0.13; SCAR.add(s);
  for (const y of [0.36, 0.55, 0.74]){ const c = new THREE.Mesh(rbox(0.16, 0.035, 0.03, 0.01, 1), m); c.position.set(0.25 + (y - 0.55) * 0.13, y, 0.528); c.rotation.z = -0.13; SCAR.add(c); } })();
const MUFF = new THREE.Group(); ben.head.add(MUFF);
(function(){ const o = mat(0xf27a1a, { roughness: 0.5 }), k = mat(0x2a2a2e); [-1, 1].forEach(s => { P(MUFF, rbox(0.22, 0.52, 0.48, 0.1), o, s * 0.68, 0.48, -0.02); P(MUFF, rbox(0.06, 0.4, 0.36, 0.03), k, s * 0.58, 0.48, -0.02); });
  const b = new THREE.Mesh(new THREE.TorusGeometry(0.72, 0.07, 8, 24, PI), k); b.position.set(0, 0.5, -0.02); MUFF.add(b); })();
function earsCover(k){ ben.sh[0].rotation.set(-0.35 * k, 0, -2.75 * k - 0.07 * (1 - k)); ben.sh[1].rotation.set(-0.35 * k, 0, 2.75 * k + 0.07 * (1 - k)); ben.el[0].rotation.x = -0.1 - 1.2 * k; ben.el[1].rotation.x = -0.1 - 1.2 * k; }

/* =========================================================
   KAMERA + Zustand
   ========================================================= */
const cL = new THREE.Vector3();
let blurAmt = 0, fadeBlk = 0, T = 0, flashA = 0, eyeS = 1, talk = 0, dT = 0;
let dbK = 0, dbV = 0, waveK = 0, painK = 0, muffK = 0;
function camW(p, a, b){ cam.position.set(lerp(a[0], b[0], p), lerp(a[1], b[1], p), lerp(a[2], b[2], p)); cL.set(lerp(a[3], b[3], p), lerp(a[4], b[4], p), lerp(a[5], b[5], p)); cam.fov = lerp(a[6], b[6], p); }
function camFin(sh){ cam.position.x += Math.sin(dT * 0.7) * 0.03; cam.position.y += Math.sin(dT * 0.9 + 1) * 0.02; if (sh){ cam.position.x += Math.sin(T * 23) * sh; cam.position.y += Math.cos(T * 17) * sh; } cam.up.set(0, 1, 0); cam.lookAt(cL); cam.updateProjectionMatrix(); cam.updateMatrixWorld(); }
const HOOK = [[4.0, 1.8, 9.0, -2.0, 3.0, -8.0, 52], [3.8, 1.8, 8.8, -1.6, 3.0, -8.0, 52]];
function base(){ show(ben); MUFF.visible = false; JET.visible = true; }
function standBen(t, yaw){ bRest(ben, t, 0); place(ben, 0, 0, 0, yaw); }
// Hook: Jet donnert bei t ≈ 1,3 s an Ben vorbei
function hookScene(t){ const x = jetAt(t, -95, 70, 0); standBen(t, -0.5 + 0.9 * seg(t, 0.3, 1.4)); const c = E.out(seg(t, 0.6, 1.0)); earsCover(c); eyeS = lerp(1.1, 0.35, c); bFace(ben, -0.9 * c, 0.5 * c); ben.torso.rotation.x = -0.12 * c;
  ben.head.rotation.y = -0.3 * (1 - seg(t, 0.3, 1.4)) + 0.4 * seg(t, 1.4, 2.4); waveK = clamp01(1 - Math.abs(x) / 70); return x; }

/* =========================================================
   SZENEN (Sprecherspur Tempo 1,05)
   ========================================================= */
const SCN = [
  { t: 0, set: AIR, mood: MOOD.day, hook: 1,
    upd(lt){ dT = T; base(); const x = hookScene(T); camW(E.io(seg(lt, 0, 3.9)), HOOK[0], [3.2, 1.9, 8.2, 0.4, 2.6, -6.0, 52]); camFin(0.05 * clamp01(1 - Math.abs(x) / 40)); } },
  { t: 3.9, set: AIR, mood: MOOD.day, hud: () => ['NORMALES GESPRÄCH', 'ETWA 60 DEZIBEL'],
    upd(lt){ dT = T; base(); JET.visible = false; standBen(T, 0.2); eyeS = 1.05; bFace(ben, 0.6, 0.1); dbK = E.out(seg(T, 4.1, 4.4)); dbV = 60 * E.out(seg(T, 4.3, 5.6));
      camW(E.io(seg(lt, 0, 2.88)), [2.6, 2.4, 6.8, 0, 2.0, 0, 46], [2.0, 2.3, 6.0, 0, 2.0, 0, 46]); camFin(); } },
  { t: 6.78, set: AIR, mood: MOOD.day, hud: () => ['AB 85 DEZIBEL', 'AUF DAUER SCHÄDLICH'],
    upd(lt){ dT = T; base(); JET.visible = false; standBen(T, -0.3); eyeS = 1.15; bFace(ben, -0.2, 0.1); ben.sh[1].rotation.set(-0.2, 0, 1.8 * seg(T, 8.0, 8.5)); ben.el[1].rotation.x = -1.4 * seg(T, 8.0, 8.5);
      dbK = 1; dbV = lerp(60, 85, E.io(seg(T, 6.9, 7.8)));
      camW(E.io(seg(lt, 0, 3.68)), [-3.0, 2.6, 6.4, 0, 2.2, 0, 44], [-2.4, 2.5, 5.6, 0, 2.3, 0, 44]); camFin(); } },
  { t: 10.46, set: AIR, mood: MOOD.day, hud: () => T < 15.3 ? ['STARTENDER JET', 'RUND 140 DEZIBEL'] : ['ÜBER DER SCHMERZGRENZE', 'GEHÖR KANN SOFORT SCHADEN NEHMEN'],
    upd(lt){ dT = T; base(); const tt = T - 10.46, x = jetAt(tt, -120, 60, 6); standBen(T, -0.4); const c = E.out(seg(tt, 0.6, 1.1)); earsCover(c); eyeS = lerp(1.2, 0.3, c); bFace(ben, -1, 0.6 * c); ben.torso.rotation.x = -0.15 * c; ben.legs[0].rotation.x = 0.15 * c;
      waveK = clamp01(1 - Math.abs(x) / 90) + 0.4 * seg(tt, 1, 2) * (1 - seg(T, 17.5, 18.8)); painK = clamp01(1 - Math.abs(x) / 50);
      dbK = 1; dbV = lerp(85, 140, E.io(seg(tt, 0.2, 2.2)));
      camW(E.io(seg(lt, 0, 8.42)), [5.0, 1.6, 8.0, -1.0, 3.2, -9.0, 56], [3.0, 1.9, 6.4, 1.5, 2.8, -6.0, 52]); camFin(0.07 * painK); } },
  { t: 18.88, set: AIR, mood: MOOD.day, hud: () => ['UND BEN?', 'MIT GEHÖRSCHUTZ'],
    upd(lt){ dT = T; base(); const tt = T - 18.88, x = jetAt(tt, -100, 75, 0); standBen(T, 0.1); MUFF.visible = true; eyeS = 1.05; bFace(ben, 1, 0.15);
      const th = seg(T, 20.2, 20.6); ben.sh[0].rotation.set(-1.4 * th, 0, -0.35 * th - 0.07); ben.el[0].rotation.x = -1.3 * th; muffK = E.out(seg(T, 20.0, 20.3)) * (1 - seg(T, 22.8, 22.95)); dbK = 1; dbV = lerp(140, 110, seg(T, 19.2, 20.4));
      camW(E.io(seg(lt, 0, 4.07)), [2.4, 2.2, 6.4, 0, 2.6, -2.0, 50], [3.4, 2.0, 7.6, 0, 2.8, -4.0, 52]); camFin(0.02 * clamp01(1 - Math.abs(x) / 40)); } },
  { t: 22.95, set: AIR, mood: MOOD.day, loopin: 1,
    upd(lt){ dT = T - END; base(); hookScene(T - END); camW(0, HOOK[0], HOOK[1]); camFin(); } },
];
const SUBS = __SUBS__;
