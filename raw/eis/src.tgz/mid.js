/* =========================================================
   STIMMUNG: Wintersee
   ========================================================= */
function sky(a, b, c){
  const cv = document.createElement('canvas'); cv.width = 4; cv.height = 512; const x = cv.getContext('2d'), g = x.createLinearGradient(0, 0, 0, 512);
  g.addColorStop(0, a); g.addColorStop(0.6, b); g.addColorStop(1, c); x.fillStyle = g; x.fillRect(0, 0, 4, 512);
  const t = new THREE.CanvasTexture(cv); t.encoding = THREE.sRGBEncoding; return t;
}
const MOOD = { win: { sky: sky('#7fa8d0', '#c4d8ea', '#eef4f8'), fog: [0xdfe8f0, 50, 200], hemi: [0xf4f8ff, 0x9ab0c8, 1.0], sun: [0xfff4e8, 1.1], sp: [10, 14, 8] } };
const SR = 10; { const c = sun.shadow.camera; c.left = -SR; c.right = SR; c.top = SR; c.bottom = -SR; c.near = 1; c.far = 60; c.updateProjectionMatrix(); }
function setMood(m){
  scene.background = m.sky; scene.fog.color.set(m.fog[0]); scene.fog.near = m.fog[1]; scene.fog.far = m.fog[2]; scene.environment = envDay || envNight;
  hemi.color.set(m.hemi[0]); hemi.groundColor.set(m.hemi[1]); hemi.intensity = m.hemi[2]; sun.color.set(m.sun[0]); sun.intensity = m.sun[1];
  sun.position.set(m.sp[0], m.sp[1], m.sp[2]); sun.target.position.set(0, 0, 0); fill.color.set(0xffffff); fill.intensity = 0.35; fill.position.set(-5, 6, 10);
}

/* =========================================================
   SET: zugefrorener See mit Loch (Kappe bricht), Ufer, Bäume
   ========================================================= */
const LAKE = new THREE.Group(); scene.add(LAKE); const SETS = [LAKE];
const CAP = new THREE.Group(), CRACKS = [], SHARDS = [];
(function(){ const im = mat(0xd8eaf4, { roughness: 0.25, metalness: 0.05 });
  const sh = new THREE.Shape(); sh.absarc(0, 0, 120, 0, PI * 2, false); const hole = new THREE.Path(); for (let i = 0; i <= 14; i++){ const a = i / 14 * PI * 2, r = 1.45 + 0.18 * Math.sin(i * 2.3); i ? hole.lineTo(Math.cos(a) * r, Math.sin(a) * r) : hole.moveTo(Math.cos(a) * r, Math.sin(a) * r); } sh.holes.push(hole);
  const ice = new THREE.Mesh(new THREE.ExtrudeGeometry(sh, { depth: 0.18, bevelEnabled: false, curveSegments: 48 }), im); ice.rotation.x = -PI / 2; ice.position.y = -0.18; ice.receiveShadow = true; LAKE.add(ice);
  const wt = new THREE.Mesh(new THREE.CircleGeometry(2, 32), new THREE.MeshStandardMaterial({ color: 0x163a58, roughness: 0.1, metalness: 0.3 })); wt.rotation.x = -PI / 2; wt.position.y = -0.1; LAKE.add(wt);
  // Kappe über dem Loch (bricht beim Einbrechen)
  LAKE.add(CAP); const cp = new THREE.Mesh(new THREE.CircleGeometry(1.75, 24), im); cp.rotation.x = -PI / 2; cp.position.y = 0.002; cp.receiveShadow = true; CAP.add(cp);
  const cm = new THREE.MeshBasicMaterial({ color: 0x5a7a90 }); for (let i = 0; i < 9; i++){ const c = new THREE.Mesh(new THREE.BoxGeometry(1, 0.01, 0.035), cm); c.rotation.y = i * 0.7 + hsh(i) * 0.4; c.position.y = 0.012; CAP.add(c); CRACKS.push(c); }
  for (let i = 0; i < 8; i++){ const s = P(LAKE, new THREE.CylinderGeometry(0.35 + hsh(i) * 0.2, 0.35 + hsh(i) * 0.2, 0.12, 5), im); SHARDS.push(s); }
  // Ufer + Bäume + Schneeinseln
  const sn = mat(0xf6f8fb, { roughness: 1 }), tr = mat(0x2e4a36, { flatShading: true }), st = mat(0x5a4030);
  const bank = new THREE.Mesh(new THREE.TorusGeometry(70, 10, 6, 40), sn); bank.rotation.x = -PI / 2; bank.position.y = -6; LAKE.add(bank);
  for (let i = 0; i < 26; i++){ const a = i / 26 * PI * 2 + hsh(i) * 0.2, r = 62 + hsh(i + 4) * 10, x = Math.cos(a) * r, z = Math.sin(a) * r, h = 6 + hsh(i + 9) * 5;
    P(LAKE, new THREE.CylinderGeometry(0.4, 0.5, 2, 6), st, x, 2.5, z); P(LAKE, new THREE.ConeGeometry(2.6, h, 7), tr, x, 3 + h / 2, z); }
  [[-7, -9, 2.2], [9, -6, 1.6], [-10, 6, 1.4]].forEach(([x, z, r]) => { const m = new THREE.Mesh(new THREE.SphereGeometry(r, 16, 8), sn); m.scale.y = 0.15; m.position.set(x, 0, z); m.receiveShadow = true; LAKE.add(m); });
  // Messstab (Ende)
})();
const STICK = new THREE.Group(); LAKE.add(STICK); STICK.position.set(1.6, 0, -4.6);
(function(){ P(STICK, rbox(0.12, 1.6, 0.12, 0.02, 1), mat(0xf2c21a), 0, 0.8, 0); for (let i = 0; i < 6; i++) P(STICK, rbox(0.14, 0.03, 0.14, 0.005, 1), mat(0x1a1a1a), 0, 0.2 + i * 0.25, 0); })();
function capState(t){ const cr = seg(t, 2.2, 3.1), br = t >= 3.2;
  CAP.visible = !br; CRACKS.forEach((c, i) => { const k = Math.min(1, cr * 1.4 - hsh(i + 2) * 0.4); c.visible = k > 0.02; c.scale.x = Math.max(0.02, k) * (2.2 + hsh(i) * 1.2); c.position.x = Math.cos(-c.rotation.y) * c.scale.x * 0.5 * 0; });
  SHARDS.forEach((s, i) => { s.visible = br; const a = i / 8 * PI * 2 + hsh(i) * 0.5, r = 0.9 + hsh(i + 3) * 0.3; s.position.set(Math.cos(a) * r, -0.06 + 0.03 * Math.sin(t * 2 + i), Math.sin(a) * r); s.rotation.set(0.3 * Math.sin(t + i), i, 0.2 * Math.cos(t * 1.3 + i)); }); }

// Freund für "nie allein"
const PAL = boxer({ top: 0x3a7ac8, trim: 0x2a5a98, pants: 0x3a3a3a, shoe: 0x2a2a2a, sole: 0x111111, hair: 0xc89a4a, skin: 0xe8c0a0 }); ALL.push(PAL); scene.add(PAL.root);

/* =========================================================
   BEN
   ========================================================= */
const SCAR = new THREE.Group(); ben.head.add(SCAR);
(function(){ const m = mat(0xa8463f, { roughness: 0.7 }); const s = new THREE.Mesh(rbox(0.075, 0.72, 0.03, 0.012, 1), m); s.position.set(0.25, 0.55, 0.522); s.rotation.z = -0.13; SCAR.add(s);
  for (const y of [0.36, 0.55, 0.74]){ const c = new THREE.Mesh(rbox(0.16, 0.035, 0.03, 0.01, 1), m); c.position.set(0.25 + (y - 0.55) * 0.13, y, 0.528); c.rotation.z = -0.13; SCAR.add(c); } })();
// Im Wasser: nur Oberkörper über der Wasserlinie
function inWater(t, k){ bRest(ben, t, 0); place(ben, 0, -1.55, 0, 0); ben.sh[0].rotation.set(-0.6 - 0.5 * k * Math.sin(t * 7), 0, -1.0 - 0.3 * k * Math.sin(t * 6)); ben.sh[1].rotation.set(-0.6 - 0.5 * k * Math.sin(t * 7 + 2), 0, 1.0 + 0.3 * k * Math.sin(t * 6 + 1));
  ben.root.position.y += 0.05 * Math.sin(t * 3); }

/* =========================================================
   KAMERA + Zustand
   ========================================================= */
const cL = new THREE.Vector3();
let blurAmt = 0, fadeBlk = 0, T = 0, flashA = 0, eyeS = 1, talk = 0, dT = 0;
let shockK = 0, tenK = 0, outK = 0, rollK = 0, thickK = 0, frostK = 0;
function camW(p, a, b){ cam.position.set(lerp(a[0], b[0], p), lerp(a[1], b[1], p), lerp(a[2], b[2], p)); cL.set(lerp(a[3], b[3], p), lerp(a[4], b[4], p), lerp(a[5], b[5], p)); cam.fov = lerp(a[6], b[6], p); }
function camFin(sh){ cam.position.x += Math.sin(dT * 0.7) * 0.02; cam.position.y += Math.sin(dT * 0.9 + 1) * 0.015; if (sh){ cam.position.x += Math.sin(T * 23) * sh; cam.position.y += Math.cos(T * 17) * sh; } cam.up.set(0, 1, 0); cam.lookAt(cL); cam.updateProjectionMatrix(); cam.updateMatrixWorld(); }
const HOOK = [[2.2, 3.6, 8.5, 0, 2.4, 0, 50], [1.9, 3.4, 7.6, 0, 2.2, 0, 50]];
function base(t){ show(ben); STICK.visible = false; capState(t); }
function hookBen(t){ bRest(ben, t, 0); const w = seg(t, 0, 2.2), fall = E.io(seg(t, 3.15, 3.5)); place(ben, 0, -1.55 * fall, lerp(-2.4, 0, w), 0); if (t < 2.2) wlk(ben, t * 9, 0.8);
  if (t > 2.2){ const s = seg(t, 2.2, 2.6); ben.sh[0].rotation.set(0, 0, -1.2 * s); ben.sh[1].rotation.set(0, 0, 1.2 * s); ben.head.rotation.x = 0.5 * s; eyeS = lerp(1, 1.45, s); bFace(ben, -s, 0.5 * s); } else { eyeS = 1; bFace(ben, 0.4, 0.1); } }

/* =========================================================
   SZENEN (Sprecherspur Tempo 1,12)
   ========================================================= */
const SCN = [
  { t: 0, set: LAKE, mood: MOOD.win, hook: 1,
    upd(lt){ dT = T; base(T); hookBen(T); camW(E.io(seg(lt, 0, 3.54)), HOOK[0], HOOK[1]); camFin(0.06 * bump(T, 3.2, 3.54)); } },
  { t: 3.54, set: LAKE, mood: MOOD.win, hud: () => ['MINUTE 1', 'KÄLTESCHOCK'],
    upd(lt){ dT = T; base(T); const calm = seg(T, 7.23, 8.0); inWater(T, 1 - 0.7 * calm); eyeS = lerp(1.5, 0.9, calm); bFace(ben, lerp(-1, -0.3, calm), lerp(0.75 + 0.2 * Math.sin(T * 9), 0.15, calm));
      frostK = 0.3; shockK = E.out(seg(T, 3.7, 4.0)) * (1 - seg(T, 8.55, 8.73)); camW(E.io(seg(lt, 0, 5.19)), [2.4, 2.4, 5.2, 0, 1.0, 0, 48], [2.0, 2.2, 4.4, 0, 0.9, 0, 48]); camFin(); } },
  { t: 8.73, set: LAKE, mood: MOOD.win, hud: () => ['ETWA 10 MINUTEN', 'BIS DIE MUSKELN VERSAGEN'],
    upd(lt){ dT = T; base(T); inWater(T, 0.25); ben.head.rotation.x = 0.15; eyeS = 0.7; bFace(ben, -0.5, 0.25); frostK = 0.3 + 0.4 * seg(T, 8.8, 12.0);
      tenK = E.out(seg(T, 8.9, 9.2)) * (1 - seg(T, 12.0, 12.18)); camW(E.io(seg(lt, 0, 3.45)), [-4.0, 3.2, 6.0, 0, 0.8, 0, 46], [-3.4, 3.0, 5.2, 0, 0.8, 0, 46]); camFin(); } },
  { t: 12.18, set: LAKE, mood: MOOD.win, hud: () => ['RAUS – ABER RICHTIG', 'DORTHIN, WO ER HERKAM'],
    upd(lt){ dT = T; base(T); bRest(ben, T, 0); const tn = E.io(seg(T, 12.2, 12.7)), lie = E.io(seg(T, 12.7, 14.6)), pull = E.io(seg(T, 14.9, 17.0));
      place(ben, 0, lerp(-1.55, -0.35, lie) + lerp(0, 0.77, pull), lerp(0, -0.9, lie) + lerp(0, -2.6, pull), lerp(0, PI, tn)); ben.root.rotation.x = 1.3 * lie + 0.27 * pull;
      ben.sh[0].rotation.set(-2.9 * lie, 0, -0.25); ben.sh[1].rotation.set(-2.9 * lie, 0, 0.25); ben.el[0].rotation.x = -0.3 * pull; ben.el[1].rotation.x = -0.3 * pull;
      const kick = T > 14.9 && T < 17.0 ? 1 : 0; ben.legs[0].rotation.x = 0.5 * kick * Math.sin(T * 14); ben.legs[1].rotation.x = -0.5 * kick * Math.sin(T * 14); ben.head.rotation.x = -0.6 * lie;
      eyeS = 1.2; bFace(ben, -0.6, 0.3); frostK = 0.6; outK = E.out(seg(T, 12.4, 12.7)) * (1 - seg(T, 17.25, 17.43));
      camW(E.io(seg(lt, 0, 5.25)), [8.0, 3.4, 0.5, 0, 0.6, -1.6, 50], [8.4, 3.6, -2.0, 0, 0.4, -4.4, 50]); camFin(); } },
  { t: 17.43, set: LAKE, mood: MOOD.win, hud: () => ['NICHT AUFSTEHEN!', 'WEGROLLEN'],
    upd(lt){ dT = T; base(T); bRest(ben, T, 0); const rl = E.io(seg(T, 17.7, 19.5)); place(ben, -2.6 * rl, 0.42, -3.5, PI); ben.root.rotation.x = PI / 2;
      ben.body.rotation.y = -PI * 2 * rl; ben.sh[0].rotation.set(-2.9, 0, -0.1); ben.sh[1].rotation.set(-2.9, 0, 0.1); eyeS = 1.1; bFace(ben, -0.3, 0.2); frostK = 0.5;
      rollK = E.out(seg(T, 17.6, 17.9)) * (1 - seg(T, 19.55, 19.73)); camW(E.io(seg(lt, 0, 2.3)), [3.0, 4.2, 0.4, -0.3, 0.3, -5.8, 52], [1.6, 4.0, -0.2, -2.1, 0.3, -5.8, 52]); camFin(); } },
  { t: 19.73, set: LAKE, mood: MOOD.win, hud: () => ['UND BEN?', 'EIS AB 15 CM – NIE ALLEIN'],
    upd(lt){ dT = T; base(T); show(ben, PAL); STICK.visible = true; bRest(ben, T, 0); bRest(PAL, T + 1, 0); place(ben, 0.6, 0, -4.4, 0.3); place(PAL, 2.8, 0, -4.9, -0.3);
      ben.sh[1].rotation.set(-1.2, 0, 0.3); PAL.sh[0].rotation.set(0, 0, -2.6 - 0.2 * Math.sin(T * 6)); eyeS = 1; bFace(ben, 0.7, 0.12); bFace(PAL, 0.7, 0.15); frostK = 0.15;
      thickK = E.out(seg(T, 20.6, 20.9)); camW(E.io(seg(lt, 0, 4.67)), [2.4, 3.2, 4.4, 1.6, 2.6, -4.6, 50], [2.2, 3.1, 3.6, 1.6, 2.6, -4.6, 50]); camFin(); } },
  { t: 24.05, set: LAKE, mood: MOOD.win, loopin: 1,
    upd(lt){ dT = T - END; base(T - END); hookBen(T - END); camW(0, HOOK[0], HOOK[1]); camFin(); } },
];
const SUBS = __SUBS__;
