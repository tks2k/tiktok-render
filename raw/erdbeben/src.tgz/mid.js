/* =========================================================
   STIMMUNG: Wohnzimmer bei Tag
   ========================================================= */
function sky(a, b, c){
  const cv = document.createElement('canvas'); cv.width = 4; cv.height = 512; const x = cv.getContext('2d'), g = x.createLinearGradient(0, 0, 0, 512);
  g.addColorStop(0, a); g.addColorStop(0.6, b); g.addColorStop(1, c); x.fillStyle = g; x.fillRect(0, 0, 4, 512);
  const t = new THREE.CanvasTexture(cv); t.encoding = THREE.sRGBEncoding; return t;
}
const MOOD = { room: { sky: sky('#9cc8ec', '#cfe4f4', '#eef4f8'), fog: [0xe8e2d8, 40, 120], hemi: [0xfff6ea, 0x8a7460, 0.95], sun: [0xfff0dc, 1.0], sp: [6, 12, 10] } };
const SR = 10; { const c = sun.shadow.camera; c.left = -SR; c.right = SR; c.top = SR; c.bottom = -SR; c.near = 1; c.far = 50; c.updateProjectionMatrix(); }
function setMood(m){
  scene.background = m.sky; scene.fog.color.set(m.fog[0]); scene.fog.near = m.fog[1]; scene.fog.far = m.fog[2]; scene.environment = envDay || envNight;
  hemi.color.set(m.hemi[0]); hemi.groundColor.set(m.hemi[1]); hemi.intensity = m.hemi[2]; sun.color.set(m.sun[0]); sun.intensity = m.sun[1];
  sun.position.set(m.sp[0], m.sp[1], m.sp[2]); sun.target.position.set(0, 0, -2); fill.color.set(0xffffff); fill.intensity = 0.4; fill.position.set(-5, 6, 8);
}

/* =========================================================
   SET: Wohnzimmer (Rückwand mit Tür, Regal, Fenster), Tisch, Lampe
   ========================================================= */
const ROOM = new THREE.Group(); scene.add(ROOM); const SETS = [ROOM];
const LAMP = new THREE.Group(), PIC = new THREE.Group(), WIN = new THREE.Group(), BOOKS = [], SHARDS = [];
let VASE, PLASTER;
(function(){ const wm = mat(0xe9e0cf, { roughness: 0.95 }), fl = mat(0x9a6e44, { roughness: 0.8 }), wd = mat(0x7a5232, { roughness: 0.8 });
  const f = P(ROOM, new THREE.BoxGeometry(14, 0.2, 14), fl, 0, -0.1, 1); f.castShadow = false;
  P(ROOM, new THREE.BoxGeometry(5.4, 5, 0.3), wm, -4.3, 2.5, -5);           // Rückwand links
  P(ROOM, new THREE.BoxGeometry(7.0, 5, 0.3), wm, 3.5, 2.5, -5);            // Rückwand rechts
  P(ROOM, new THREE.BoxGeometry(1.6, 1.8, 0.3), wm, -0.8, 4.1, -5);         // über der Tür
  P(ROOM, new THREE.BoxGeometry(0.3, 5, 14), wm, -7, 2.5, 1); P(ROOM, new THREE.BoxGeometry(0.3, 5, 14), wm, 7, 2.5, 1);
  const hall = new THREE.Mesh(new THREE.PlaneGeometry(2, 3.4), new THREE.MeshBasicMaterial({ color: 0x3a3430 })); hall.position.set(-0.8, 1.6, -5.4); ROOM.add(hall);
  const fr = mat(0xf4f0e8); P(ROOM, rbox(0.14, 3.3, 0.4, 0.03, 1), fr, -1.62, 1.6, -5); P(ROOM, rbox(0.14, 3.3, 0.4, 0.03, 1), fr, 0.02, 1.6, -5); P(ROOM, rbox(1.78, 0.14, 0.4, 0.03, 1), fr, -0.8, 3.22, -5);
  const dl = new THREE.Group(); dl.position.set(-1.55, 0, -4.85); ROOM.add(dl); P(dl, rbox(1.5, 3.1, 0.1, 0.03, 1), mat(0xffffff, { roughness: 0.6 }), 0.75, 1.55, 0); dl.rotation.y = 1.2;
  // Regal mit Büchern + Vase
  const S = new THREE.Group(); S.position.set(-4.4, 0, -4.5); ROOM.add(S);
  P(S, rbox(2.6, 0.12, 0.7, 0.02, 1), wd, 0, 0.1, 0); [1.2, 2.3, 3.4].forEach(y => P(S, rbox(2.6, 0.1, 0.7, 0.02, 1), wd, 0, y, 0)); P(S, rbox(0.12, 3.5, 0.7, 0.02, 1), wd, -1.25, 1.75, 0); P(S, rbox(0.12, 3.5, 0.7, 0.02, 1), wd, 1.25, 1.75, 0);
  const bc = [0xb03a2a, 0x2a5a9a, 0xe0b030, 0x3a8a4a, 0x8a3a8a, 0xd06a2a];
  for (let r = 0; r < 2; r++) for (let i = 0; i < 7; i++){ const h = 0.65 + hsh(i + r * 9) * 0.25; P(S, rbox(0.2, h, 0.5, 0.02, 1), mat(bc[(i + r * 2) % 6]), -1.0 + i * 0.26, (r ? 2.35 : 1.25) + h / 2, 0); }
  for (let i = 0; i < 4; i++){ const b = P(ROOM, rbox(0.22, 0.8, 0.55, 0.02, 1), mat(bc[(i + 3) % 6])); BOOKS.push(b); }
  VASE = P(ROOM, new THREE.CylinderGeometry(0.18, 0.28, 0.7, 12), mat(0x4a8ac0, { roughness: 0.3 }));
  const sm = mat(0x4a8ac0, { roughness: 0.3, flatShading: true }); for (let i = 0; i < 7; i++) SHARDS.push(P(ROOM, new THREE.TetrahedronGeometry(0.12 + hsh(i) * 0.08, 0), sm));
  PLASTER = P(ROOM, new THREE.DodecahedronGeometry(0.35, 0), mat(0xd8cfc0, { flatShading: true }));
  // Fenster rechts
  WIN.position.set(3.4, 2.7, -4.82); ROOM.add(WIN); P(WIN, rbox(2.6, 2.2, 0.16, 0.03, 1), fr, 0, 0, 0);
  const gl = new THREE.Mesh(new THREE.PlaneGeometry(2.3, 1.9), new THREE.MeshStandardMaterial({ color: 0xa8d4f0, roughness: 0.05, metalness: 0.3, emissive: 0x4a7aa0, emissiveIntensity: 0.4 })); gl.position.z = 0.1; WIN.add(gl);
  P(WIN, rbox(0.08, 1.9, 0.06, 0.01, 1), fr, 0, 0, 0.13); P(WIN, rbox(2.3, 0.08, 0.06, 0.01, 1), fr, 0, 0, 0.13);
  // Bild an der Wand
  PIC.position.set(5.6, 3.3, -4.8); ROOM.add(PIC); P(PIC, rbox(1.0, 0.8, 0.06, 0.02, 1), mat(0x6a4a2a), 0, -0.45, 0); P(PIC, rbox(0.84, 0.64, 0.07, 0.01, 1), mat(0x8ac0e0), 0, -0.45, 0.01);
  // Tisch (stabil)
  const TB = new THREE.Group(); TB.position.set(2.2, 0, -0.6); ROOM.add(TB); const tw = mat(0x8a5a32, { roughness: 0.6 });
  P(TB, rbox(3.4, 0.16, 2.2, 0.04), tw, 0, 1.86, 0); [[-1.5, -0.9], [1.5, -0.9], [-1.5, 0.9], [1.5, 0.9]].forEach(([x, z]) => P(TB, rbox(0.16, 1.8, 0.16, 0.03, 1), tw, x, 0.9, z));
  P(TB, new THREE.CylinderGeometry(0.12, 0.12, 0.25, 10), mat(0xffffff), -0.6, 2.06, 0.3); P(TB, new THREE.CylinderGeometry(0.18, 0.18, 0.05, 14), mat(0xffffff), 0.5, 1.97, -0.2);
  // Teppich + Sofa links vorn
  P(ROOM, rbox(5, 0.03, 3.6, 0.01, 1), mat(0xb84a3a, { roughness: 1 }), -2.4, 0.02, 1.4);
  P(ROOM, rbox(3.6, 1.0, 1.4, 0.15), mat(0x4a6a8a, { roughness: 0.9 }), -4.6, 0.5, 2.8); P(ROOM, rbox(3.6, 1.4, 0.4, 0.15), mat(0x4a6a8a, { roughness: 0.9 }), -4.6, 1.2, 3.4);
  const ce = P(ROOM, new THREE.BoxGeometry(14, 0.2, 14), mat(0xf2ede4, { roughness: 1 }), 0, 5.1, 1); ce.castShadow = false;
  // Deckenlampe
  LAMP.position.set(0, 5, 0); ROOM.add(LAMP); P(LAMP, new THREE.CylinderGeometry(0.02, 0.02, 1.2, 4), mat(0x222222), 0, -0.6, 0);
  P(LAMP, new THREE.ConeGeometry(0.5, 0.45, 16, 1, true), mat(0xf2e2b0, { side: THREE.DoubleSide }), 0, -1.35, 0);
})();
// Fallende Gegenstände (zeitgesteuert, deterministisch)
function falls(t){ const sx = -4.4, sz = -4.5;
  BOOKS.forEach((b, i) => { const t0 = 7.9 + i * 0.12, p = seg(t, t0, t0 + 0.45), y0 = 3.85, y1 = 0.12; b.position.set(sx - 0.6 + i * 0.35 + 1.2 * p, lerp(y0, y1, p * p), sz + 0.1 + 1.4 * p); b.rotation.set(0, 0.3 * i, (1.5 + 0.2 * i) * E.out(p)); });
  const pv = seg(t, 8.2, 8.55); VASE.visible = pv < 1; VASE.position.set(sx + 0.8 + 0.6 * pv, lerp(3.82, 0.35, pv * pv), sz + 1.1 * pv); VASE.rotation.z = 1.2 * pv;
  SHARDS.forEach((s, i) => { s.visible = pv >= 1; const a = hsh(i + 3) * 6.283, k = E.out(seg(t, 8.55, 8.9)), r = 0.3 + hsh(i + 7) * 0.9; s.position.set(sx + 1.4 + Math.cos(a) * r * k, 0.08, sz + 1.1 + Math.sin(a) * r * k); s.rotation.set(i, i * 2, 0); });
  const pp = seg(t, 8.25, 8.62); PLASTER.visible = t > 8.25; PLASTER.position.set(-0.8 + 0.2 * pp, lerp(4.9, 0.35, pp * pp), -3.9 + 0.4 * pp); PLASTER.rotation.set(3 * pp, 2 * pp, 0); }
function quake(k, t){ LAMP.rotation.z = 0.35 * k * Math.sin(t * 4.3); LAMP.rotation.x = 0.2 * k * Math.sin(t * 3.1 + 1); PIC.rotation.z = 0.2 * k * Math.sin(t * 7); WIN.position.x = 3.4 + 0.02 * k * Math.sin(t * 31); }

/* =========================================================
   BEN
   ========================================================= */
const SCAR = new THREE.Group(); ben.head.add(SCAR);
(function(){ const m = mat(0xa8463f, { roughness: 0.7 }); const s = new THREE.Mesh(rbox(0.075, 0.72, 0.03, 0.012, 1), m); s.position.set(0.25, 0.55, 0.522); s.rotation.z = -0.13; SCAR.add(s);
  for (const y of [0.36, 0.55, 0.74]){ const c = new THREE.Mesh(rbox(0.16, 0.035, 0.03, 0.01, 1), m); c.position.set(0.25 + (y - 0.55) * 0.13, y, 0.528); c.rotation.z = -0.13; SCAR.add(c); } })();
function wobble(t, k){ ben.sh[0].rotation.set(-0.3, 0, -1.1 - 0.25 * k * Math.sin(t * 9)); ben.sh[1].rotation.set(-0.3, 0, 1.1 + 0.25 * k * Math.sin(t * 9 + 1)); ben.legs[0].rotation.z = -0.15; ben.legs[1].rotation.z = 0.15; ben.root.rotation.z = 0.06 * k * Math.sin(t * 6); }
// Krabbel-/Deckungspose (passt unter den Tisch: Unterkante 1,78)
function crawl(r, ph, mv){ r.body.position.y = 0.6 + 0.04 * Math.sin(ph) * mv; r.torso.rotation.x = 1.0; r.head.rotation.x = -0.85; r.legs[0].rotation.x = 1.35 + 0.15 * Math.sin(ph) * mv; r.legs[1].rotation.x = 1.35 - 0.15 * Math.sin(ph) * mv;
  r.sh[0].rotation.set(-0.55 + 0.25 * Math.sin(ph + 1) * mv, 0, -0.1); r.sh[1].rotation.set(-0.55 - 0.25 * Math.sin(ph + 1) * mv, 0, 0.1); r.el[0].rotation.x = -0.3; r.el[1].rotation.x = -0.3; }

/* =========================================================
   KAMERA + Zustand
   ========================================================= */
const cL = new THREE.Vector3();
let blurAmt = 0, fadeBlk = 0, T = 0, flashA = 0, eyeS = 1, talk = 0, dT = 0;
let xK = 0, stepK = 0, awayK = 0, mythK = 0, qK = 1;
function camW(p, a, b){ cam.position.set(lerp(a[0], b[0], p), lerp(a[1], b[1], p), lerp(a[2], b[2], p)); cL.set(lerp(a[3], b[3], p), lerp(a[4], b[4], p), lerp(a[5], b[5], p)); cam.fov = lerp(a[6], b[6], p); }
function camFin(sh){ cam.position.x += Math.sin(dT * 0.7) * 0.015; cam.position.y += Math.sin(dT * 0.9 + 1) * 0.01; if (sh){ cam.position.x += Math.sin(dT * 23) * sh; cam.position.y += Math.cos(dT * 17) * sh; cL.x += Math.sin(dT * 19 + 2) * sh * 0.6; } cam.up.set(0, 1, 0); cam.lookAt(cL); cam.updateProjectionMatrix(); cam.updateMatrixWorld(); }
const HOOK = [[1.2, 3.4, 9.5, -1.2, 3.4, 0.5, 50], [1.0, 3.3, 8.6, -1.2, 3.4, 0.5, 50]];
function base(t){ show(ben); falls(t); }
function hookBen(t){ bRest(ben, t, 0); place(ben, -1.5, 0, 1.5, 0.2); wobble(t, 1); eyeS = 1.45; bFace(ben, -1, 0.55); quake(1, t); }

/* =========================================================
   SZENEN (Sprecherspur Tempo 1,05)
   ========================================================= */
const SCN = [
  { t: 0, set: ROOM, mood: MOOD.room, hook: 1,
    upd(lt){ dT = T; base(T); hookBen(T); camW(E.io(seg(lt, 0, 3.33)), HOOK[0], HOOK[1]); camFin(0.05); } },
  { t: 3.33, set: ROOM, mood: MOOD.room, hud: () => ['RAUSRENNEN?', 'LIEBER NICHT!'],
    upd(lt){ dT = T; base(T); quake(1, T); bRest(ben, T, 0); const r = E.io(seg(T, 3.45, 4.95)); place(ben, lerp(-1.5, -0.8, r), 0, lerp(1.5, -2.2, r), lerp(0.2, PI, seg(T, 3.4, 3.7)));
      if (r < 1) wlk(ben, T * 14, 1); else wobble(T, 1); eyeS = 1.4; bFace(ben, -1, 0.5); xK = E.out(seg(T, 4.9, 5.15)) * (1 - seg(T, 5.75, 5.92));
      camW(E.io(seg(lt, 0, 2.59)), [3.0, 3.2, 7.5, -1.0, 2.2, -1.0, 50], [2.6, 3.4, 6.0, -0.9, 2.3, -2.2, 50]); camFin(0.05); } },
  { t: 5.92, set: ROOM, mood: MOOD.room, hud: () => ['GEFAHR', 'HERABFALLENDE TEILE'],
    upd(lt){ dT = T; base(T); quake(1, T); bRest(ben, T, 0); const back = E.io(seg(T, 8.45, 8.95)); place(ben, -0.8, 0, lerp(-2.2, -1.2, back), lerp(PI, PI + 0.5, back)); wobble(T, 1);
      if (T > 8.3){ ben.sh[0].rotation.set(-2.6, 0, -0.3); ben.sh[1].rotation.set(-2.6, 0, 0.3); ben.el[0].rotation.x = -1.2; ben.el[1].rotation.x = -1.2; } eyeS = 1.45; bFace(ben, -1, 0.6);
      camW(E.io(seg(lt, 0, 3.81)), [-2.6, 3.8, 4.0, -2.0, 2.4, -3.6, 55], [-2.4, 3.7, 3.4, -2.0, 2.3, -3.6, 55]); camFin(0.05 + 0.08 * bump(T, 8.5, 8.8)); } },
  { t: 9.73, set: ROOM, mood: MOOD.room, hud: () => ['BESSER:', 'RUNTER · DECKUNG · FESTHALTEN'],
    upd(lt){ dT = T; base(T); quake(0.85, T); bRest(ben, T, 0); const dn = E.io(seg(T, 9.9, 10.4)), cr = E.io(seg(T, 10.6, 12.5)), tn = E.io(seg(T, 12.4, 12.9));
      const x = lerp(-0.8, 2.2, cr), z = lerp(-1.2, -0.6, cr); place(ben, x, 0, z, lerp(lerp(PI + 0.5, PI / 2, seg(T, 10.4, 10.7)), 0, tn));
      if (dn < 1){ wobble(T, 1); ben.body.position.y = lerp(1.0, 0.6, dn); ben.torso.rotation.x = 1.0 * dn; ben.legs[0].rotation.x = 1.35 * dn; ben.legs[1].rotation.x = 1.35 * dn; }
      else crawl(ben, T * 9, cr > 0 && cr < 1 ? 1 : 0);
      if (T > 13.4){ const h = E.io(seg(T, 13.4, 13.8)); ben.sh[1].rotation.set(lerp(-0.55, -1.9, h), 0, lerp(0.1, -0.35, h)); ben.el[1].rotation.x = -0.4 * h; ben.sh[0].rotation.set(-0.7, 0, -0.1); }
      eyeS = 1.3; bFace(ben, -0.7, 0.3); stepK = E.out(seg(T, 9.9, 10.2)) * (1 - seg(T, 14.55, 14.73));
      camW(E.io(seg(lt, 0, 5.0)), [4.8, 3.4, 6.8, 0.6, 1.3, -1.0, 52], [5.4, 2.6, 5.4, 1.6, 1.0, -0.8, 52]); camFin(0.04); } },
  { t: 14.73, set: ROOM, mood: MOOD.room, hud: () => ['WEG VON', 'FENSTERN & REGALEN'],
    upd(lt){ dT = T; base(T); quake(0.85, T); bRest(ben, T, 0); place(ben, 2.2, 0, -0.6, 0); crawl(ben, T, 0); ben.sh[1].rotation.set(-1.9, 0, -0.35); ben.el[1].rotation.x = -0.4; ben.sh[0].rotation.set(-0.7, 0, -0.1);
      eyeS = 1.3; bFace(ben, -0.7, 0.3); awayK = E.out(seg(T, 14.9, 15.2)) * (1 - seg(T, 16.7, 16.88));
      camW(E.io(seg(lt, 0, 2.15)), [-3.0, 2.8, 4.4, 2.0, 2.4, -4.8, 55], [-3.0, 2.8, 3.8, 2.4, 2.5, -4.8, 55]); camFin(0.04); } },
  { t: 16.88, set: ROOM, mood: MOOD.room, hud: () => ['TÜRRAHMEN?', 'VERALTETER MYTHOS'],
    upd(lt){ dT = T; base(T); quake(0.85, T); bRest(ben, T, 0); place(ben, 2.2, 0, -0.6, 0); crawl(ben, T, 0); ben.sh[1].rotation.set(-1.9, 0, -0.35); ben.el[1].rotation.x = -0.4;
      eyeS = 1.3; bFace(ben, -0.7, 0.3); mythK = E.out(seg(T, 17.0, 17.3)) * (1 - seg(T, 20.05, 20.23));
      camW(E.io(seg(lt, 0, 3.35)), [-0.6, 2.8, 2.2, -0.8, 2.0, -5.0, 55], [-0.6, 2.7, 1.4, -0.8, 2.0, -5.0, 55]); camFin(0.04); } },
  { t: 20.23, set: ROOM, mood: MOOD.room, hud: () => ['UND BEN?', 'WARTET UNTERM TISCH'],
    upd(lt){ dT = T; base(T); const q = 0.85 * (1 - seg(T, 21.2, 22.8)); quake(q, T); bRest(ben, T, 0); const pk = E.io(seg(T, 22.9, 23.4)); place(ben, 2.2, 0, lerp(-0.6, -0.2, pk), 0); crawl(ben, T, 0);
      ben.sh[1].rotation.set(-1.9 * (1 - pk), 0, -0.35 * (1 - pk)); ben.el[1].rotation.x = -0.4; ben.head.rotation.x = lerp(-0.85, -1.0, pk);
      eyeS = lerp(1.3, 1, pk); bFace(ben, lerp(-0.6, 0.7, pk), lerp(0.3, 0.12, pk));
      camW(E.io(seg(lt, 0, 3.5)), [4.6, 2.0, 7.0, 2.2, 1.4, -0.6, 48], [4.2, 1.9, 6.3, 2.2, 1.3, -0.6, 48]); camFin(0.04 * q); } },
  { t: 23.75, set: ROOM, mood: MOOD.room, loopin: 1,
    upd(lt){ dT = T - END; base(T - END); hookBen(T - END); camW(0, HOOK[0], HOOK[1]); camFin(0.05); } },
];
const SUBS = __SUBS__;
