/* =========================================================
   STIMMUNGEN: Wiese (DE), Tunnel, Erde im Schnitt, Sandinsel (andere Seite)
   ========================================================= */
const MOOD = {
  ger: { bg: 0x6aa8e0, fog: [0x6aa8e0, 50, 200], hemi: [0xeef6ff, 0x5a6a40, 0.85], sun: [0xfff2dc, 1.15] },
  tun: { bg: 0x120a06, fog: [0x1a0e08, 6, 46], hemi: [0xffd8b0, 0x3a2010, 1.1], sun: [0xffe0c0, 0.2] },
  ear: { bg: 0x0b1530, fog: [0x0b1530, 200, 400], hemi: [0xffffff, 0x404060, 0.9], sun: [0xffffff, 0.9] },
  snd: { bg: 0xf0a878, fog: [0xf0a878, 50, 200], hemi: [0xfff0e0, 0x8a6a40, 0.85], sun: [0xffe0b8, 1.1] } };
const SR = 14; { const c = sun.shadow.camera; c.left = -SR; c.right = SR; c.top = SR; c.bottom = -SR; c.near = 1; c.far = 120; c.updateProjectionMatrix(); }
function setMood(m){
  scene.background = new THREE.Color(m.bg); scene.fog.color.set(m.fog[0]); scene.fog.near = m.fog[1]; scene.fog.far = m.fog[2]; scene.environment = envDay;
  hemi.color.set(m.hemi[0]); hemi.groundColor.set(m.hemi[1]); hemi.intensity = m.hemi[2]; sun.color.set(m.sun[0]); sun.intensity = m.sun[1];
  sun.position.set(10, 30, 20); sun.target.position.set(0, 0, 0); fill.color.set(0xffffff); fill.intensity = 0.35; fill.position.set(-10, 8, 20);
}

/* =========================================================
   SETS
   ========================================================= */
const HR = 2.4;
function holeGround(col){ const s = new THREE.Shape(); s.moveTo(-150, -150); s.lineTo(150, -150); s.lineTo(150, 150); s.lineTo(-150, 150); s.lineTo(-150, -150);
  const h = new THREE.Path(); h.absarc(0, 0, HR, 0, PI * 2, true); s.holes.push(h); const m = new THREE.Mesh(new THREE.ShapeGeometry(s, 48), mat(col, { roughness: 1 })); m.rotation.x = -PI / 2; m.receiveShadow = true; return m; }
const shaftTex = (function(){ const c = document.createElement('canvas'); c.width = 8; c.height = 256; const x = c.getContext('2d'), g = x.createLinearGradient(0, 0, 0, 256); g.addColorStop(0, '#7a5232'); g.addColorStop(0.25, '#3a2414'); g.addColorStop(1, '#050302'); x.fillStyle = g; x.fillRect(0, 0, 8, 256); const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; return t; })();
function shaft(par, rimCol){ const s = new THREE.Mesh(new THREE.CylinderGeometry(HR, HR, 30, 40, 1, true), new THREE.MeshBasicMaterial({ map: shaftTex, side: THREE.BackSide, fog: false })); s.position.y = -15; par.add(s);
  const b = new THREE.Mesh(new THREE.CircleGeometry(HR, 40), new THREE.MeshBasicMaterial({ color: 0x050302, fog: false })); b.rotation.x = -PI / 2; b.position.y = -29.9; par.add(b);
  const r = new THREE.Mesh(new THREE.RingGeometry(HR, HR + 0.45, 48), mat(rimCol, { roughness: 0.9 })); r.rotation.x = -PI / 2; r.position.y = 0.02; r.receiveShadow = true; par.add(r); }
const GER = new THREE.Group(); scene.add(GER);
(function(){ GER.add(holeGround(0x5f9a45)); shaft(GER, 0x8a8478);
  const tr = mat(0x5a3e28), lf = mat(0x2f6b34, { roughness: 0.9, flatShading: true });
  for (let i = 0; i < 16; i++){ const a = i / 16 * PI * 2 + hsh(i) * 0.3, d = 13 + hsh(i + 4) * 8, x = Math.cos(a) * d, z = Math.sin(a) * d; P(GER, new THREE.CylinderGeometry(0.25, 0.35, 3, 6), tr, x, 1.5, z); P(GER, new THREE.DodecahedronGeometry(1.8 + hsh(i) * 0.8, 0), lf, x, 3.8, z); }
  const fl = [mat(0xf2e24a), mat(0xf2f2f2), mat(0xd85ab8)]; for (let i = 0; i < 80; i++){ const a = hsh(i * 3) * PI * 2, d = 3.2 + hsh(i * 5) * 9; P(GER, new THREE.SphereGeometry(0.07, 6, 4), fl[i % 3], Math.cos(a) * d, 0.08, Math.sin(a) * d); }
  // Warnschild
  P(GER, new THREE.CylinderGeometry(0.06, 0.06, 1.6, 6), mat(0x9a9a9a), -3.4, 0.8, -1.2); const sg = P(GER, new THREE.CylinderGeometry(0.5, 0.5, 0.06, 3), mat(0xf2c21a), -3.4, 1.75, -1.2); sg.rotation.x = PI / 2; sg.rotation.y = 0;
})();
const SND = new THREE.Group(); scene.add(SND);
(function(){ SND.add(holeGround(0xe2c98a)); shaft(SND, 0xb89a68);
  const sea = new THREE.Mesh(new THREE.RingGeometry(16, 200, 64), mat(0x2a8ab8, { roughness: 0.3 })); sea.rotation.x = -PI / 2; sea.position.y = 0.04; SND.add(sea);
  const tk = mat(0x8a6a44), lf = mat(0x2f8a3a, { roughness: 0.8, flatShading: true });
  [[-6, -7], [7, -9], [-9, 3], [10, 2]].forEach(([x, z], i) => { for (let k = 0; k < 6; k++) P(SND, new THREE.CylinderGeometry(0.18, 0.22, 0.8, 6), tk, x + k * k * 0.03, 0.4 + k * 0.78, z);
    for (let k = 0; k < 5; k++){ const l = P(SND, rbox(0.5, 0.08, 2.4, 0.04), lf, x + 0.75 + Math.cos(k * 1.26) * 1.0, 4.9, z + Math.sin(k * 1.26) * 1.0); l.rotation.y = -k * 1.26 + PI / 2; l.rotation.x = 0.35; } });
})();
// Tunnel: Wand mit Längsstreifen (parallel zur Fallrichtung → kein Stroboskop-Flackern)
const tunTex = (function(){ const c = document.createElement('canvas'); c.width = 512; c.height = 1024; const x = c.getContext('2d'); x.fillStyle = '#8a8a8a'; x.fillRect(0, 0, 512, 1024);
  for (let i = 0; i < 140; i++){ const px = hsh(i) * 512, py = hsh(i + 50) * 1024, w = 6 + hsh(i + 9) * 22, h = 160 + hsh(i + 3) * 380, v = 100 + Math.floor(hsh(i + 7) * 90);
    const g = x.createLinearGradient(0, py - h / 2, 0, py + h / 2); g.addColorStop(0, `rgba(${v},${v},${v},0)`); g.addColorStop(0.5, `rgba(${v},${v},${v},0.8)`); g.addColorStop(1, `rgba(${v},${v},${v},0)`);
    x.fillStyle = g; for (const o of [-1024, 0, 1024]) x.fillRect(px - w / 2, py - h / 2 + o, w, h); }
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.wrapS = t.wrapT = THREE.RepeatWrapping; t.repeat.set(3, 4); return t; })();
const TUN = new THREE.Group(); scene.add(TUN);
const TW = new THREE.Mesh(new THREE.CylinderGeometry(2.6, 2.6, 90, 40, 1, true), new THREE.MeshBasicMaterial({ map: tunTex, side: THREE.BackSide })); TUN.add(TW);
const TSKY = new THREE.Mesh(new THREE.CircleGeometry(2.6, 40), new THREE.MeshBasicMaterial({ color: 0xbfe2ff, fog: false })); TSKY.rotation.x = PI / 2; TUN.add(TSKY);
const TGLO = new THREE.Mesh(new THREE.CircleGeometry(2.6, 40), new THREE.MeshBasicMaterial({ color: 0xffb060, fog: false })); TGLO.rotation.x = -PI / 2; TUN.add(TGLO);
const C_CR = new THREE.Color(0x9a6a44), C_MA = new THREE.Color(0xe06a2a);
let tunOff = 0;
// tunnel(d: Abstand Öffnung oben, k: 0 Kruste … 1 Mantel, sp: Streifentempo)
function tunnel(d, k, sp){ TSKY.position.y = d; TGLO.position.y = -40; TW.material.color.copy(C_CR).lerp(C_MA, k); tunOff = (tunOff + sp / 30 / 22.5) % 1; tunTex.offset.y = tunOff; scene.fog.color.copy(TW.material.color).multiplyScalar(0.18); scene.background = scene.fog.color; }
// Erde im Schnitt
const EAR = new THREE.Group(); scene.add(EAR);
const DOT = new THREE.Group(); EAR.add(DOT);
(function(){ const sh = new THREE.Mesh(new THREE.SphereGeometry(10, 64, 40, PI, PI), mat(0x2a6ab0, { roughness: 0.7, side: THREE.DoubleSide })); EAR.add(sh);
  [[10, 0x6a4a30], [9.6, 0xd0582a], [5.5, 0xf08a2a], [2.5, 0xffd04a]].forEach(([r, c], i) => { const m = new THREE.Mesh(new THREE.CircleGeometry(r, 72), new THREE.MeshBasicMaterial({ color: c, fog: false })); m.position.z = 0.01 + i * 0.01; EAR.add(m); });
  const t = new THREE.Mesh(new THREE.PlaneGeometry(0.42, 20.6), new THREE.MeshBasicMaterial({ color: 0x140c08, fog: false })); t.position.z = 0.06; EAR.add(t);
  [1, -1].forEach(s => { const g = new THREE.Mesh(new THREE.CircleGeometry(1.0, 24, s > 0 ? 0 : PI, PI), new THREE.MeshBasicMaterial({ color: s > 0 ? 0x4aa84a : 0xe2c98a, fog: false })); g.position.set(0, s * 10, 0.005); EAR.add(g); });
  const d = new THREE.Mesh(new THREE.CircleGeometry(0.62, 32), new THREE.MeshBasicMaterial({ color: 0x0b1220, fog: false })); d.position.z = 0.08; DOT.add(d);
  const d2 = new THREE.Mesh(new THREE.CircleGeometry(0.48, 32), new THREE.MeshBasicMaterial({ color: 0xE8B21F, fog: false })); d2.position.z = 0.09; DOT.add(d2); })();
const SETS = [GER, SND, TUN, EAR];

/* =========================================================
   BEN: Narbe + Posen
   ========================================================= */
const SCAR = new THREE.Group(); ben.head.add(SCAR);
(function(){ const m = mat(0xa8463f, { roughness: 0.7 }); const s = new THREE.Mesh(rbox(0.075, 0.72, 0.03, 0.012, 1), m); s.position.set(0.25, 0.55, 0.522); s.rotation.z = -0.13; SCAR.add(s);
  for (const y of [0.36, 0.55, 0.74]){ const c = new THREE.Mesh(rbox(0.16, 0.035, 0.03, 0.01, 1), m); c.position.set(0.25 + (y - 0.55) * 0.13, y, 0.528); c.rotation.z = -0.13; SCAR.add(c); } })();
function flail(r, t, a){ [0, 1].forEach(i => { const s = i ? 1 : -1; r.sh[i].rotation.set(-2.5 + Math.sin(t * 7 + i * 2) * 0.35 * a, 0, s * (0.45 + Math.sin(t * 6 + i) * 0.2 * a)); r.el[i].rotation.x = -0.5 + Math.sin(t * 8 + i) * 0.3 * a; });
  r.legs[0].rotation.x = Math.sin(t * 6) * 0.3 * a; r.legs[1].rotation.x = -Math.sin(t * 6) * 0.3 * a; }

/* =========================================================
   KAMERA + Zustand
   ========================================================= */
const cL = new THREE.Vector3();
let blurAmt = 0, fadeBlk = 0, T = 0, flashA = 0, eyeS = 1, talk = 0, dT = 0;
let spdK = 0, minK = 0, loopK = 0, lblK = 0;
function camW(p, a, b){ cam.position.set(lerp(a[0], b[0], p), lerp(a[1], b[1], p), lerp(a[2], b[2], p)); cL.set(lerp(a[3], b[3], p), lerp(a[4], b[4], p), lerp(a[5], b[5], p)); cam.fov = lerp(a[6], b[6], p); }
function camFin(sh){ cam.position.x += Math.sin(dT * 0.7) * 0.03; cam.position.y += Math.sin(dT * 0.9 + 1) * 0.02; if (sh){ cam.position.x += Math.sin(T * 23) * sh; cam.position.y += Math.cos(T * 17) * sh; } cam.up.set(0, 1, 0); cam.lookAt(cL); cam.updateProjectionMatrix(); cam.updateMatrixWorld(); }
// Phase der harmonischen Schwingung: 0 = Start (DE), π/2 = Erdmittelpunkt, π = andere Seite
const T0 = 4.0, TA = 18.2;
function PH(t){ return PI * (t - T0) / (TA - T0); }
function spd(){ return Math.max(0, 28440 * Math.sin(clamp01((T - T0) / (TA - T0)) * PI)); }
function mins(){ return Math.round(40 * clamp01((T - T0) / (TA - T0))); }
// Aufstieg auf der anderen Seite (kopfüber, Füße zuerst)
function riseY(t){ return 3.8 - 0.526 * (t - TA) * (t - TA); }
const HOOK = [[2.6, 5.4, -6.0, 0, 0.6, 1.6, 50], [2.4, 5.2, -5.6, 0, 0.6, 1.6, 50]];
function hookBen(t){ bRest(ben, t, 0); const j = seg(t, 3.5, 4.0);
  if (t < 3.5){ place(ben, 0, 0, 3.1, PI); ben.head.rotation.x = 0.45; ben.torso.rotation.x = 0.12; eyeS = 1.15; bFace(ben, -0.3, 0.2 + 0.1 * Math.sin(t * 2)); ben.sh[0].rotation.set(-0.3, 0, -0.35); ben.sh[1].rotation.set(-0.3, 0, 0.35); }
  else { const y = t < 4.0 ? 0.9 * Math.sin(PI * j) : -14 * (t - 4.0) * (t - 4.0); place(ben, 0, y, 3.1 * (1 - E.io(j)), PI); flail(ben, t, 1); eyeS = 1.3; bFace(ben, -0.9, 0.8); ben.head.rotation.x = 0.2; } }

/* =========================================================
   SZENEN (Sprecherspur Tempo 1,1)
   ========================================================= */
const SCN = [
  { t: 0, set: GER, mood: MOOD.ger, hook: 1,
    upd(lt){ dT = T; show(ben); hookBen(T); camW(E.io(seg(lt, 0, 4.3)), HOOK[0], [2.2, 4.6, -5.0, 0, 0.2, 1.2, 50]); camFin(); } },
  { t: 4.3, set: TUN, mood: MOOD.tun, hud: () => ['FREIER FALL', 'OHNE LUFT UND HITZE'],
    upd(lt){ dT = T; show(ben); bRest(ben, T, 0); place(ben, 0, 0, 0, 0); flail(ben, T, 1); eyeS = 1.3; bFace(ben, -0.9, 0.7); ben.head.rotation.x = -0.35;
      const k = seg(T, 4.3, 7.94); tunnel(4 + 34 * k * k, 0.6 * k, 8 + 30 * k); spdK = E.out(seg(T, 4.6, 4.9)) * (1 - seg(T, 7.8, 7.94));
      camW(E.io(seg(lt, 0, 3.64)), [0.4, -4.6, 1.8, 0, 30, -2.6, 64], [0.3, -4.0, 1.6, 0, 30, -2.2, 60]); camFin(0.01); } },
  { t: 7.94, set: EAR, mood: MOOD.ear, hud: () => T < 11.2 ? ['ERDMITTELPUNKT', 'HÖCHSTES TEMPO'] : ['WEITER GEHT\'S', 'DURCH DEN KERN'],
    upd(lt){ dT = T; show(); DOT.position.set(0, 10 * Math.cos(PH(T)), 0); spdK = E.out(seg(T, 8.1, 8.4)) * (1 - seg(T, 12.5, 12.66)); lblK = E.out(seg(T, 8.2, 8.6)) * (1 - seg(T, 12.5, 12.66));
      camW(E.io(seg(lt, 0, 4.72)), [0, -3.5, 44, 0, -3.5, 0, 50], [0, -3.0, 36, 0, -3.0, 0, 50]); camFin(); } },
  { t: 12.66, set: TUN, mood: MOOD.tun, hud: () => ['SCHWERKRAFT BREMST', 'JETZT ZIEHT SIE ZURÜCK'],
    upd(lt){ dT = T; show(ben); bRest(ben, T, 0); place(ben, 0, 3.3, 0, 0); ben.root.rotation.z = PI; flail(ben, T, 0.6); eyeS = 1.2; bFace(ben, -0.5, 0.4);
      const k = seg(T, 12.66, 15.18); tunnel(38 - 32 * k, 0.6 * (1 - k), 34 * (1 - k) + 4); spdK = E.out(seg(T, 12.8, 13.1)) * (1 - seg(T, 15.0, 15.18));
      camW(E.io(seg(lt, 0, 2.52)), [0.4, -3.2, 2.0, 0, 30, -2.4, 64], [0.3, -2.8, 1.8, 0, 30, -2.0, 62]); camFin(); } },
  { t: 15.18, set: SND, mood: MOOD.snd, hud: () => ['ANDERE SEITE', 'FÜSSE ZUERST – KOPFÜBER!'],
    upd(lt){ dT = T; show(ben); bRest(ben, T, 0); place(ben, 0, riseY(T), 0, 0); ben.root.rotation.z = PI; eyeS = 1.1; bFace(ben, 0.2, 0.15); ben.sh[0].rotation.set(0, 0, -0.25); ben.sh[1].rotation.set(0, 0, 0.25);
      minK = E.out(seg(T, 15.4, 15.7)) * (1 - seg(T, 18.5, 18.7));
      camW(E.io(seg(lt, 0, 3.52)), [4.2, 3.0, 9.0, 0, 1.2, 0, 50], [3.4, 2.6, 7.6, 0, 1.6, 0, 50]); camFin(); } },
  { t: 18.7, set: SND, mood: MOOD.snd, hud: () => T < 20.3 ? ['FESTHALTEN!', 'SONST GEHT\'S ZURÜCK'] : ['DANEBEN', 'ZURÜCK INS LOCH'],
    upd(lt){ dT = T; show(ben); bRest(ben, T, 0); place(ben, 0, riseY(T), 0, 0); ben.root.rotation.z = PI; const g = E.out(seg(T, 18.8, 19.5));
      [0, 1].forEach(i => { const s = i ? 1 : -1; ben.sh[i].rotation.set(-PI * g, 0, s * (0.25 + 0.75 * g)); ben.el[i].rotation.x = -0.2 * g; });
      const miss = seg(T, 19.6, 20.0); eyeS = 1.0 + 0.3 * miss; bFace(ben, -0.9 * miss + 0.3 * (1 - miss), 0.2 + 0.7 * miss);
      camW(E.io(seg(lt, 0, 2.78)), [3.0, 2.6, 6.4, 0, 1.4, 0, 48], [2.6, 2.2, 5.6, 0, 0.6, 0, 50]); camFin(); } },
  { t: 21.48, set: EAR, mood: MOOD.ear, hud: () => ['FÜR IMMER', 'HIN UND HER'],
    upd(lt){ dT = T; show(); DOT.position.set(0, -10 * Math.cos((T - 21.48) * 4.2), 0); loopK = E.out(seg(T, 21.6, 21.9)) * (1 - seg(T, 22.45, 22.6));
      camW(E.io(seg(lt, 0, 1.12)), [0, -3.0, 38, 0, -3.0, 0, 50], [0, -3.0, 40, 0, -3.0, 0, 50]); camFin(); } },
  { t: 22.6, set: GER, mood: MOOD.ger, loopin: 1,
    upd(lt){ dT = T - END; show(ben); hookBen(T - END); camW(0, HOOK[0], HOOK[1]); camFin(); } },
];
const SUBS = __SUBS__;
