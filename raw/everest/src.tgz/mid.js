/* =========================================================
   STIMMUNG: Gipfel (statischer Himmel)
   ========================================================= */
function sky(){
  const c = document.createElement('canvas'); c.width = 4; c.height = 512; const x = c.getContext('2d'), g = x.createLinearGradient(0, 0, 0, 512);
  g.addColorStop(0, '#173f86'); g.addColorStop(0.5, '#4f8fd6'); g.addColorStop(1, '#cfe6f8'); x.fillStyle = g; x.fillRect(0, 0, 4, 512);
  const t = new THREE.CanvasTexture(c); t.encoding = THREE.sRGBEncoding; return t;
}
const MOOD = { peak: { sky: sky(), fog: [0xd6e8f6, 80, 420], hemi: [0xeaf4ff, 0x9aaac0, 0.95], sun: [0xfff6e6, 1.35], sp: [10, 18, 12] } };
const SR = 12; { const c = sun.shadow.camera; c.left = -SR; c.right = SR; c.top = SR; c.bottom = -SR; c.near = 1; c.far = 80; c.updateProjectionMatrix(); }
function setMood(m){
  scene.background = m.sky; scene.fog.color.set(m.fog[0]); scene.fog.near = m.fog[1]; scene.fog.far = m.fog[2]; scene.environment = envDay;
  hemi.color.set(m.hemi[0]); hemi.groundColor.set(m.hemi[1]); hemi.intensity = m.hemi[2]; sun.color.set(m.sun[0]); sun.intensity = m.sun[1];
  sun.position.set(m.sp[0], m.sp[1], m.sp[2]); sun.target.position.set(0, 0, 0); fill.color.set(0xdfe8ff); fill.intensity = 0.35; fill.position.set(-12, 6, 16);
}

/* =========================================================
   SETS: Gipfel + Lager
   ========================================================= */
const PEAK = new THREE.Group(), CAMP = new THREE.Group(); scene.add(PEAK, CAMP); const SETS = [PEAK, CAMP];
const SNOW = mat(0xf4f7fb, { roughness: 0.85, flatShading: true }), ROCK = mat(0x6d6a70, { roughness: 1, flatShading: true });
(function(){
  const m = P(PEAK, new THREE.ConeGeometry(14, 16, 9, 1), SNOW, 0, -8.05, 0); m.rotation.y = 0.3;
  [[-9, -12, -6, 9, 12], [10, -13, -9, 10, 11], [-4, -14, 9, 8, 9]].forEach(([x, y, z, r, h]) => { const c = P(PEAK, new THREE.ConeGeometry(r, h, 8, 1), ROCK, x, y, z); c.rotation.y = x; });
  const cl = mat(0xffffff, { roughness: 1 });
  [[-30, -16, -40, 14], [25, -15, -50, 18], [-10, -17, -70, 22], [40, -18, -25, 12], [-45, -18, -15, 13], [0, -18, -110, 30]].forEach(([x, y, z, r]) => { const o = P(PEAK, new THREE.SphereGeometry(1, 20, 12), cl, x, y, z); o.scale.set(r, r * 0.22, r * 0.7); o.castShadow = false; });
  [[-60, -10, -160, 30, 50], [70, -12, -180, 34, 46], [10, -15, -230, 40, 40]].forEach(([x, y, z, r, h]) => { const c = P(PEAK, new THREE.ConeGeometry(r, h, 7, 1), SNOW, x, y, z); c.castShadow = false; });
  const fl = [0x2f6fd0, 0xf2f2f2, 0xd8352a, 0x3aa65a, 0xf2c21a];
  for (let k = 0; k < 7; k++){ const f = P(PEAK, rbox(0.42, 0.5, 0.04, 0.02, 1), mat(fl[k % 5], { roughness: 0.8, side: THREE.DoubleSide }), -2.2 + k * 0.42, 0.9 - Math.abs(k - 3) * 0.08, -1.6); f.rotation.y = 0.1; }
  P(PEAK, new THREE.CylinderGeometry(0.06, 0.06, 1.4, 8), mat(0x6b4a2e), -2.5, 0.4, -1.6); P(PEAK, new THREE.CylinderGeometry(0.06, 0.06, 1.4, 8), mat(0x6b4a2e), 0.7, 0.4, -1.6);
  const g = P(CAMP, new THREE.PlaneGeometry(400, 400), mat(0xeef3f8, { roughness: 0.9 }), 0, 0, 0); g.rotation.x = -PI / 2;
  const tent = P(CAMP, new THREE.ConeGeometry(1.8, 2.0, 4, 1), mat(0xf07a24, { roughness: 0.7 }), -3.2, 1.0, -2.0); tent.rotation.y = PI / 4; tent.scale.set(1.3, 1, 1);
  const t2 = P(CAMP, new THREE.ConeGeometry(1.6, 1.8, 4, 1), mat(0xf2c21a, { roughness: 0.7 }), 3.6, 0.9, -4.0); t2.rotation.y = PI / 4;
  const big = P(CAMP, new THREE.ConeGeometry(70, 80, 9, 1), SNOW, 0, 32, -150); big.castShadow = false;
  [[-50, 20, -120, 40, 50], [60, 16, -130, 44, 44]].forEach(([x, y, z, r, h]) => { const c = P(CAMP, new THREE.ConeGeometry(r, h, 8, 1), ROCK, x, y, z); c.castShadow = false; });
})();
const PACK = new THREE.Group(); ben.torso.add(PACK); P(PACK, rbox(0.85, 0.95, 0.45, 0.1), mat(0x3a5f9a, { roughness: 0.7 }), 0, 0.55, -0.48); P(PACK, rbox(0.7, 0.2, 0.08, 0.04, 1), mat(0x2a456f), 0, 0.3, -0.72);
const BOT = new THREE.Group(); ben.el[1].add(BOT); BOT.position.set(0, -0.72, 0.1); P(BOT, new THREE.CylinderGeometry(0.17, 0.17, 0.9, 16), mat(0xf07a24, { roughness: 0.4, metalness: 0.3 }), 0, 0, 0); P(BOT, new THREE.CylinderGeometry(0.08, 0.1, 0.16, 12), mat(0x9aa2ae, { metalness: 0.6 }), 0, 0.52, 0);

/* =========================================================
   BEN
   ========================================================= */
const SCAR = new THREE.Group(); ben.head.add(SCAR);
(function(){ const m = mat(0xa8463f, { roughness: 0.7 }); const s = new THREE.Mesh(rbox(0.075, 0.72, 0.03, 0.012, 1), m); s.position.set(0.25, 0.55, 0.522); s.rotation.z = -0.13; SCAR.add(s);
  for (const y of [0.36, 0.55, 0.74]){ const c = new THREE.Mesh(rbox(0.16, 0.035, 0.03, 0.01, 1), m); c.position.set(0.25 + (y - 0.55) * 0.13, y, 0.528); c.rotation.z = -0.13; SCAR.add(c); } })();
function gasp(r, t, k){ const b = Math.sin(t * 7); r.torso.rotation.x = (0.28 + 0.05 * b) * k; r.torso.scale.y = 1 + 0.03 * b * k; r.sh[0].rotation.set(-0.5 * k, 0, -0.25 * k - 0.07); r.sh[1].rotation.set(-0.5 * k, 0, 0.25 * k + 0.07); r.el[0].rotation.x = -0.6 * k; r.el[1].rotation.x = -0.6 * k;
  r.legs[0].rotation.x = -0.15 * k; r.legs[1].rotation.x = 0.1 * k; r.body.position.y = 1 - 0.06 * k; r.head.rotation.x = -0.15 * k; bFace(r, -0.6 * k, (0.35 + 0.25 * Math.max(0, b)) * k); }

/* =========================================================
   KAMERA + Zustand
   ========================================================= */
const cL = new THREE.Vector3();
let blurAmt = 0, fadeBlk = 0, T = 0, flashA = 0, eyeS = 1, talk = 0, dT = 0;
let o2K = 0, beamK = 0, minK = 0, cellK = 0, mesK = 0, altK = 0;
function camW(p, a, b){ cam.position.set(lerp(a[0], b[0], p), lerp(a[1], b[1], p), lerp(a[2], b[2], p)); cL.set(lerp(a[3], b[3], p), lerp(a[4], b[4], p), lerp(a[5], b[5], p)); cam.fov = lerp(a[6], b[6], p); }
function camFin(sh){ cam.position.x += Math.sin(dT * 0.7) * 0.02; cam.position.y += Math.sin(dT * 0.9 + 1) * 0.015; if (sh){ cam.position.x += Math.sin(T * 23) * sh; cam.position.y += Math.cos(T * 17) * sh; } cam.up.set(0, 1, 0); cam.lookAt(cL); cam.updateProjectionMatrix(); cam.updateMatrixWorld(); }
const HOOK = [[4.2, 3.6, 14.0, 0.2, 3.0, 0, 40], [3.7, 3.4, 12.8, 0.2, 2.9, 0, 40]];
const CS = [3.4, 2.4, 11.0, 0.2, 1.4, 0, 40];
function base(){ show(ben); BOT.visible = false; PACK.visible = true; }
function hookBen(t){ bRest(ben, t, 0); place(ben, 0, 0, 0, 0.35); gasp(ben, t, 1); eyeS = 0.85; }

/* =========================================================
   SZENEN (Sprecherspur Tempo 1,25)
   ========================================================= */
const SCN = [
  { t: 0, set: PEAK, mood: MOOD.peak, hook: 1,
    upd(lt){ dT = T; base(); hookBen(T); camW(E.io(seg(lt, 0, 3.36)), HOOK[0], HOOK[1]); camFin(); } },
  { t: 3.36, set: PEAK, mood: MOOD.peak, hud: () => ['NUR EIN DRITTEL', 'SAUERSTOFF PRO ATEMZUG'],
    upd(lt){ dT = T; base(); hookBen(T); o2K = E.out(seg(T, 3.6, 3.9)) * (1 - seg(T, 6.75, 6.96)); camW(E.io(seg(lt, 0, 3.6)), HOOK[1], CS); camFin(); } },
  { t: 6.96, set: PEAK, mood: MOOD.peak, hud: () => T < 8.9 ? ['DIREKT HOCHBEAMEN?', 'OHNE GEWÖHNUNG'] : ['BEWUSSTLOS', 'NACH WENIGEN MINUTEN'],
    upd(lt){ dT = T; base(); bRest(ben, T, 0); const ap = E.out(seg(T, 7.3, 8.0)), fall = E.io(seg(T, 9.2, 10.3));
      place(ben, 0, 0, 0, 0.35); ben.root.visible = T > 7.42;
      gasp(ben, T, 1 - fall * 0.5); ben.root.rotation.z = 0.0; ben.body.position.y = lerp(ben.body.position.y, 0.28, fall); ben.legs[0].rotation.x = lerp(ben.legs[0].rotation.x, -1.5, fall); ben.legs[1].rotation.x = lerp(ben.legs[1].rotation.x, -1.5, fall);
      ben.torso.rotation.x = lerp(ben.torso.rotation.x, 0.6, fall); ben.head.rotation.set(0.5 * fall, 0, 0.3 * fall); eyeS = lerp(1.2, 0.08, seg(T, 9.6, 10.2)); if (fall > 0.5) bFace(ben, 0.2, 0.15);
      beamK = bump(T, 7.0, 8.4); flashA = 0.5 * bump(T, 7.25, 7.6); minK = E.out(seg(T, 9.0, 9.3)) * (1 - seg(T, 10.55, 10.74));
      camW(0, CS, CS); camFin(); } },
  { t: 10.74, set: CAMP, mood: MOOD.peak, hud: () => ['WOCHENLANG GEWÖHNEN', 'MEHR ROTE BLUTKÖRPERCHEN'],
    upd(lt){ dT = T; base(); bRest(ben, T, 0); place(ben, 0.6, 0, 0.5, 0.25); const s = Math.sin(T * 2); ben.sh[0].rotation.set(0, 0, -0.07); ben.sh[1].rotation.set(-0.4 + 0.15 * s, 0, 0.3); eyeS = 1; bFace(ben, 0.4, 0.05);
      cellK = E.out(seg(T, 11.0, 11.3)) * (1 - seg(T, 15.0, 15.2)); camW(E.io(seg(lt, 0, 4.46)), [3.5, 3.0, 12.5, 0, 2.4, -2, 40], [3.0, 2.8, 11.2, 0, 2.3, -2, 40]); camFin(); } },
  { t: 15.2, set: PEAK, mood: MOOD.peak, hud: () => ['1978', 'ERSTMALS OHNE FLASCHE'],
    upd(lt){ dT = T; base(); bRest(ben, T, 0); place(ben, 0, 0, 0, 0.35); gasp(ben, T, 0.4); ben.sh[1].rotation.set(-2.7, 0, 0.2); ben.el[1].rotation.x = -0.1; eyeS = 1; bFace(ben, 0.6, 0.3);
      mesK = E.out(seg(T, 15.4, 15.7)) * (1 - seg(T, 18.95, 19.17)); camW(E.io(seg(lt, 0, 3.97)), [-3.2, 2.2, 11.5, 0, 1.6, 0, 40], [-2.8, 2.4, 10.4, 0, 1.6, 0, 40]); camFin(); } },
  { t: 19.17, set: PEAK, mood: MOOD.peak, hud: () => ['ÜBER 8000 METER', 'TODESZONE'],
    upd(lt){ dT = T; base(); hookBen(T); altK = E.out(seg(T, 19.3, 19.6)) * (1 - seg(T, 21.8, 21.97)); camW(E.io(seg(lt, 0, 2.8)), [6.5, 3.4, 18.0, 0.0, 1.0, 0, 40], [6.0, 3.6, 16.6, 0.0, 1.0, 0, 40]); camFin(); } },
  { t: 21.97, set: PEAK, mood: MOOD.peak, hud: () => ['UND BEN?', 'FLASCHE KOMMT MIT'],
    upd(lt){ dT = T - END; base(); hookBen(T - END); const pk = E.io(seg(T, 22.9, 23.55)), w = 1 - E.io(seg(T, 23.5, 23.85)); BOT.visible = T < 23.52; const gx = ben.sh[1].rotation.x, gz = ben.sh[1].rotation.z, ge = ben.el[1].rotation.x;
      ben.sh[1].rotation.set(lerp(gx, lerp(-1.1, 0.6, pk), w), 0, lerp(gz, lerp(0.1, 0.5, pk), w)); ben.el[1].rotation.x = lerp(ge, lerp(-0.9, -1.8, pk), w); if (w > 0.5) bFace(ben, 0.5 * (1 - pk), 0.3); camW(E.io(seg(T, 21.97, 23.9)), [3.0, 2.6, 10.0, 0.2, 1.8, 0, 40], HOOK[0]); camFin(); } },
  { t: 23.9, set: PEAK, mood: MOOD.peak, loopin: 1,
    upd(lt){ dT = T - END; base(); hookBen(T - END); camW(0, HOOK[0], HOOK[1]); camFin(); } },
];
const SUBS = __SUBS__;
