/* =========================================================
   STIMMUNG: Kabine innen / Himmel außen
   ========================================================= */
function sky(stops){
  const c = document.createElement('canvas'); c.width = 4; c.height = 256; const x = c.getContext('2d'), g = x.createLinearGradient(0, 0, 0, 256);
  stops.forEach(s => g.addColorStop(s[0], s[1])); x.fillStyle = g; x.fillRect(0, 0, 4, 256); const t = new THREE.CanvasTexture(c); t.encoding = THREE.sRGBEncoding; return t;
}
const MOOD = {
  cabin: { sky: sky([[0, '#3a6fb8'], [1, '#cfe4f7']]), fog: [0xf2f4f7, 60, 200], hemi: [0xfffaf0, 0x8a8478, 1.0], sun: [0xfff4e0, 0.75], env: 1, sp: [-3, 14, -10] },
  sky: { sky: sky([[0, '#1f5fb8'], [0.55, '#6fa8e8'], [1, '#d8ecfb']]), fog: [0xd8ecfb, 80, 260], hemi: [0xeaf4ff, 0xb8c4d0, 1.0], sun: [0xfff2d8, 1.15], env: 1, sp: [-8, 20, 14] },
};
const SR = 9; { const c = sun.shadow.camera; c.left = -SR; c.right = SR; c.top = SR; c.bottom = -SR; c.near = 1; c.far = 60; c.updateProjectionMatrix(); }
function setMood(m){
  scene.background = m.sky; scene.fog.color.set(m.fog[0]); scene.fog.near = m.fog[1]; scene.fog.far = m.fog[2]; scene.environment = m.env ? envDay : envNight;
  hemi.color.set(m.hemi[0]); hemi.groundColor.set(m.hemi[1]); hemi.intensity = m.hemi[2]; sun.color.set(m.sun[0]); sun.intensity = m.sun[1];
  sun.position.set(m.sp[0], m.sp[1], m.sp[2]); sun.target.position.set(1.5, 1.5, 0); fill.color.set(0xffffff); fill.intensity = 0.35; fill.position.set(-10, 8, -30);
}

/* =========================================================
   SET 1: Kabine (Rumpf als Zylinder, Ben am Fenster rechts)
   ========================================================= */
const CABIN = new THREE.Group(); scene.add(CABIN);
const WIN = new THREE.Vector3(4.05, 2.55, -0.25);
let pane = null; const MASK = [];
(function(){
  const hull = new THREE.Mesh(new THREE.CylinderGeometry(4.2, 4.2, 40, 64, 1, true), new THREE.MeshStandardMaterial({ color: 0xe9e6df, roughness: 0.85, side: THREE.BackSide }));
  hull.rotation.x = PI / 2; hull.position.y = 1.8; hull.receiveShadow = true; CABIN.add(hull);
  const fl = new THREE.Mesh(new THREE.PlaneGeometry(8, 40), new THREE.MeshStandardMaterial({ color: 0x59606c, roughness: 0.95 })); fl.rotation.x = -PI / 2; fl.receiveShadow = true; CABIN.add(fl);
  // Gepäckfächer rechts + Panel
  const bin = mat(0xf2f0ea, { roughness: 0.6 });
  P(CABIN, rbox(1.3, 0.9, 40, 0.08, 1), bin, 3.0, 4.75, 0);
  P(CABIN, rbox(1.6, 0.08, 1.2, 0.03, 1), mat(0xdedbd2), 1.95, 4.27, -0.5);
  // Sitzreihen (Ben-Reihe z = 0, dahinter z = 3)
  const seatM = mat(0x2a3a6a, { roughness: 0.8 }), arm = mat(0x9aa0aa, { roughness: 0.5 });
  [0, 3.1, 6.2].forEach(z => [2.45, 0.8].forEach(x => { P(CABIN, rbox(1.55, 0.32, 1.35, 0.1), seatM, x, 0.62, z); P(CABIN, rbox(1.55, 2.0, 0.3, 0.12), seatM, x, 1.75, z + 0.68);
    P(CABIN, rbox(1.2, 0.35, 0.2, 0.08), mat(0xe8e6e0), x, 2.62, z + 0.62); P(CABIN, rbox(0.4, 0.55, 1.3, 0.05), mat(0x23304f), x, 0.24, z); }));
  [3.25, 1.62, -0.0].forEach(x => P(CABIN, rbox(0.12, 0.12, 1.2, 0.04, 1), arm, x, 1.15, 0));
  P(CABIN, rbox(1.2, 0.14, 0.72, 0.05, 1), mat(0x6a6e78, { roughness: 0.6 }), 2.45, 0.95, 0.05);   // Gurt über dem Schoß
  // Fenster (Himmel + Scheibe + Rahmen)
  const sc = document.createElement('canvas'); sc.width = 64; sc.height = 128; const x = sc.getContext('2d'), g = x.createLinearGradient(0, 0, 0, 128); g.addColorStop(0, '#4f8fdc'); g.addColorStop(0.6, '#bcdcf6'); g.addColorStop(0.62, '#ffffff'); g.addColorStop(1, '#e8eef4'); x.fillStyle = g; x.fillRect(0, 0, 64, 128);
  const st = new THREE.CanvasTexture(sc); st.encoding = THREE.sRGBEncoding;
  const sk = new THREE.Mesh(new THREE.PlaneGeometry(0.78, 1.04), new THREE.MeshBasicMaterial({ map: st })); sk.position.copy(WIN).add(new THREE.Vector3(0.06, 0, 0)); sk.rotation.y = -PI / 2; CABIN.add(sk);
  pane = new THREE.Mesh(new THREE.PlaneGeometry(0.78, 1.04), new THREE.MeshStandardMaterial({ color: 0xcfe6ff, transparent: true, opacity: 0.25, roughness: 0.05, depthWrite: false })); pane.position.copy(WIN).add(new THREE.Vector3(0.02, 0, 0)); pane.rotation.y = -PI / 2; CABIN.add(pane);
  const fr = mat(0xf7f6f2, { roughness: 0.5 });
  [[0, 0.62, 1.0, 0.2], [0, -0.62, 1.0, 0.2], [0.49, 0, 0.2, 1.44], [-0.49, 0, 0.2, 1.44]].forEach(([dz, dy, w, h]) => { const m = P(CABIN, rbox(0.1, h, w, 0.04, 1), fr, WIN.x - 0.02, WIN.y + dy, WIN.z + dz); m.castShadow = false; });
  // Sauerstoffmasken (Becher + Schlauch)
  [[2.35, 3.25, -0.6], [1.2, 3.25, -0.6]].forEach(([mx, my, mz]) => { const cup = P(CABIN, new THREE.CylinderGeometry(0.15, 0.2, 0.22, 16), mat(0xf2c21b, { roughness: 0.5 }), mx, my, mz);
    const tube = P(CABIN, new THREE.CylinderGeometry(0.02, 0.02, 1, 6), mat(0xe8e8e8), mx, my, mz); MASK.push({ cup, tube, hang: new THREE.Vector3(mx, my, mz), top: new THREE.Vector3(mx * 0.5 + 0.9, 4.24, -0.5) }); });
})();
const _ma = new THREE.Vector3(), _mb = new THREE.Vector3(), _up = new THREE.Vector3(0, 1, 0);
function maskAt(i, p, vis){ const M = MASK[i]; M.cup.visible = M.tube.visible = vis; if (!vis) return; M.cup.position.copy(p); M.cup.rotation.set(-PI / 2, 0, 0);
  _ma.subVectors(M.top, p); const L = _ma.length(); M.tube.position.copy(p).addScaledVector(_ma, 0.5); M.tube.scale.set(1, L, 1); M.tube.quaternion.setFromUnitVectors(_up, _ma.normalize()); }

/* =========================================================
   SET 2: Außen – Flugzeug über den Wolken
   ========================================================= */
const SKYS = new THREE.Group(); scene.add(SKYS);
const PLN = new THREE.Group(), CLD = new THREE.Group(); SKYS.add(PLN, CLD);
(function(){
  const w = mat(0xf4f5f7, { roughness: 0.45, metalness: 0.1 }), bl = mat(0x2a5ab8, { roughness: 0.5 }), gr = mat(0xb8bec8, { roughness: 0.5, metalness: 0.3 });
  const f = P(PLN, new THREE.CylinderGeometry(1.0, 1.0, 12, 32), w, 0, 0, 0); f.rotation.z = PI / 2;
  const n = P(PLN, new THREE.SphereGeometry(1.0, 24, 16), w, 6, 0, 0); n.scale.set(1.4, 1, 1);
  const tc = P(PLN, new THREE.ConeGeometry(1.0, 3.2, 24), w, -7.6, 0.25, 0); tc.rotation.z = PI / 2; tc.scale.set(1, 1, 0.9);
  P(PLN, rbox(2.2, 2.6, 0.18, 0.08), bl, -8.0, 1.8, 0); P(PLN, rbox(1.8, 0.14, 4.6, 0.06), w, -8.2, 0.5, 0);
  P(PLN, rbox(2.4, 0.18, 14, 0.08), w, -0.4, -0.45, 0);
  [-3.2, 3.2].forEach(z => { const e = P(PLN, new THREE.CylinderGeometry(0.42, 0.38, 1.8, 20), gr, 0.6, -0.95, z); e.rotation.z = PI / 2; });
  for (let i = 0; i < 14; i++){ const xx = 4.2 - i * 0.62; if (i === 6) P(PLN, rbox(0.3, 0.38, 0.04, 0.05, 1), mat(0x111418), xx, 0.25, 0.99); else P(PLN, rbox(0.22, 0.3, 0.04, 0.05, 1), mat(0x22324a, { roughness: 0.2 }), xx, 0.25, 0.99); }
  P(PLN, rbox(12, 0.16, 0.05, 0.03, 1), bl, -0.3, -0.25, 0.99);
  const cm = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 1, emissive: 0xffffff, emissiveIntensity: 0.25 });
  let sd = 3; const r = () => { sd = (sd * 16807) % 2147483647; return sd / 2147483647; };
  for (let i = 0; i < 70; i++){ const c = new THREE.Mesh(new THREE.SphereGeometry(1, 14, 10), cm); const s = 3 + r() * 5; c.scale.set(s * 1.6, s * 0.55, s); c.position.set(-90 + r() * 180, r() * 2, -70 + r() * 60); CLD.add(c); }
})();
const SETS = [CABIN, SKYS];

/* =========================================================
   FIGUREN
   ========================================================= */
const SCAR = new THREE.Group(); ben.head.add(SCAR);
(function(){ const m = mat(0xa8463f, { roughness: 0.7 }); const s = new THREE.Mesh(rbox(0.075, 0.72, 0.03, 0.012, 1), m); s.position.set(0.25, 0.55, 0.522); s.rotation.z = -0.13; SCAR.add(s);
  for (const y of [0.36, 0.55, 0.74]){ const c = new THREE.Mesh(rbox(0.16, 0.035, 0.03, 0.01, 1), m); c.position.set(0.25 + (y - 0.55) * 0.13, y, 0.528); c.rotation.z = -0.13; SCAR.add(c); } })();
const pro = boxer({ top: 0x3cae6a, pants: 0x1f2a44, shoe: 0x1c1c22, hair: 0x8a5a2a, skin: 0xf2c6a2 }); ALL.push(pro); scene.add(pro.root);
[ben, pro].forEach(r => { r.L1 = 0.46; r.L2 = 0.56; });
const _ia = new THREE.Vector3(), _ib = new THREE.Vector3(), _ic = new THREE.Vector3(), _id = new THREE.Vector3(), _ie = new THREE.Vector3(), _if = new THREE.Vector3(), _ig = new THREE.Vector3(), _ih = new THREE.Vector3();
const _iq = new THREE.Quaternion(), _qa = new THREE.Quaternion(), _qb = new THREE.Quaternion(), _dn = new THREE.Vector3(0, -1, 0);
function ik(r, i, tw, pw){
  r.torso.updateWorldMatrix(true, false);
  const tl = r.torso.worldToLocal(_ia.copy(tw)); r.torso.getWorldQuaternion(_iq); const pl = _ib.copy(pw).applyQuaternion(_iq.invert());
  const S = _ic.set(i ? 0.67 : -0.67, 0.92, 0), D = _id.subVectors(tl, S), L1 = r.L1, L2 = r.L2;
  const d = Math.min(Math.max(D.length(), 0.15), L1 + L2 - 0.002); D.normalize();
  const a = Math.acos(Math.max(-1, Math.min(1, (L1 * L1 + d * d - L2 * L2) / (2 * L1 * d))));
  const n = _ie.crossVectors(D, pl).normalize(), e = _if.copy(D).applyAxisAngle(n, a);
  _qa.setFromUnitVectors(_dn, e); r.sh[i].quaternion.copy(_qa);
  const f = _ih.subVectors(tl, _ig.copy(S).addScaledVector(e, L1)).normalize().applyQuaternion(_qb.copy(_qa).invert());
  r.el[i].quaternion.setFromUnitVectors(_dn, f);
}
const BS = [2.45, 0, 0.08], PS = [0.8, 0, 0.08], SEATY = 0.62;
// sitzen: Hüfte auf dem Polster, Hände im Schoß
function seated(r, p){ bRest(r, T, r === ben ? 0 : 2); place(r, p[0], p[1], p[2], PI); sit(r, SEATY); r.sh[0].rotation.set(-0.55, 0, -0.1); r.sh[1].rotation.set(-0.55, 0, 0.1); r.el[0].rotation.set(-0.7, 0, 0); r.el[1].rotation.set(-0.7, 0, 0); }
function faceW(r, o){ r.head.updateWorldMatrix(true, false); return r.head.localToWorld(o.set(0, 0.42, 0.72)); }
const _fa = new THREE.Vector3(), _fb = new THREE.Vector3();

/* =========================================================
   KAMERA + Zustand
   ========================================================= */
const cL = new THREE.Vector3();
let blurAmt = 0, fadeBlk = 0, T = 0, flashA = 0, eyeS = 1, talk = 0, dT = 0;
let crackK = 0, streakK = 0, fogA = 0, thermK = 0, cntK = 0, darkK = 0, zoneK = 0, altK = 0, passK = 0;
function camW(p, a, b){ cam.position.set(lerp(a[0], b[0], p), lerp(a[1], b[1], p), lerp(a[2], b[2], p)); cL.set(lerp(a[3], b[3], p), lerp(a[4], b[4], p), lerp(a[5], b[5], p)); cam.fov = lerp(a[6], b[6], p); }
function camFin(sh){ cam.position.x += Math.sin(dT * 0.7) * 0.012; cam.position.y += Math.sin(dT * 0.9 + 1) * 0.008; if (sh){ cam.position.x += Math.sin(T * 23) * sh; cam.position.y += Math.cos(T * 17) * sh; } cam.up.set(0, 1, 0); cam.lookAt(cL); cam.updateProjectionMatrix(); cam.updateMatrixWorld(); }
const imp = at => T >= at ? Math.exp(-(T - at) * 3) : 0;
const BURST = 2.75;
const fogK = t => E.out(seg(t, BURST, BURST + 1.0)) * (1 - 0.75 * E.io(seg(t, 6.6, 9.6))) * (1 - E.io(seg(t, 9.6, 12.5)));
const pullK = t => t > BURST ? Math.exp(-(t - BURST) * 1.1) : 0;
const HOOK = [[-1.3, 3.5, -6.4, 2.3, 2.4, 0.2, 40], [-0.8, 3.35, -5.6, 2.5, 2.4, 0.1, 38]];
function base(){ show(ben); pane.visible = true; MASK.forEach((M, i) => maskAt(i, M.hang, false)); scene.fog.far = 200; scene.fog.near = 60; }
function hookPose(t){ base(); seated(ben, BS); ben.head.rotation.y = -0.9; eyeS = 1; bFace(ben, 0.3, 0.05); }
function cabinFog(t){ const k = fogK(t); fogA = 0.36 * k; scene.fog.color.set(0xf2f4f7); scene.fog.near = lerp(60, 0.5, k); scene.fog.far = lerp(200, 11, k); }
function benStorm(t){ seated(ben, BS); const p = pullK(t); ben.head.rotation.y = -0.9 * (1 - seg(t, BURST, BURST + 0.4)) - 0.35 * p; ben.head.rotation.z = 0.12 * p;
  ben.sh[0].rotation.set(-0.4 - 0.4 * p, 0, -0.1 - 1.0 * p + 0.06 * p * Math.sin(t * 30)); ben.torso.rotation.z = 0.08 * p; }

/* =========================================================
   SZENEN (gekürzte Sprecherspur, Tempo 1,25)
   ========================================================= */
const SCN = [
  { t: 0, set: CABIN, mood: MOOD.cabin, hook: 1,
    upd(lt){ dT = T; base(); crackK = E.io(seg(T, 0.3, 2.7)); if (T < BURST){ hookPose(T); bFace(ben, T > 1.2 ? -0.4 : 0.3, T > 1.2 ? 0.3 : 0.05); eyeS = T > 1.2 ? 1.3 : 1; }
      else { crackK = 0; pane.visible = false; benStorm(T); eyeS = 1.45; bFace(ben, -0.9, 0.9); }
      cabinFog(T); streakK = E.out(seg(T, BURST, BURST + 0.15)) * (1 - seg(T, 4.6, 5.4));
      camW(E.io(seg(lt, 0, 3.45)), HOOK[0], HOOK[1]); camFin(0.06 * imp(BURST)); } },
  { t: 3.45, set: CABIN, mood: MOOD.cabin, hud: () => ['NEBEL IN 1 SEKUNDE', 'LUFT KÜHLT SCHLAGARTIG AB'],
    upd(lt){ dT = T; base(); pane.visible = false; benStorm(T); eyeS = 1.4; bFace(ben, -0.8, 0.7); cabinFog(T); streakK = 1 - seg(T, 4.6, 5.4);
      camW(E.io(seg(lt, 0, 3.55)), [-1.0, 3.3, -5.8, 2.6, 2.4, 0.0, 40], [-0.4, 3.2, -5.2, 2.7, 2.4, 0.0, 39]); camFin(0.02 * pullK(T)); } },
  { t: 7.0, set: CABIN, mood: MOOD.cabin, hud: () => ['DRAUSSEN: -50 °C', 'UND KAUM SAUERSTOFF'],
    upd(lt){ dT = T; base(); pane.visible = false; benStorm(T); ben.sh[0].rotation.x = -0.9; ben.sh[1].rotation.x = -0.9; ben.sh[0].rotation.z = -0.3; ben.sh[1].rotation.z = 0.3; eyeS = 1.2; bFace(ben, -0.6, 0.3);
      cabinFog(T); thermK = E.out(seg(T, 7.1, 7.4)) * (1 - seg(T, 9.55, 9.75));
      camW(E.io(seg(lt, 0, 2.75)), [0.4, 3.1, -4.4, 3.0, 2.5, 0.0, 38], [0.8, 3.0, -4.0, 3.0, 2.5, 0.0, 37]); camFin(); } },
  { t: 9.75, set: CABIN, mood: MOOD.cabin, hud: () => ['NUR CA. 30 SEKUNDEN', 'DANN WIRD BEN OHNMÄCHTIG'],
    upd(lt){ dT = T; base(); pane.visible = false; seated(ben, BS); const d = seg(T, 10.4, 12.3); ben.head.rotation.x = 0.25 * d + 0.12 * d * Math.sin(T * 2.2); ben.head.rotation.z = 0.1 * d * Math.sin(T * 1.3);
      eyeS = lerp(1, 0.3, d); bFace(ben, 0.4 * d, 0.15); cabinFog(T); cntK = E.out(seg(T, 9.85, 10.15)) * (1 - seg(T, 12.35, 12.55)); darkK = 0.5 * E.io(seg(T, 10.0, 12.3)) * (1 - seg(T, 12.4, 12.55));
      camW(E.io(seg(lt, 0, 2.8)), [1.2, 2.9, -3.7, 2.45, 2.45, 0.1, 36], [1.4, 2.85, -3.3, 2.45, 2.45, 0.1, 34]); camFin(); } },
  { t: 12.55, set: CABIN, mood: MOOD.cabin, hud: () => T < 13.7 ? ['RAUSGESAUGT?', 'NEIN – DAS LOCH IST KLEIN'] : ['SOG NUR AM LOCH', 'ANGESCHNALLT BLEIBEN!'],
    upd(lt){ dT = T; base(); pane.visible = false; seated(ben, BS); ben.head.rotation.x = 0.2; eyeS = 0.5; bFace(ben, 0.3, 0.1); cabinFog(T); zoneK = E.out(seg(T, 12.7, 13.0)) * (1 - seg(T, 14.85, 15.05));
      camW(E.io(seg(lt, 0, 2.5)), [0.9, 5.3, -3.6, 2.6, 1.0, 0.2, 46], [1.1, 5.4, -3.2, 2.7, 1.0, 0.2, 46]); camFin(); } },
  { t: 15.08, set: CABIN, mood: MOOD.cabin, hud: () => T < 17.55 ? ['PROFI', 'ERST DIE EIGENE MASKE'] : ['DANN DEM NACHBARN', 'SAUERSTOFF FÜR BEN'],
    upd(lt){ dT = T; base(); pane.visible = false; pro.root.visible = true; seated(ben, BS); seated(pro, PS);
      const drop = E.out(seg(T, 15.15, 15.55)), bounce = 0.06 * Math.sin(seg(T, 15.55, 16.1) * PI * 3) * (1 - seg(T, 15.55, 16.1));
      const hang = i => _ma.copy(MASK[i].hang).add(new THREE.Vector3(0, (1 - drop) * 0.95 + bounce, 0));
      const pf = faceW(pro, _fa), bf = faceW(ben, _fb);
      // Profi: eigene Maske (Arm 1), dann Bens Maske (Arm 0)
      const g1 = E.io(seg(T, 15.6, 16.0)), m1 = E.io(seg(T, 16.0, 16.55)), r1 = E.io(seg(T, 16.6, 17.0));
      const p1 = new THREE.Vector3().copy(hang(1)).lerp(pf, m1); maskAt(1, p1, true);
      if (g1 > 0 && r1 < 1){ const h = new THREE.Vector3().copy(p1).add(new THREE.Vector3(0, -0.12, 0)); const rest = new THREE.Vector3(0.2, 1.3, -0.5); ik(pro, 1, rest.lerp(h, g1 * (1 - r1)), new THREE.Vector3(-0.5, -1, 0)); }
      const g0 = E.io(seg(T, 16.9, 17.35)), m0 = E.io(seg(T, 17.35, 17.95)), r0 = E.io(seg(T, 18.0, 18.3));
      const p0 = new THREE.Vector3().copy(hang(0)).lerp(bf, m0); maskAt(0, p0, true);
      if (g0 > 0 && r0 < 1){ const h = new THREE.Vector3().copy(p0).add(new THREE.Vector3(-0.15, -0.1, 0)); const rest = new THREE.Vector3(1.4, 1.3, -0.5); ik(pro, 0, rest.lerp(h, g0 * (1 - r0)), new THREE.Vector3(0.3, -1, 0)); }
      const wake = E.io(seg(T, 17.95, 18.3)); ben.head.rotation.x = 0.2 * (1 - wake); eyeS = lerp(0.45, 1, wake); bFace(ben, 0.3, 0.1); bFace(pro, 0.4, 0.05); pro.head.rotation.y = T > 16.8 ? -0.45 * E.io(seg(T, 16.8, 17.2)) : 0;
      camW(E.io(seg(lt, 0, 3.27)), [-0.9, 3.35, -5.2, 1.7, 2.6, 0.1, 40], [-0.6, 3.3, -4.8, 1.8, 2.6, 0.1, 39]); camFin(); } },
  { t: 18.35, set: SKYS, mood: MOOD.sky, hud: () => ['SINKFLUG', 'RUNTER AUF 3 KM'],
    upd(lt){ dT = T; base(); ben.root.visible = false; const u = seg(T, 18.5, 21.8);
      PLN.position.set(0, 0, 0); PLN.rotation.set(0, 0, -0.16 * E.io(seg(T, 18.4, 18.9))); CLD.position.set(-6 * (T - 18.35), -22 + 14 * E.io(u), 0);
      altK = E.out(seg(T, 18.45, 18.75)) * (1 - seg(T, 21.75, 21.95));
      camW(E.io(seg(lt, 0, 3.6)), [3.0, 1.6, 22, -0.5, 0, 0, 40], [2.0, 1.2, 20, -0.5, -0.4, 0, 40]); camFin(); } },
  { t: 21.95, set: CABIN, mood: MOOD.cabin, hud: () => ['UND BEN?', 'WIEDER AM FENSTER'],
    upd(lt){ dT = T; base(); bRest(ben, T, 0); const w = seg(T, 22.0, 22.85), tn = E.io(seg(T, 22.8, 23.2)), sd = E.io(seg(T, 23.15, 23.7));
      if (T < 23.15){ place(ben, lerp(0.1, BS[0], E.io(w)), 0, lerp(-1.55, -1.3, tn), lerp(PI / 2, PI, tn)); if (w < 1) wlk(ben, w * PI * 4, Math.sin(PI * w)); }
      else { place(ben, BS[0], 0, lerp(-1.3, BS[2], sd), PI); const b = ben.body.position.y; sit(ben, SEATY); ben.body.position.y = lerp(1, ben.body.position.y, sd); ben.legs[0].rotation.x *= sd; ben.legs[1].rotation.x *= sd; ben.torso.rotation.x *= sd;
        ben.sh[0].rotation.set(-0.55 * sd, 0, -0.1); ben.sh[1].rotation.set(-0.55 * sd, 0, 0.1); ben.el[0].rotation.set(-0.7 * sd, 0, 0); ben.el[1].rotation.set(-0.7 * sd, 0, 0); }
      ben.head.rotation.y = -0.9 * E.io(seg(T, 23.6, 24.1)); eyeS = 1; bFace(ben, 0.3, 0.05); passK = E.out(seg(T, 22.05, 22.35)) * (1 - seg(T, 23.5, 23.75));
      camW(E.io(seg(lt, 0, 2.2)), [-1.8, 3.7, -6.8, 1.4, 2.2, 0, 42], HOOK[0]); camFin(); } },
  { t: 24.2, set: CABIN, mood: MOOD.cabin, loopin: 1,
    upd(lt){ dT = T - END; hookPose(0); camW(0, HOOK[0], HOOK[1]); camFin(); } },
];
const SUBS = __SUBS__;
