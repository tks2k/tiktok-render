/* =========================================================
   STIMMUNG: Gewitter, dunkelgrün-grauer Himmel
   ========================================================= */
function sky(stops){
  const c = document.createElement('canvas'); c.width = 4; c.height = 256; const x = c.getContext('2d'), g = x.createLinearGradient(0, 0, 0, 256);
  stops.forEach(s => g.addColorStop(s[0], s[1])); x.fillStyle = g; x.fillRect(0, 0, 4, 256); const t = new THREE.CanvasTexture(c); t.encoding = THREE.sRGBEncoding; return t;
}
const MOOD = { storm: { sky: sky([[0, '#2a3238'], [0.55, '#4a5a5a'], [1, '#7a8a84']]), fog: [0x5a6a68, 25, 110], hemi: [0xc8d4d8, 0x404a40, 0.75], sun: [0xdde6ea, 0.7] } };
const SR = 16; { const c = sun.shadow.camera; c.left = -SR; c.right = SR; c.top = SR; c.bottom = -SR; c.near = 1; c.far = 80; c.updateProjectionMatrix(); }
function setMood(m){
  scene.background = m.sky; scene.fog.color.set(m.fog[0]); scene.fog.near = m.fog[1]; scene.fog.far = m.fog[2]; scene.environment = envDay;
  hemi.color.set(m.hemi[0]); hemi.groundColor.set(m.hemi[1]); hemi.intensity = m.hemi[2]; sun.color.set(m.sun[0]); sun.intensity = m.sun[1];
  sun.position.set(-10, 30, 14); sun.target.position.set(0, 0, 0); fill.color.set(0xdde6ff); fill.intensity = 0.3; fill.position.set(10, 8, 20);
}

/* =========================================================
   SET: Straße, Gehweg, Haus mit Vordach (x -6), Auto (x 4)
   ========================================================= */
const STR = new THREE.Group(); scene.add(STR); const SETS = [STR];
const HX = -6.5, HZ = -4.5;
(function(){
  const gr = mat(0x4f7a3a, { roughness: 1 }), sw = mat(0xa8a49c, { roughness: 0.95 }), rd = mat(0x3c3c40, { roughness: 0.9 }), wh = mat(0xe8e8e8);
  const g = new THREE.Mesh(new THREE.PlaneGeometry(300, 300), gr); g.rotation.x = -PI / 2; g.receiveShadow = true; STR.add(g);
  const s = new THREE.Mesh(new THREE.PlaneGeometry(300, 3), sw); s.rotation.x = -PI / 2; s.position.set(0, 0.02, 0); s.receiveShadow = true; STR.add(s);
  const r = new THREE.Mesh(new THREE.PlaneGeometry(300, 8), rd); r.rotation.x = -PI / 2; r.position.set(0, 0.015, 6); r.receiveShadow = true; STR.add(r);
  for (let i = -20; i <= 20; i++) P(STR, new THREE.BoxGeometry(3, 0.02, 0.25), wh, i * 6, 0.03, 6);
  // Haus mit Tür + Vordach
  const wl = mat(0xd8c8a8, { roughness: 0.9 }), rf = mat(0x8a3a2a, { roughness: 0.8 }), dr = mat(0x5a3a24), wn = mat(0x9ac8e8, { roughness: 0.1, metalness: 0.3 });
  P(STR, new THREE.BoxGeometry(10, 7, 6), wl, HX, 3.5, HZ - 3.2);
  const roof = P(STR, new THREE.ConeGeometry(7.6, 3.6, 4), rf, HX, 8.8, HZ - 3.2); roof.rotation.y = PI / 4; roof.scale.z = 0.62;
  P(STR, new THREE.BoxGeometry(1.8, 3.6, 0.12), dr, HX, 1.8, HZ - 0.15); [-3, 3].forEach(dx => P(STR, new THREE.BoxGeometry(1.8, 1.6, 0.1), wn, HX + dx, 3.6, HZ - 0.16));
  P(STR, new THREE.BoxGeometry(5, 0.25, 3.2), rf, HX, 4.4, HZ + 1.4); [-2.3, 2.3].forEach(dx => P(STR, new THREE.CylinderGeometry(0.1, 0.1, 4.4, 8), wh, HX + dx, 2.2, HZ + 2.8));
  P(STR, new THREE.BoxGeometry(5, 0.2, 3.2), sw, HX, 0.1, HZ + 1.4);
  // Bäume weiter weg
  const tr = mat(0x5a3e28), lf = mat(0x2f5a2a, { roughness: 0.9, flatShading: true });
  for (let i = 0; i < 14; i++){ const x = -40 + i * 7 + hsh(i) * 3, z = -16 - hsh(i + 4) * 10; P(STR, new THREE.CylinderGeometry(0.25, 0.35, 4, 6), tr, x, 2, z); P(STR, new THREE.DodecahedronGeometry(2.4, 0), lf, x, 5, z); }
})();
// Auto (Front zeigt nach -x), Windschutzscheibe mit Riss
const CAR = new THREE.Group(); STR.add(CAR); CAR.position.set(4.5, 0, 4.0);
const CRK = (function(){ const c = document.createElement('canvas'); c.width = 256; c.height = 128; const x = c.getContext('2d'); x.strokeStyle = 'rgba(255,255,255,0.95)'; x.lineWidth = 3;
  for (let i = 0; i < 14; i++){ const a = i / 14 * PI * 2 + hsh(i) * 0.3; let px = 110, py = 60; x.beginPath(); x.moveTo(px, py); for (let k = 1; k <= 5; k++){ px += Math.cos(a + (hsh(i * 7 + k) - 0.5) * 0.7) * 22; py += Math.sin(a + (hsh(i * 3 + k) - 0.5) * 0.7) * 14; x.lineTo(px, py); } x.stroke(); }
  x.beginPath(); x.arc(110, 60, 9, 0, 7); x.stroke(); const t = new THREE.CanvasTexture(c); return new THREE.MeshBasicMaterial({ map: t, transparent: true, opacity: 0, depthWrite: false }); })();
(function(){ const b = mat(0x2a5aa8, { roughness: 0.35, metalness: 0.5 }), gl = mat(0x2a3a48, { roughness: 0.05, metalness: 0.6 }), tk = mat(0x1a1a1e);
  P(CAR, rbox(8, 1.4, 3.6, 0.3), b, 0, 1.2, 0); P(CAR, rbox(4.4, 1.3, 3.3, 0.3), b, 0.4, 2.45, 0);
  const ws = new THREE.Mesh(new THREE.PlaneGeometry(3.0, 1.5), gl); ws.position.set(-2.05, 2.4, 0); ws.rotation.set(0, -PI / 2, 0); ws.rotateX(-0.75); CAR.add(ws);
  const ck = new THREE.Mesh(new THREE.PlaneGeometry(3.0, 1.5), CRK); ck.position.set(-2.07, 2.41, 0); ck.rotation.copy(ws.rotation); CAR.add(ck);
  [[-2.6, 1.8], [-2.6, -1.8], [2.6, 1.8], [2.6, -1.8]].forEach(([x, z]) => P(CAR, new THREE.CylinderGeometry(0.62, 0.62, 0.4, 16), tk, x, 0.62, z).rotation.x = PI / 2); })();
// Gewitterwolke
const CLD = new THREE.Group(); STR.add(CLD); CLD.position.set(0, 26, -30);
(function(){ const cm = mat(0x3a4448, { roughness: 1, flatShading: true }); for (let i = 0; i < 16; i++){ const r = 4 + hsh(i) * 4; P(CLD, new THREE.DodecahedronGeometry(r, 1), cm, (hsh(i + 1) - 0.5) * 30, (hsh(i + 2) - 0.2) * 8 + (i < 5 ? 10 : 0), (hsh(i + 3) - 0.5) * 8); } })();
// Hagel: fallende Körner (Instanzen) + liegende Körner
const NH = 420, HG = new THREE.InstancedMesh(new THREE.IcosahedronGeometry(0.07, 1), mat(0xf2f6f8, { roughness: 0.2 }), NH); STR.add(HG);
const NL = 520, HL = new THREE.InstancedMesh(new THREE.IcosahedronGeometry(0.07, 1), mat(0xeef2f4, { roughness: 0.3 }), NL); STR.add(HL);
const _m = new THREE.Matrix4(), _q = new THREE.Quaternion(), _s = new THREE.Vector3(), _v = new THREE.Vector3();
// k: Dichte 0..1, sp: Fallgeschwindigkeit (E/s), cx/cz: Zentrum, sz: Korngröße
function hail(t, k, sp, cx, cz, sz, roofed){ const H = 14;
  for (let i = 0; i < NH; i++){ const on = hsh(i * 1.3) < k; const x = cx + (hsh(i * 2.1) - 0.5) * 22, z = cz + (hsh(i * 3.7) - 0.5) * 16;
    let y = H - ((t * sp + hsh(i * 5.9) * H) % H); const under = roofed && Math.abs(x - HX) < 2.5 && z > HZ - 0.2 && z < HZ + 3.0 && y < 4.4;
    _s.setScalar(on && !under ? sz * (0.7 + hsh(i * 4.4) * 0.6) : 0.0001); _v.set(x, y, z); _q.identity(); _s.y *= 1 + sp / 40; _m.compose(_v, _q, _s); HG.setMatrixAt(i, _m); }
  HG.instanceMatrix.needsUpdate = true; }
function ground(k, sz){ for (let i = 0; i < NL; i++){ const x = (hsh(i * 6.1) - 0.5) * 30, z = -6 + hsh(i * 2.9) * 14; const roofed = Math.abs(x - HX) < 2.5 && z > HZ - 0.2 && z < HZ + 3.0;
    _s.setScalar(!roofed && hsh(i * 1.7) < k ? sz * (0.6 + hsh(i * 3.3) * 0.8) : 0.0001); _v.set(x, 0.05, z); _q.identity(); _m.compose(_v, _q, _s); HL.setMatrixAt(i, _m); } HL.instanceMatrix.needsUpdate = true; }
// Rekordkorn (14 cm = 0,28 E)
const BIG = new THREE.Mesh(new THREE.DodecahedronGeometry(0.14, 2), new THREE.MeshStandardMaterial({ color: 0xeef6fa, roughness: 0.15, transparent: true, opacity: 0.92 })); BIG.position.set(1.0, 0.13, 1.0); BIG.scale.set(1.1, 0.9, 1); STR.add(BIG);
const FALL = new THREE.Mesh(new THREE.DodecahedronGeometry(0.06, 1), mat(0xf2f6f8, { roughness: 0.2 })); STR.add(FALL);

/* =========================================================
   BEN: Narbe, Tasse
   ========================================================= */
const SCAR = new THREE.Group(); ben.head.add(SCAR);
(function(){ const m = mat(0xa8463f, { roughness: 0.7 }); const s = new THREE.Mesh(rbox(0.075, 0.72, 0.03, 0.012, 1), m); s.position.set(0.25, 0.55, 0.522); s.rotation.z = -0.13; SCAR.add(s);
  for (const y of [0.36, 0.55, 0.74]){ const c = new THREE.Mesh(rbox(0.16, 0.035, 0.03, 0.01, 1), m); c.position.set(0.25 + (y - 0.55) * 0.13, y, 0.528); c.rotation.z = -0.13; SCAR.add(c); } })();
const CUP = new THREE.Group(); ben.el[0].add(CUP); CUP.position.set(0, -0.66, 0.14); P(CUP, new THREE.CylinderGeometry(0.16, 0.13, 0.3, 14), mat(0xf2f2f2), 0, 0, 0); P(CUP, new THREE.CylinderGeometry(0.14, 0.14, 0.02, 14), mat(0x5a3010), 0, 0.14, 0);
function headCover(k){ ben.sh[0].rotation.set(-2.6 * k, 0, 0.35 * k - 0.07 * (1 - k)); ben.sh[1].rotation.set(-2.6 * k, 0, -0.35 * k + 0.07 * (1 - k)); ben.el[0].rotation.x = -0.1 - 1.3 * k; ben.el[1].rotation.x = -0.1 - 1.3 * k; ben.head.rotation.x = 0.25 * k; }

/* =========================================================
   KAMERA + Zustand
   ========================================================= */
const cL = new THREE.Vector3();
let blurAmt = 0, fadeBlk = 0, T = 0, flashA = 0, eyeS = 1, talk = 0, dT = 0;
let upK = 0, carK = 0, recK = 0, spdK = 0, goK = 0, roofK = 0;
function camW(p, a, b){ cam.position.set(lerp(a[0], b[0], p), lerp(a[1], b[1], p), lerp(a[2], b[2], p)); cL.set(lerp(a[3], b[3], p), lerp(a[4], b[4], p), lerp(a[5], b[5], p)); cam.fov = lerp(a[6], b[6], p); }
function camFin(sh){ cam.position.x += Math.sin(dT * 0.7) * 0.03; cam.position.y += Math.sin(dT * 0.9 + 1) * 0.02; if (sh){ cam.position.x += Math.sin(T * 23) * sh; cam.position.y += Math.cos(T * 17) * sh; } cam.up.set(0, 1, 0); cam.lookAt(cL); cam.updateProjectionMatrix(); cam.updateMatrixWorld(); }
const HOOK = [[2.2, 2.6, 9.0, 0.4, 2.2, 0, 50], [2.0, 2.5, 8.6, 0.6, 2.2, 0, 50]];
function base(){ show(ben); CUP.visible = false; BIG.visible = false; FALL.visible = false; CRK.opacity = 0; flashA = 0; }
// Hook: Ben läuft auf dem Gehweg, Hagel setzt ein, Hände über den Kopf
function hookBen(t){ const x = 1.2 * Math.max(-1, t) - 1.0; bRest(ben, t, 0); place(ben, x, 0, 0, PI / 2 + 0.6 * seg(t, 1.2, 1.8)); const c = E.out(seg(t, 1.0, 1.5));
  wlk(ben, t * 7, 1 - 0.6 * c); headCover(c); eyeS = lerp(1.0, 1.4, c); bFace(ben, -0.8 * c, 0.4 * c); hail(t, 0.25 + 0.6 * seg(t, 0.3, 2.0), 22, x, 1, 1, false); ground(0.15 + 0.35 * seg(t, 0, 3.5), 1);
  }

/* =========================================================
   SZENEN (Sprecherspur Tempo 1,1)
   ========================================================= */
const SCN = [
  { t: 0, set: STR, mood: MOOD.storm, hook: 1,
    upd(lt){ dT = T; base(); hookBen(T); camW(E.io(seg(lt, 0, 3.51)), HOOK[0], [2.6, 2.3, 7.6, 2.2, 2.0, 0, 50]); camFin(); } },
  { t: 3.51, set: STR, mood: MOOD.storm, hud: () => ['GEWITTERWOLKE', 'STARKE AUFWINDE'],
    upd(lt){ dT = T; base(); bRest(ben, T, 0); place(ben, 3.0, 0, 0, PI / 2 + 0.6); headCover(1); eyeS = 1.3; bFace(ben, -0.6, 0.3); hail(T, 0.85, 22, 3, 1, 1, false); ground(0.55, 1);
      upK = E.out(seg(T, 3.7, 4.0)) * (1 - seg(T, 6.85, 7.0));
      camW(E.io(seg(lt, 0, 3.49)), [3.0, 3.0, 9.0, 1.5, 6.0, -6.0, 56], [3.0, 3.6, 9.4, 0.5, 14.0, -20.0, 60]); camFin(); } },
  { t: 7.0, set: STR, mood: MOOD.storm, hud: () => ['AB 4 ZENTIMETERN', 'GEHEN AUTOSCHEIBEN KAPUTT'],
    upd(lt){ dT = T; base(); ben.root.visible = false; hail(T, 0.8, 24, 4, 3, 2.2, false); ground(0.6, 1.4);
      const TC = 9.0, f = seg(T, TC - 0.45, TC); FALL.visible = T < TC; FALL.scale.setScalar(2.9); FALL.position.set(4.5 - 2.07 + 0.3, 2.41 + 6 * (1 - f), 4.0); CRK.opacity = T > TC ? 1 : 0;
      carK = E.out(seg(T, 7.2, 7.5)) * (1 - seg(T, 9.9, 10.04));
      camW(E.io(seg(lt, 0, 3.04)), [-2.0, 3.4, 9.0, 2.6, 2.2, 4.0, 46], [-1.2, 3.2, 8.2, 2.5, 2.3, 4.0, 44]); camFin(0.04 * bump(T, TC, TC + 0.25)); } },
  { t: 10.04, set: STR, mood: MOOD.storm, hud: () => ['DEUTSCHLAND-REKORD', '14,1 CM · 360 G · 2013'],
    upd(lt){ dT = T; base(); ben.root.visible = false; BIG.visible = true; hail(T, 0.5, 22, 1, 1, 1.2, false); ground(0.6, 1.3);
      recK = E.out(seg(T, 10.3, 10.6)) * (1 - seg(T, 14.15, 14.31));
      camW(E.io(seg(lt, 0, 4.27)), [1.9, 0.75, 2.1, 1.0, 0.15, 1.0, 40], [1.6, 0.6, 1.7, 1.0, 0.16, 1.0, 38]); camFin(); } },
  { t: 14.31, set: STR, mood: MOOD.storm, hud: () => ['GROSSE KÖRNER', 'ÜBER 100 KM/H'],
    upd(lt){ dT = T; base(); bRest(ben, T, 0); place(ben, 1.0, 0, 0.2, PI / 2 + 0.3); headCover(1); eyeS = 1.45; bFace(ben, -1, 0.5); ben.torso.rotation.x = 0.2;
      hail(T, 1, 40, 1, 1, 1.6, false); ground(0.75, 1.4); spdK = E.out(seg(T, 14.5, 14.8)) * (1 - seg(T, 18.15, 18.31));
      camW(E.io(seg(lt, 0, 4.0)), [4.6, 1.4, 6.4, 1.0, 2.2, 0.2, 52], [3.6, 1.6, 5.4, 1.0, 2.2, 0.2, 52]); camFin(); } },
  { t: 18.31, set: STR, mood: MOOD.storm, hud: () => ['SOFORT REIN', 'INS HAUS ODER AUTO'],
    upd(lt){ dT = T; base(); const s = E.io(seg(T, 18.4, 20.6)), x = lerp(1.0, HX + 0.6, s), z = lerp(0.2, HZ + 1.3, s); bRest(ben, T, 0); place(ben, x, 0, z, -PI / 2 - 0.5 * Math.sin(PI * s));
      if (s < 1) wlk(ben, T * 11, 1.4); headCover(1 - seg(T, 20.4, 20.9)); eyeS = 1.3; bFace(ben, -0.5, 0.3);
      hail(T, 1, 34, -2, 0, 1.4, true); ground(0.8, 1.4); goK = E.out(seg(T, 18.5, 18.8)) * (1 - seg(T, 21.15, 21.33));
      camW(E.io(seg(lt, 0, 3.02)), [3.0, 3.2, 9.6, -1.5, 2.0, -1.2, 54], [0.0, 3.0, 8.6, -4.8, 2.0, -2.6, 52]); camFin(); } },
  { t: 21.33, set: STR, mood: MOOD.storm, hud: () => ['UND BEN?', 'WARTET UNTERM DACH'],
    upd(lt){ dT = T; base(); bRest(ben, T, 0); place(ben, HX + 0.6, 0.2, HZ + 1.3, 0.2); CUP.visible = true; ben.sh[0].rotation.set(-1.0, 0, -0.15); ben.el[0].rotation.x = -1.2; eyeS = 1.05; bFace(ben, 0.9, 0.1);
      hail(T, 0.9, 26, HX, HZ + 4, 1.2, true); ground(0.85, 1.3); roofK = E.out(seg(T, 21.6, 21.9)) * (1 - seg(T, 23.35, 23.5));
      camW(E.io(seg(lt, 0, 2.17)), [HX + 3.6, 2.4, HZ + 8.6, HX + 0.4, 2.4, HZ + 1.0, 50], [HX + 2.8, 2.3, HZ + 7.6, HX + 0.4, 2.4, HZ + 1.0, 48]); camFin(); } },
  { t: 23.5, set: STR, mood: MOOD.storm, loopin: 1,
    upd(lt){ dT = T - END; base(); hookBen(T - END); camW(0, HOOK[0], HOOK[1]); camFin(); } },
];
const SUBS = __SUBS__;
