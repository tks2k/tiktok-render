/* =========================================================
   STIMMUNG: Unterwasser (statischer Verlauf)
   ========================================================= */
function sky(){
  const c = document.createElement('canvas'); c.width = 4; c.height = 512; const x = c.getContext('2d'), g = x.createLinearGradient(0, 0, 0, 512);
  g.addColorStop(0, '#6fc4e6'); g.addColorStop(0.35, '#2e8fc0'); g.addColorStop(0.75, '#145a8a'); g.addColorStop(1, '#0b3a62'); x.fillStyle = g; x.fillRect(0, 0, 4, 512);
  const t = new THREE.CanvasTexture(c); t.encoding = THREE.sRGBEncoding; return t;
}
const MOOD = { sea: { sky: sky(), fog: [0x1f78a8, 12, 70], hemi: [0xbfe8ff, 0x1a4a6a, 0.85], sun: [0xe8fbff, 1.15], sp: [4, 30, 10] } };
const SR = 14; { const c = sun.shadow.camera; c.left = -SR; c.right = SR; c.top = SR; c.bottom = -SR; c.near = 1; c.far = 90; c.updateProjectionMatrix(); }
function setMood(m){
  scene.background = m.sky; scene.fog.color.set(m.fog[0]); scene.fog.near = m.fog[1]; scene.fog.far = m.fog[2]; scene.environment = envDay;
  hemi.color.set(m.hemi[0]); hemi.groundColor.set(m.hemi[1]); hemi.intensity = m.hemi[2]; sun.color.set(m.sun[0]); sun.intensity = m.sun[1];
  sun.position.set(m.sp[0], m.sp[1], m.sp[2]); sun.target.position.set(0, 0, 0); fill.color.set(0x9fd8ff); fill.intensity = 0.4; fill.position.set(-12, 4, 16);
}

/* =========================================================
   SET: Meeresgrund
   ========================================================= */
const SEA = new THREE.Group(); scene.add(SEA); const SETS = [SEA];
(function(){
  const g = new THREE.Mesh(new THREE.PlaneGeometry(400, 400), new THREE.MeshStandardMaterial({ color: 0xc9b98a, roughness: 1 })); g.rotation.x = -PI / 2; g.position.y = -7; g.receiveShadow = true; SEA.add(g);
  const rk = mat(0x5d6b70, { roughness: 1 }), rk2 = mat(0x4a585e, { roughness: 1 });
  [[-7, -7, -8, 2.2], [8, -7, -12, 3.0], [-12, -7, -20, 4.0], [14, -7, -24, 3.6], [3, -7, -30, 5], [-4, -7, 4, 1.4]].forEach(([x, y, z, s], i) => P(SEA, new THREE.DodecahedronGeometry(s, 0), i % 2 ? rk : rk2, x, y + s * 0.35, z));
  const wd = [mat(0x3f8a4a, { roughness: 0.9 }), mat(0x5aa050, { roughness: 0.9 })];
  [[-5, -9], [-5.8, -8.4], [6.5, -10], [7.2, -11], [-10, -16], [11, -18], [1, -14]].forEach(([x, z], i) => { const h = 2.5 + (i % 3) * 1.2; const m = P(SEA, rbox(0.35, h, 0.2, 0.08), wd[i % 2], x, -7 + h / 2, z); m.userData.sw = i; });
})();
const WEED = []; SEA.children.forEach(o => { if (o.userData.sw !== undefined) WEED.push(o); });
const BUBM = new THREE.MeshStandardMaterial({ color: 0xeaf8ff, transparent: true, opacity: 0.55, roughness: 0.1, envMapIntensity: 1.2, depthWrite: false });
const BUB = []; for (let i = 0; i < 18; i++){ const b = new THREE.Mesh(new THREE.SphereGeometry(1, 14, 10), BUBM); b.visible = false; b.renderOrder = 4; scene.add(b); BUB.push(b); }
function bubbles(cx, cy, cz, t){ BUB.forEach((b, i) => { const h = hsh(i + 1), age = t - h * 0.5; if (age < 0 || age > 2.4){ b.visible = false; return; }
  b.visible = true; const s = (0.12 + 0.14 * hsh(i + 9)) * (1 - seg(age, 1.8, 2.4)); b.scale.setScalar(Math.max(0.001, s));
  b.position.set(cx + (hsh(i + 3) - 0.5) * 2.2 + Math.sin(age * 3 + i) * 0.12, cy + (hsh(i + 5) - 0.2) * 2.5 + age * 2.2, cz + (hsh(i + 7) - 0.5) * 1.2); }); }

/* =========================================================
   HAI (Vorderseite +x, Maul vorne)
   ========================================================= */
const SHK = new THREE.Group(); scene.add(SHK);
const JAW = new THREE.Group(), TAIL = new THREE.Group();
(function(){
  const top = mat(0x5f7a8c, { roughness: 0.5 }), bel = mat(0xeeeeea, { roughness: 0.6 }), dark = mat(0x2a3640, { roughness: 0.7 }), red = mat(0x7a2226, { roughness: 0.8 }), tooth = mat(0xffffff, { roughness: 0.3 });
  const sph = (m, sx, sy, sz, x, y, z) => { const o = P(SHK, new THREE.SphereGeometry(1, 40, 24), m, x, y, z); o.scale.set(sx, sy, sz); return o; };
  sph(top, 3.6, 0.9, 1.05, 0, 0.35, 0); sph(bel, 3.0, 0.7, 0.9, -0.4, -0.25, 0);
  sph(red, 0.75, 0.32, 0.66, 2.85, -0.28, 0);
  for (let k = 0; k < 9; k++){ const a = -1.1 + k * 2.2 / 8; const c = P(SHK, new THREE.ConeGeometry(0.075, 0.2, 6), tooth, 2.55 + 0.85 * Math.cos(a), -0.3, 0.62 * Math.sin(a)); c.rotation.x = PI; }
  [-1, 1].forEach(s => { P(SHK, new THREE.SphereGeometry(0.14, 14, 10), mat(0x0a0a0e, { roughness: 0.2 }), 2.75, 0.45, s * 0.64);
    for (let k = 0; k < 3; k++){ const gl = P(SHK, rbox(0.1, 0.55, 0.05, 0.03, 1), dark, 1.6 + k * 0.25, 0.15, s * (0.92 - k * 0.04)); gl.rotation.y = -s * 0.25; } });
  const fin = (m, r, h, x, y, z, rx, rz, sz) => { const o = P(SHK, new THREE.ConeGeometry(r, h, 4), m, x, y, z); o.scale.z = sz; o.rotation.set(rx, 0, rz); return o; };
  fin(top, 0.8, 1.7, 0.1, 1.75, 0, 0, 0.45, 0.25);
  [-1, 1].forEach(s => { const f = fin(top, 0.42, 1.5, 1.1, -0.55, s * 0.8, s * 0.9, 0.75, 0.25); });
  JAW.position.set(2.2, -0.3, 0); SHK.add(JAW);
  const j = P(JAW, new THREE.SphereGeometry(1, 30, 16), top, 0.62, -0.08, 0); j.scale.set(0.72, 0.2, 0.64);
  const jb = P(JAW, new THREE.SphereGeometry(1, 30, 16), bel, 0.55, -0.15, 0); jb.scale.set(0.6, 0.16, 0.56);
  for (let k = 0; k < 8; k++){ const a = -1.0 + k * 2.0 / 7; P(JAW, new THREE.ConeGeometry(0.07, 0.18, 6), tooth, 0.3 + 0.72 * Math.cos(a), 0.12, 0.55 * Math.sin(a)); }
  TAIL.position.set(-3.1, 0.3, 0); SHK.add(TAIL);
  const tp = P(TAIL, new THREE.SphereGeometry(1, 20, 12), top, -0.3, 0, 0); tp.scale.set(0.9, 0.32, 0.28);
  const t1 = P(TAIL, new THREE.ConeGeometry(0.42, 2.0, 4), top, -1.1, 0.85, 0); t1.scale.z = 0.22; t1.rotation.z = 0.7;
  const t2 = P(TAIL, new THREE.ConeGeometry(0.34, 1.2, 4), top, -0.95, -0.45, 0); t2.scale.z = 0.22; t2.rotation.z = PI - 0.75;
})();
const MOUTH = new THREE.Vector3(3.2, -0.25, 0);
function shk(x, y, z, yaw, jaw, t, sw){ SHK.visible = true; SHK.position.set(x, y, z); SHK.rotation.set(0, yaw, 0); JAW.rotation.z = -jaw; TAIL.rotation.y = (sw === undefined ? 1 : sw) * 0.32 * Math.sin(t * 5.5); SHK.rotation.y += -(sw === undefined ? 1 : sw) * 0.04 * Math.sin(t * 5.5); }
// Hai so platzieren, dass das Maul bei M liegt
function shkMouth(M, yaw, jaw, t, sw){ const c = Math.cos(yaw), s = Math.sin(yaw); shk(M.x - (MOUTH.x * c + MOUTH.z * s), M.y - MOUTH.y, M.z - (-MOUTH.x * s + MOUTH.z * c), yaw, jaw, t, sw); }

/* =========================================================
   BEN
   ========================================================= */
const SCAR = new THREE.Group(); ben.head.add(SCAR);
(function(){ const m = mat(0xa8463f, { roughness: 0.7 }); const s = new THREE.Mesh(rbox(0.075, 0.72, 0.03, 0.012, 1), m); s.position.set(0.25, 0.55, 0.522); s.rotation.z = -0.13; SCAR.add(s);
  for (const y of [0.36, 0.55, 0.74]){ const c = new THREE.Mesh(rbox(0.16, 0.035, 0.03, 0.01, 1), m); c.position.set(0.25 + (y - 0.55) * 0.13, y, 0.528); c.rotation.z = -0.13; SCAR.add(c); } })();
function tread(r, t, w){ w = w === undefined ? 1 : w; const a = Math.sin(t * 3.0), b = Math.sin(t * 3.0 + 1.6);
  r.sh[0].rotation.set(0.15 * b * w, 0, -0.95 - 0.28 * a * w); r.sh[1].rotation.set(-0.15 * b * w, 0, 0.95 + 0.28 * a * w); r.el[0].rotation.set(-0.45, 0, 0); r.el[1].rotation.set(-0.45, 0, 0);
  r.legs[0].rotation.set(0.4 * a * w, 0, -0.06); r.legs[1].rotation.set(-0.4 * a * w, 0, 0.06); r.torso.rotation.x = 0.05; }

/* =========================================================
   KAMERA + Zustand
   ========================================================= */
const cL = new THREE.Vector3();
let blurAmt = 0, fadeBlk = 0, T = 0, flashA = 0, eyeS = 1, talk = 0, dT = 0;
let forceK = 0, testK = 0, tgtK = 0, riskK = 0, bonkT = -9;
function camW(p, a, b){ cam.position.set(lerp(a[0], b[0], p), lerp(a[1], b[1], p), lerp(a[2], b[2], p)); cL.set(lerp(a[3], b[3], p), lerp(a[4], b[4], p), lerp(a[5], b[5], p)); cam.fov = lerp(a[6], b[6], p); }
function camFin(sh){ cam.position.x += Math.sin(dT * 0.7) * 0.02; cam.position.y += Math.sin(dT * 0.9 + 1) * 0.015; if (sh){ cam.position.x += Math.sin(T * 23) * sh; cam.position.y += Math.cos(T * 17) * sh; } cam.up.set(0, 1, 0); cam.lookAt(cL); cam.updateProjectionMatrix(); cam.updateMatrixWorld(); }
const imp = at => T >= at ? Math.exp(-(T - at) * 3) : 0;
const HOOK = [[3.6, 5.0, 18.6, 0.6, 4.4, -1.5, 40], [3.0, 4.6, 16.8, 0.5, 4.1, -1.0, 40]];
const TB = 3.3, BT = new THREE.Vector3(0.32, 0.38, 0.02), HD = new THREE.Vector3(-0.3, 0, 1).normalize(), YH = Math.atan2(-HD.z, HD.x);
const _M = new THREE.Vector3();
function base(){ show(ben); SHK.visible = false; BUB.forEach(b => b.visible = false); WEED.forEach(w => w.rotation.z = 0.08 * Math.sin(dT * 0.8 + w.userData.sw)); }
function hookShark(t){ const d = Math.max(0, TB - t); _M.copy(BT).addScaledVector(HD, -2.4 * d); _M.y += 0.4 * seg(d, 0.6, 4);
  const jaw = t < TB - 0.14 ? 0.62 * E.out(seg(t, -1.5, 2.2)) : 0.62 * (1 - seg(t, TB - 0.14, TB)) + 0.2 * seg(t, TB - 0.14, TB); shkMouth(_M, YH, jaw, t); }
function hookBen(t){ bRest(ben, t, 0); place(ben, 0, 0.1 * Math.sin(t * 1.5), 0, 0); tread(ben, t); eyeS = 1; bFace(ben, 0.2, 0.05); }

/* =========================================================
   SZENEN (Sprecherspur Tempo 1,1)
   ========================================================= */
const SCN = [
  { t: 0, set: SEA, mood: MOOD.sea, hook: 1,
    upd(lt){ dT = T; base(); hookBen(T); hookShark(T); camW(E.io(seg(lt, 0, 2.78)), HOOK[0], HOOK[1]); camFin(); } },
  { t: 2.78, set: SEA, mood: MOOD.sea, hud: () => ['BISSKRAFT', 'FAST 2 TONNEN'],
    upd(lt){ dT = T; base(); const bit = seg(T, TB - 0.1, TB + 0.05); bRest(ben, T, 0); place(ben, 0.06 * imp(TB) * Math.sin(T * 40), 0.1 * Math.sin(T * 1.5) * (1 - bit), 0, 0); tread(ben, T, 1 - 0.6 * bit);
      ben.legs[1].rotation.x = lerp(ben.legs[1].rotation.x, 0.1, bit); eyeS = 1 + 0.4 * bit; bFace(ben, -0.9 * bit, 0.6 * bit); hookShark(T);
      flashA = 0.35 * imp(TB) * 0; forceK = E.out(seg(T, 3.4, 3.7)) * (1 - seg(T, 6.15, 6.35));
      camW(E.io(seg(lt, 0.15, 1.3)), HOOK[1], [11.5, 2.4, 9.5, 0.6, 0.9, -2.0, 40]); camFin(0.05 * imp(TB)); } },
  { t: 6.35, set: SEA, mood: MOOD.sea, hud: () => ['NUR EIN TESTBISS', 'BEN IST IHM ZU KNOCHIG'],
    upd(lt){ dT = T; base(); bRest(ben, T, 0); place(ben, 0.05 * Math.sin(T * 9) * seg(T, 6.6, 7.0), 0, 0, 0); tread(ben, T, 0.4); ben.legs[1].rotation.x = 0.1; eyeS = 1.2; bFace(ben, -0.6, 0.15);
      hookShark(TB + 1); SHK.position.x += 0.05 * Math.sin(T * 9) * seg(T, 6.6, 7.0); testK = E.out(seg(T, 7.4, 7.7)) * (1 - seg(T, 10.25, 10.44));
      camW(E.io(seg(lt, 0, 4.09)), [11.5, 2.4, 9.5, 0.6, 0.9, -2.0, 40], [10.6, 2.2, 8.6, 0.6, 0.9, -2.0, 40]); camFin(); } },
  { t: 10.44, set: SEA, mood: MOOD.sea, hud: () => ['HAI LÄSST LOS', 'UND SCHWIMMT WEG'],
    upd(lt){ dT = T; base(); bRest(ben, T, 0); place(ben, 0, 0.1 * Math.sin(T * 1.5), 0, 0); tread(ben, T, seg(T, 10.6, 11.2)); eyeS = 1; bFace(ben, 0.3 * seg(T, 11, 11.5), 0.08);
      hookShark(TB + 1); const P0 = SHK.position.clone(), back = E.io(seg(T, 10.6, 12.3)), turn = E.io(seg(T, 10.95, 11.9));
      const jaw = 0.2 + 0.4 * bump(T, 10.5, 11.4); shk(P0.x - HD.x * 6.5 * back + 7 * turn * turn, P0.y - 0.6 * back, P0.z - HD.z * 6.5 * back - 4 * turn, YH + PI * turn, jaw, T, 1.4);
      camW(E.io(seg(lt, 0, 1.89)), [10.6, 2.2, 8.6, 0.6, 0.9, -2.0, 40], [5.0, 2.4, 17.0, 1.4, 1.0, -3.0, 40]); camFin(); } },
  { t: 12.33, set: SEA, mood: MOOD.sea, hud: () => T < 14.1 ? ['BEISST ER WEITER?', 'AUGEN UND KIEMEN!'] : ['VOLLTREFFER', 'DA IST ER EMPFINDLICH'],
    upd(lt){ dT = T; base(); bRest(ben, T, 0); place(ben, 0, 0.1 * Math.sin(T * 1.5), 0, 0); tread(ben, T, 1);
      const pu = E.out(seg(T, 13.85, 14.1)) * (1 - E.io(seg(T, 14.5, 14.9))); ben.sh[1].rotation.set(0, 0, lerp(ben.sh[1].rotation.z, PI / 2, pu)); ben.el[1].rotation.x = lerp(-0.45, 0, pu); ben.torso.rotation.y = 0.25 * pu;
      eyeS = 1; bFace(ben, 0.9, 0.15 + 0.3 * pu);
      const app = Math.max(0, 14.1 - T), rec = E.out(seg(T, 14.1, 14.7)), go = E.io(seg(T, 14.6, 16.0));
      shk(4.6 + 2.4 * app + 2.0 * rec + 9 * go, 1.47 + 0.3 * rec, -0.8 - 1.5 * go, PI - 0.5 * rec * (1 - go) + 0.0 * go, 0.5 * (1 - seg(T, 13.95, 14.12)) + 0.15 * rec * (1 - go), T, 1 + go);
      SHK.rotation.z = 0.35 * Math.exp(-Math.max(0, T - 14.1) * 4) * (T > 14.1 ? Math.sin((T - 14.1) * 18) : 0);
      tgtK = E.out(seg(T, 13.25, 13.5)) * (1 - seg(T, 14.15, 14.4));
      camW(E.io(seg(lt, 0, 3.7)), [2.6, 2.2, 16.0, 1.6, 1.5, -0.4, 40], [2.4, 2.1, 15.0, 1.5, 1.5, -0.4, 40]); camFin(0.06 * imp(14.1)); } },
  { t: 16.04, set: SEA, mood: MOOD.sea, hud: () => ['UND DAS RISIKO?', 'WINZIG'],
    upd(lt){ dT = T; base(); hookBen(T); bFace(ben, 0.5, 0.05); const x = -26 + 3.2 * (T - 16.04); shk(x, -1.5, -30, 0, 0.05, T, 1);
      riskK = E.out(seg(T, 17.0, 17.3)) * (1 - seg(T, 19.65, 19.84)); camW(E.io(seg(lt, 0, 3.8)), [0.4, 1.8, 22.0, 0.2, 0.6, -4, 40], [0.3, 1.8, 21.0, 0.2, 0.6, -4, 40]); camFin(); } },
  { t: 19.84, set: SEA, mood: MOOD.sea, hud: () => ['UND BEN?', 'SCHON WIEDER IM WASSER'],
    upd(lt){ dT = T - END; base(); const k = E.out(seg(T, 19.9, 21.0)); hookBen(T - END); ben.root.position.y += 10.5 * (1 - k);
      const up = 1 - seg(T, 20.6, 21.2); ben.sh[0].rotation.z = lerp(ben.sh[0].rotation.z, -2.9, up); ben.sh[1].rotation.z = lerp(ben.sh[1].rotation.z, 2.9, up); ben.legs[0].rotation.x *= 1 - up; ben.legs[1].rotation.x *= 1 - up;
      eyeS = 1; bFace(ben, 0.4, 0.25 * up); bubbles(0, ben.root.position.y - 0.5, 0.2, T - 20.0); hookShark(T - END);
      camW(0, HOOK[0], HOOK[0]); camFin(); } },
  { t: 22.0, set: SEA, mood: MOOD.sea, loopin: 1,
    upd(lt){ dT = T - END; base(); hookBen(T - END); hookShark(T - END); camW(0, HOOK[0], HOOK[1]); camFin(); } },
];
const SUBS = __SUBS__;
