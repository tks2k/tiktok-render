/* =========================================================
   STIMMUNG: Zimmer (Tag)
   ========================================================= */
function sky(stops){
  const c = document.createElement('canvas'); c.width = 4; c.height = 256; const x = c.getContext('2d'), g = x.createLinearGradient(0, 0, 0, 256);
  stops.forEach(s => g.addColorStop(s[0], s[1])); x.fillStyle = g; x.fillRect(0, 0, 4, 256); const t = new THREE.CanvasTexture(c); t.encoding = THREE.sRGBEncoding; return t;
}
const MOOD = { room: { sky: sky([[0, '#e8dcc8'], [1, '#e8dcc8']]), fog: [0xe8dcc8, 60, 200], hemi: [0xfff6ea, 0x8a7458, 0.95], sun: [0xfff0dc, 0.9], env: 1 } };
const SR = 8; { const c = sun.shadow.camera; c.left = -SR; c.right = SR; c.top = SR; c.bottom = -SR; c.near = 1; c.far = 60; c.updateProjectionMatrix(); }
sun.target.position.set(0, 1.5, -1); sun.position.set(-6, 14, 12);
function setMood(m){
  scene.background = m.sky; scene.fog.color.set(m.fog[0]); scene.fog.near = m.fog[1]; scene.fog.far = m.fog[2]; scene.environment = m.env ? envDay : envNight;
  hemi.color.set(m.hemi[0]); hemi.groundColor.set(m.hemi[1]); hemi.intensity = m.hemi[2]; sun.color.set(m.sun[0]); sun.intensity = m.sun[1];
  fill.color.set(0xffffff); fill.intensity = 0.35; fill.position.set(10, 8, 20);
}

/* =========================================================
   SET: Zimmer mit Tisch (Kaugummi-Packung), Fenster, WC-Tür
   ========================================================= */
const room = new THREE.Group(); scene.add(room);

(function(){
  const fl = new THREE.Mesh(new THREE.PlaneGeometry(40, 30), new THREE.MeshStandardMaterial({ color: 0xb98a5a, roughness: 0.85 })); fl.rotation.x = -PI / 2; fl.receiveShadow = true; room.add(fl);
  const wm = new THREE.MeshStandardMaterial({ color: 0xece2d0, roughness: 0.95 });
  const bw = new THREE.Mesh(new THREE.PlaneGeometry(40, 14), wm); bw.position.set(0, 7, -3.2); bw.receiveShadow = true; room.add(bw);
  P(room, rbox(40, 0.3, 0.12, 0.03, 1), mat(0xffffff), 0, 0.15, -3.12);
  // Fenster
  const win = new THREE.Mesh(new THREE.PlaneGeometry(2.0, 1.8), new THREE.MeshBasicMaterial({ color: 0xbfe0fa })); win.position.set(2.4, 3.6, -3.18); room.add(win);
  [[0, 0.95, 2.2, 0.16], [0, -0.95, 2.2, 0.16], [1.05, 0, 0.16, 2.06], [-1.05, 0, 0.16, 2.06], [0, 0, 0.08, 1.8]].forEach(([x, y, w, h]) => P(room, rbox(w, h, 0.1, 0.03, 1), mat(0xffffff), 2.4 + x, 3.6 + y, -3.12));
  // Tisch + Packung
  const wood = mat(0x8a5a36, { roughness: 0.6 });
  P(room, rbox(1.8, 0.12, 1.1, 0.04, 1), wood, 1.95, 1.6, -0.2); [[-0.8, -0.45], [0.8, -0.45], [-0.8, 0.45], [0.8, 0.45]].forEach(([x, z]) => P(room, rbox(0.1, 1.55, 0.1, 0.03, 1), wood, 1.95 + x, 0.78, -0.2 + z));
  // Pflanze
  P(room, new THREE.CylinderGeometry(0.35, 0.28, 0.7, 14), mat(0xc8694a), -1.4, 0.35, -2.5); P(room, new THREE.SphereGeometry(0.75, 14, 10), mat(0x4f9a46, { roughness: 0.9 }), -1.4, 1.35, -2.5);
})();
const SETS = [room];

/* =========================================================
   FIGUREN
   ========================================================= */
const SCAR = new THREE.Group(); ben.head.add(SCAR);
(function(){ const m = mat(0xa8463f, { roughness: 0.7 }); const s = new THREE.Mesh(rbox(0.075, 0.72, 0.03, 0.012, 1), m); s.position.set(0.25, 0.55, 0.522); s.rotation.z = -0.13; SCAR.add(s);
  for (const y of [0.36, 0.55, 0.74]){ const c = new THREE.Mesh(rbox(0.16, 0.035, 0.03, 0.01, 1), m); c.position.set(0.25 + (y - 0.55) * 0.13, y, 0.528); c.rotation.z = -0.13; SCAR.add(c); } })();
ben.L1 = 0.46; ben.L2 = 0.56;
const _ia = new THREE.Vector3(), _ib = new THREE.Vector3(), _ic = new THREE.Vector3(), _id = new THREE.Vector3(), _ie = new THREE.Vector3(), _if = new THREE.Vector3(), _ig = new THREE.Vector3(), _ih = new THREE.Vector3();
const _iq = new THREE.Quaternion(), _qa = new THREE.Quaternion(), _qb = new THREE.Quaternion(), _dn = new THREE.Vector3(0, -1, 0);
function ik(r, i, tw, pw){
  r.torso.updateWorldMatrix(true, false);
  const tl = r.torso.worldToLocal(_ia.copy(tw)); r.torso.getWorldQuaternion(_iq); const pl = _ib.copy(pw).applyQuaternion(_iq.invert());
  const S = _ic.set(i ? 0.67 : -0.67, 0.92, 0), D = _id.subVectors(tl, S), L1 = r.L1, L2 = r.L2;
  const d = Math.min(Math.max(D.length(), 0.15), L1 + L2 - 0.002); D.normalize();
  const a = Math.acos(Math.max(-1, Math.min(1, (L1 * L1 + d * d - L2 * L2) / (2 * L1 * d))));
  const n = _ie.crossVectors(D, pl).normalize(), e = _if.copy(D).applyAxisAngle(n, a);
  _qa.setFromUnitVectors(_dn, e); r.sh[i].quaternion.copy(_qa);
  const f = _ih.subVectors(tl, _ig.copy(S).addScaledVector(e, L1)).normalize().applyQuaternion(_qb.copy(_qa).invert());
  r.el[i].quaternion.setFromUnitVectors(_dn, f);
}
const MOUTH = new THREE.Vector3(0.03, 2.33, 0.6), DIR = new THREE.Vector3(-0.55, 0.5, 0.65).normalize(), POLE = new THREE.Vector3(-0.6, -1, 0.3), HAND = new THREE.Vector3(-0.74, 0.93, 0.05);
function mkBal(col){ const g = new THREE.Group(); scene.add(g); const m = new THREE.MeshStandardMaterial({ color: col, roughness: 0.28, envMapIntensity: 0.9 });
  const b = new THREE.Mesh(new THREE.SphereGeometry(1, 32, 22), m); b.castShadow = true; g.add(b); const k = new THREE.Mesh(new THREE.ConeGeometry(0.09, 0.16, 12), m); g.add(k);
  const s = new THREE.Mesh(new THREE.CylinderGeometry(0.012, 0.012, 1, 6), mat(0xf4f4f4)); scene.add(s); return { g, b, k, s }; }
const PB = mkBal(0xff5fa8), GB = mkBal(0x8c8f98);
const _bv = new THREE.Vector3(), _bk = new THREE.Vector3(), _up = new THREE.Vector3(0, 1, 0);
function balMouth(B, r){ B.g.visible = true; B.s.visible = false; _bk.copy(MOUTH).addScaledVector(DIR, 0.16); B.k.position.copy(_bk); B.k.quaternion.setFromUnitVectors(_up, DIR);
  B.b.position.copy(_bk).addScaledVector(DIR, r * 1.08 + 0.04); B.b.scale.set(r, r * 1.12, r); B.b.quaternion.setFromUnitVectors(_up, DIR); }
function balString(B, r, c){ B.g.visible = true; B.s.visible = true; B.b.position.copy(c); B.b.scale.set(r, r * 1.12, r); B.b.quaternion.set(0, 0, 0, 1);
  _bk.copy(c).add(new THREE.Vector3(0, -r * 1.12 - 0.05, 0)); B.k.position.copy(_bk); B.k.quaternion.set(1, 0, 0, 0);
  _bv.subVectors(_bk, HAND); const L = _bv.length(); B.s.position.copy(HAND).addScaledVector(_bv, 0.5); B.s.scale.set(1, L, 1); B.s.quaternion.setFromUnitVectors(_up, _bv.normalize()); }
function balHide(B){ B.g.visible = false; B.s.visible = false; }
function holdMouth(){ ik(ben, 0, _ih.copy(MOUTH).addScaledVector(DIR, 0.24).add(new THREE.Vector3(0, -0.1, 0)), POLE); }

/* =========================================================
   KAMERA + Zustand
   ========================================================= */
const cL = new THREE.Vector3();
let blurAmt = 0, fadeBlk = 0, T = 0, flashA = 0, eyeS = 1, talk = 0, dT = 0;
let waveK = 0, foldK = 0, specK = 0, bubK = 0, bubKind = 0, o2K = 0, banK = 0;
function camW(p, a, b){ cam.position.set(lerp(a[0], b[0], p), lerp(a[1], b[1], p), lerp(a[2], b[2], p)); cL.set(lerp(a[3], b[3], p), lerp(a[4], b[4], p), lerp(a[5], b[5], p)); cam.fov = lerp(a[6], b[6], p); }
function camFin(sh){ cam.position.x += Math.sin(dT * 0.7) * 0.012; cam.position.y += Math.sin(dT * 0.9 + 1) * 0.008; if (sh){ cam.position.x += Math.sin(T * 23) * sh; cam.position.y += Math.cos(T * 17) * sh; } cam.up.set(0, 1, 0); cam.lookAt(cL); cam.updateProjectionMatrix(); cam.updateMatrixWorld(); }
const imp = at => T >= at ? Math.exp(-(T - at) * 3) : 0;
const HOOK = [[2.4, 3.05, 7.2, -0.25, 2.8, 0.1, 36], [2.2, 3.0, 6.6, -0.25, 2.8, 0.1, 35]];
const MID = [2.0, 3.0, 13.0, -0.3, 2.8, 0, 40];
const FLOAT = t => new THREE.Vector3(-1.25 + 0.06 * Math.sin(t * 1.1), 4.75 + 0.08 * Math.sin(t * 1.7), 0.3);
function base(){ show(ben); ben.torso.scale.set(1, 1, 1); balHide(PB); balHide(GB); }
function stand(){ bRest(ben, T, 0); place(ben, 0, 0, 0, 0); }
function hookPose(r){ base(); stand(); balMouth(PB, r); holdMouth(); bFace(ben, 0.1, 0.1); eyeS = 1; }

/* =========================================================
   SZENEN (gekürzte Sprecherspur, Tempo 1,3)
   ========================================================= */
const SCN = [
  { t: 0, set: room, mood: MOOD.room, hook: 1,
    upd(lt){ dT = T; const r = lerp(0.75, 0.55, E.io(seg(T, 0.35, 2.2))); hookPose(r); ben.torso.scale.set(1 + 0.04 * seg(T, 0.35, 2.2), 1 + 0.03 * seg(T, 0.35, 2.2), 1 + 0.06 * seg(T, 0.35, 2.2)); eyeS = 1 + 0.35 * seg(T, 1.2, 2.2);
      camW(E.io(seg(lt, 0, 2.4)), HOOK[0], HOOK[1]); camFin(); } },
  { t: 2.4, set: room, mood: MOOD.room, hud: () => ['FAST 3× SCHNELLER', 'SCHALL IN HELIUM'],
    upd(lt){ dT = T; base(); stand(); balString(PB, 0.62, FLOAT(T)); bFace(ben, -0.2, 0.05); waveK = E.out(seg(T, 2.5, 2.8)) * (1 - seg(T, 4.95, 5.15));
      camW(E.io(seg(lt, 0, 1.5)), HOOK[1], MID); camFin(); } },
  { t: 5.15, set: room, mood: MOOD.room, hud: () => T < 7.8 ? ['STIMMBÄNDER', 'SCHWINGEN GLEICH SCHNELL'] : ['TONHÖHE BLEIBT!', 'GLEICHER GRUNDTON'],
    upd(lt){ dT = T; base(); stand(); balString(PB, 0.62, FLOAT(T)); bFace(ben, 0.1, 0.05); foldK = E.out(seg(T, 5.25, 5.55)) * (1 - seg(T, 8.85, 9.05)); camW(0, MID, MID); camFin(); } },
  { t: 9.05, set: room, mood: MOOD.room, hud: () => T < 11.2 ? ['KLANGFARBE', 'HOHE TÖNE WERDEN LAUTER'] : ['MICKY-MAUS-EFFEKT', 'HELL UND QUÄKIG'],
    upd(lt){ dT = T; base(); stand(); balString(PB, 0.62, FLOAT(T)); const tk = T > 11.25 ? 0.25 + 0.25 * Math.abs(Math.sin(T * 16)) : 0.05; bFace(ben, 0.4, tk);
      specK = E.out(seg(T, 9.15, 9.45)) * (1 - seg(T, 11.0, 11.2)); bubK = E.out(seg(T, 11.25, 11.45)) * (1 - seg(T, 12.6, 12.8)); bubKind = 0;
      camW(E.io(seg(lt, 0, 3.75)), MID, [1.6, 3.0, 10.5, -0.3, 2.8, 0, 38]); camFin(); } },
  { t: 12.8, set: room, mood: MOOD.room, hud: () => T < 14.6 ? ['SCHWEFELHEXAFLUORID', 'SCHWERES GAS'] : ['MONSTER-STIMME', 'SCHALL VIEL LANGSAMER'],
    upd(lt){ dT = T; base(); stand(); const rel = seg(T, 13.7, 14.3);
      if (T < 13.7){ balMouth(GB, 0.55); holdMouth(); bFace(ben, 0.1, 0.1); }
      else { const c = new THREE.Vector3(lerp(-0.4, -1.1, rel), lerp(2.72, 0.62, rel * rel), lerp(1.11, 0.9, rel)); const let0 = E.io(seg(T, 13.7, 14.0)); if (let0 < 1) ik(ben, 0, new THREE.Vector3().copy(MOUTH).addScaledVector(DIR, 0.24).add(new THREE.Vector3(0, -0.1, 0)).lerp(HAND, let0), POLE); balString(GB, 0.55, c); GB.s.visible = false; GB.b.position.y += rel >= 1 ? 0.06 * Math.abs(Math.sin((T - 14.3) * 8)) * Math.exp(-(T - 14.3) * 4) : 0;
        const tk = T > 14.65 ? 0.4 + 0.3 * Math.abs(Math.sin(T * 6)) : 0.1; bFace(ben, -0.8, tk); }
      bubK = E.out(seg(T, 14.65, 14.85)) * (1 - seg(T, 15.7, 15.9)); bubKind = 1;
      camW(E.io(seg(lt, 0, 3.1)), [2.2, 3.0, 9.6, -0.4, 2.4, 0.2, 38], [2.0, 2.9, 9.0, -0.4, 2.3, 0.2, 38]); camFin(); } },
  { t: 15.9, set: room, mood: MOOD.room, hud: () => T < 19.45 ? ['VORSICHT!', 'HELIUM VERDRÄNGT SAUERSTOFF'] : ['NIE AUS DER FLASCHE', 'LEBENSGEFAHR'],
    upd(lt){ dT = T; base(); stand(); balString(PB, 0.62, FLOAT(T)); const dz = E.io(seg(T, 18.05, 18.5)) * (1 - E.io(seg(T, 19.4, 19.9)));
      ben.root.rotation.z = 0.13 * dz * Math.sin(T * 3.2); ben.head.rotation.z = 0.15 * dz * Math.sin(T * 3.2 + 1); ben.root.position.x = 0.12 * dz * Math.sin(T * 3.2 - 0.5);
      eyeS = lerp(1, 0.35, dz); bFace(ben, dz > 0.5 ? 0.6 : -0.4, 0.2); o2K = E.out(seg(T, 16.0, 16.3)) * (1 - seg(T, 19.3, 19.5)); banK = E.out(seg(T, 19.45, 19.75)) * (1 - seg(T, 21.0, 21.2));
      camW(E.io(seg(lt, 0, 5.3)), [1.8, 2.9, 11.8, -0.2, 2.4, 0, 40], [1.6, 2.9, 11.0, -0.2, 2.4, 0, 40]); camFin(); } },
  { t: 21.2, set: room, mood: MOOD.room, hud: () => ['UND BEN?', 'LIEBER NORMALE LUFT'],
    upd(lt){ dT = T - END; base(); stand(); const up = E.io(seg(T, 21.3, 21.9));
      if (T < 21.9){ balString(PB, lerp(0.62, 0.32, up), FLOAT(T).lerp(_bv.copy(MOUTH).addScaledVector(DIR, 0.5), up)); PB.s.visible = up < 0.5; if (up > 0) ik(ben, 0, _ih.copy(HAND).lerp(new THREE.Vector3().copy(MOUTH).addScaledVector(DIR, 0.24).add(new THREE.Vector3(0, -0.1, 0)), up), POLE); bFace(ben, 0.3, 0.05); }
      else { const r = lerp(0.32, 0.75, E.io(seg(T, 22.1, 24.05))); balMouth(PB, r); holdMouth(); bFace(ben, 0.1, 0.1); ben.torso.scale.set(1 + 0.04 * (1 - seg(T, 22.1, 24.05)), 1, 1 + 0.06 * (1 - seg(T, 22.1, 24.05))); }
      eyeS = 1; camW(E.io(seg(lt, 0, 2.9)), MID, HOOK[0]); camFin(); } },
  { t: 24.1, set: room, mood: MOOD.room, loopin: 1,
    upd(lt){ dT = T - END; hookPose(0.75); camW(0, HOOK[0], HOOK[1]); camFin(); } },
];
const SUBS = __SUBS__;
