/* =========================================================
   STIMMUNG: Weltall, Jupiter-Wolken (orange-beige), Erde
   ========================================================= */
const MOOD = {
  spc: { bg: 0x02030a, fog: [0x02030a, 300, 900], hemi: [0xfff0e0, 0x302020, 0.7], sun: [0xfff4e8, 1.3] },
  cld: { bg: 0xc89a6a, fog: [0xc8986a, 10, 70], hemi: [0xffe6c8, 0x6a4a2a, 0.9], sun: [0xffe8c8, 0.8] },
  deep: { bg: 0x6a3a22, fog: [0x6a3a22, 6, 40], hemi: [0xffc8a0, 0x3a1a0a, 0.8], sun: [0xffc8a0, 0.5] },
  earth: { bg: 0x7ab8ec, fog: [0x8ac4f0, 40, 160], hemi: [0xf4faff, 0x5a7a40, 0.9], sun: [0xfff2dc, 1.15] } };
const SR = 12; { const c = sun.shadow.camera; c.left = -SR; c.right = SR; c.top = SR; c.bottom = -SR; c.near = 1; c.far = 80; c.updateProjectionMatrix(); }
function setMood(m){
  scene.background = new THREE.Color(m.bg); scene.fog.color.set(m.fog[0]); scene.fog.near = m.fog[1]; scene.fog.far = m.fog[2]; scene.environment = envDay;
  hemi.color.set(m.hemi[0]); hemi.groundColor.set(m.hemi[1]); hemi.intensity = m.hemi[2]; sun.color.set(m.sun[0]); sun.intensity = m.sun[1];
  sun.position.set(-12, 20, 14); sun.target.position.set(0, 0, 0); fill.color.set(0xffffff); fill.intensity = 0.3; fill.position.set(10, 6, 16);
}

/* =========================================================
   SETS
   ========================================================= */
function cvTex(w, h, f){ const c = document.createElement('canvas'); c.width = w; c.height = h; f(c.getContext('2d'), w, h); const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; return t; }
const bandTex = cvTex(512, 512, (x, w, h) => { const cols = ['#e8d2b0', '#c8925a', '#f2e2c8', '#b87a48', '#e8c898', '#a86a3a', '#f0dcc0', '#c88a52', '#e2c8a0'];
  for (let i = 0; i < 26; i++){ x.fillStyle = cols[i % cols.length]; x.fillRect(0, i * h / 26, w, h / 26 + 1); }
  for (let i = 0; i < 260; i++){ x.fillStyle = `rgba(${hsh(i) > 0.5 ? '255,240,220' : '120,70,40'},0.18)`; x.beginPath(); x.ellipse(hsh(i + 1) * w, hsh(i + 2) * h, 20 + hsh(i + 3) * 50, 3 + hsh(i + 4) * 5, 0, 0, PI * 2); x.fill(); }
  x.fillStyle = '#c0503a'; x.beginPath(); x.ellipse(w * 0.62, h * 0.66, 46, 22, 0, 0, PI * 2); x.fill(); x.fillStyle = '#d87050'; x.beginPath(); x.ellipse(w * 0.62, h * 0.66, 30, 13, 0, 0, PI * 2); x.fill(); });
const SPC = new THREE.Group(); scene.add(SPC);
const JUP = new THREE.Mesh(new THREE.SphereGeometry(70, 64, 48), new THREE.MeshStandardMaterial({ map: bandTex, roughness: 1, fog: false })); JUP.position.set(0, -76, -50); JUP.rotation.z = 0.12; SPC.add(JUP);
{ const n = 900, p = new Float32Array(n * 3); for (let i = 0; i < n; i++){ const a = hsh(i) * PI * 2, b = Math.acos(2 * hsh(i + 7) - 1), r = 500; p[i * 3] = r * Math.sin(b) * Math.cos(a); p[i * 3 + 1] = r * Math.cos(b); p[i * 3 + 2] = r * Math.sin(b) * Math.sin(a); }
  const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.BufferAttribute(p, 3)); SPC.add(new THREE.Points(g, new THREE.PointsMaterial({ color: 0xffffff, size: 1.6, sizeAttenuation: false, fog: false }))); }
// Wolkenschichten
const cloudTex = cvTex(512, 512, (x, w, h) => { x.clearRect(0, 0, w, h); for (let i = 0; i < 140; i++){ const cx = hsh(i * 3) * w, cy = hsh(i * 5) * h, r = 30 + hsh(i * 7) * 70; const g = x.createRadialGradient(cx, cy, 0, cx, cy, r); g.addColorStop(0, 'rgba(255,255,255,0.55)'); g.addColorStop(1, 'rgba(255,255,255,0)'); x.fillStyle = g; x.fillRect(cx - r, cy - r, 2 * r, 2 * r); } });
cloudTex.wrapS = cloudTex.wrapT = THREE.RepeatWrapping; cloudTex.repeat.set(3, 3);
const CLD = new THREE.Group(); scene.add(CLD); const LAYERS = []; const LC = [0xf2dcb8, 0xd8a06a, 0xe8c090, 0xc07a48, 0xf0d0a0, 0xb06a3a];
for (let i = 0; i < 6; i++){ const m = new THREE.Mesh(new THREE.PlaneGeometry(160, 160), new THREE.MeshBasicMaterial({ map: cloudTex, color: LC[i], transparent: true, opacity: 0.8, depthWrite: false, side: THREE.DoubleSide })); m.rotation.x = -PI / 2; CLD.add(m); LAYERS.push(m); }
const LSP = 7;
function layers(depth, camY){ LAYERS.forEach((m, i) => { let y = ((i * LSP - depth) % (6 * LSP) + 6 * LSP) % (6 * LSP) - 3.5 * LSP; m.position.y = y; const dy = Math.abs(y - camY); m.material.opacity = 0.75 * clamp01((dy - 1.5) / 4) * clamp01(1 - Math.abs(y) / (3.4 * LSP)); }); }
const STREAKS = []; { const sm = new THREE.MeshBasicMaterial({ color: 0xfff4e0, transparent: true, opacity: 0.45, depthWrite: false }); for (let i = 0; i < 40; i++){ const s = new THREE.Mesh(new THREE.BoxGeometry(9 + hsh(i) * 8, 0.06, 0.06), sm); CLD.add(s); STREAKS.push(s); } }
function streaks(on, t){ STREAKS.forEach((s, i) => { s.visible = on; if (!on) return; const x = ((t * 34 + hsh(i * 2) * 80) % 80) - 40; s.position.set(x, -4 + hsh(i * 3) * 12, -10 + hsh(i * 5) * 14); }); }
// Sonde (Galileo-artig)
const PRB = new THREE.Group(); CLD.add(PRB); const PRBM = new THREE.MeshStandardMaterial({ color: 0xb8b8bc, metalness: 0.6, roughness: 0.4, emissive: 0xff4a10, emissiveIntensity: 0 });
P(PRB, new THREE.ConeGeometry(1.4, 1.0, 24), mat(0x5a3a2a, { roughness: 0.8 }), 0, -0.5, 0).rotation.x = PI; P(PRB, new THREE.CylinderGeometry(1.0, 1.2, 1.2, 20), PRBM, 0, 0.5, 0); P(PRB, new THREE.CylinderGeometry(0.3, 0.3, 0.6, 10), PRBM, 0, 1.4, 0);
// Jupiter im Schnitt
const CUT = new THREE.Group(); scene.add(CUT);
(function(){ const sh = new THREE.Mesh(new THREE.SphereGeometry(10, 64, 40, PI, PI), new THREE.MeshStandardMaterial({ map: bandTex, roughness: 1, side: THREE.DoubleSide })); CUT.add(sh);
  [[10, 0xe8c898], [8.6, 0xc8a070], [6.4, 0x7a8aa8], [2.0, 0x6a4a3a]].forEach(([r, c], i) => { const m = new THREE.Mesh(new THREE.CircleGeometry(r, 72), new THREE.MeshBasicMaterial({ color: c, fog: false })); m.position.z = 0.01 + i * 0.01; CUT.add(m); }); })();
// Erde: Wiese
const GRD = new THREE.Group(); scene.add(GRD);
(function(){ const g = new THREE.Mesh(new THREE.PlaneGeometry(200, 200), mat(0x6aa850, { roughness: 1 })); g.rotation.x = -PI / 2; g.receiveShadow = true; GRD.add(g);
  const tr = mat(0x5a3e28), lf = mat(0x3f8a3a, { roughness: 0.9, flatShading: true });
  for (let i = 0; i < 14; i++){ const a = i / 14 * PI * 2, d = 12 + hsh(i) * 8; P(GRD, new THREE.CylinderGeometry(0.25, 0.35, 3, 6), tr, Math.cos(a) * d, 1.5, Math.sin(a) * d - 6); P(GRD, new THREE.DodecahedronGeometry(1.8 + hsh(i) * 0.8, 0), lf, Math.cos(a) * d, 3.8, Math.sin(a) * d - 6); }
  const fl = [mat(0xf2e24a), mat(0xf2f2f2), mat(0xd85ab8)]; for (let i = 0; i < 70; i++) P(GRD, new THREE.SphereGeometry(0.07, 6, 4), fl[i % 3], (hsh(i * 3) - 0.5) * 18, 0.08, (hsh(i * 5) - 0.5) * 12);
})();
const SETS = [SPC, CLD, CUT, GRD];

/* =========================================================
   BEN: Narbe, Raumanzug, Fallschirm
   ========================================================= */
const SCAR = new THREE.Group(); ben.head.add(SCAR);
(function(){ const m = mat(0xa8463f, { roughness: 0.7 }); const s = new THREE.Mesh(rbox(0.075, 0.72, 0.03, 0.012, 1), m); s.position.set(0.25, 0.55, 0.522); s.rotation.z = -0.13; SCAR.add(s);
  for (const y of [0.36, 0.55, 0.74]){ const c = new THREE.Mesh(rbox(0.16, 0.035, 0.03, 0.01, 1), m); c.position.set(0.25 + (y - 0.55) * 0.13, y, 0.528); c.rotation.z = -0.13; SCAR.add(c); } })();
const SUIT = new THREE.Group(); const HELM = new THREE.Group(); ben.head.add(HELM); ben.torso.add(SUIT);
(function(){ const gl = new THREE.Mesh(new THREE.SphereGeometry(0.98, 24, 18), new THREE.MeshStandardMaterial({ color: 0xcfeaff, transparent: true, opacity: 0.22, roughness: 0.05, metalness: 0.2, depthWrite: false })); gl.position.y = 0.58; gl.renderOrder = 3; HELM.add(gl);
  const ring = new THREE.Mesh(new THREE.TorusGeometry(0.62, 0.1, 10, 28), mat(0xe8e8ec, { metalness: 0.4, roughness: 0.3 })); ring.rotation.x = PI / 2; ring.position.y = -0.08; HELM.add(ring);
  P(SUIT, rbox(0.9, 0.95, 0.42, 0.08), mat(0xe8e8ec, { roughness: 0.5 }), 0, 0.55, -0.5); P(SUIT, rbox(0.5, 0.18, 0.06, 0.03, 1), mat(0xd04030), 0, 0.85, -0.73); })();
function suit(on){ SUIT.visible = on; HELM.visible = on; }
const CHUTE = new THREE.Group(); ben.root.add(CHUTE);
(function(){ const c = new THREE.Mesh(new THREE.SphereGeometry(2.6, 24, 10, 0, PI * 2, 0, PI / 2.4), new THREE.MeshStandardMaterial({ color: 0xff7a2a, roughness: 0.7, side: THREE.DoubleSide })); c.position.y = 6.2; c.scale.y = 0.6; CHUTE.add(c);
  const lm = mat(0xf2f2f2); for (let k = 0; k < 8; k++){ const a = k / 8 * PI * 2; rod(CHUTE, lm, [Math.cos(a) * 2.1, 6.9, Math.sin(a) * 2.1], [0, 3.2, 0], 0.02); } })();

/* =========================================================
   KAMERA + Zustand
   ========================================================= */
const cL = new THREE.Vector3();
let blurAmt = 0, fadeBlk = 0, T = 0, flashA = 0, eyeS = 1, talk = 0, dT = 0;
let gasK = 0, gK = 0, windK = 0, prbK = 0, firmK = 0;
function camW(p, a, b){ cam.position.set(lerp(a[0], b[0], p), lerp(a[1], b[1], p), lerp(a[2], b[2], p)); cL.set(lerp(a[3], b[3], p), lerp(a[4], b[4], p), lerp(a[5], b[5], p)); cam.fov = lerp(a[6], b[6], p); }
function camFin(sh){ cam.position.x += Math.sin(dT * 0.7) * 0.03; cam.position.y += Math.sin(dT * 0.9 + 1) * 0.02; if (sh){ cam.position.x += Math.sin(T * 5) * sh; cam.position.y += Math.cos(T * 4) * sh; } cam.up.set(0, 1, 0); cam.lookAt(cL); cam.updateProjectionMatrix(); cam.updateMatrixWorld(); }
const HOOK = [[3.6, 4.2, 9.0, 0, -1.0, -6, 52], [3.4, 4.0, 8.6, 0, -1.2, -6, 52]];
function base(){ show(ben); suit(true); CHUTE.visible = false; streaks(false, 0); PRB.visible = false; }
function fallPose(t){ bRest(ben, t, 0); [0, 1].forEach(i => { const s = i ? 1 : -1; ben.sh[i].rotation.set(-0.3, 0, s * (1.3 + 0.1 * Math.sin(t * 3 + i))); ben.el[i].rotation.x = -0.3; }); ben.legs[0].rotation.x = 0.2; ben.legs[1].rotation.x = -0.25; }
function hookBen(t){ fallPose(t); place(ben, 0, 1.2 * Math.sin(t * 0.8) * 0.2, 0, -0.3); eyeS = 1.3; bFace(ben, -0.6, 0.4); JUP.rotation.y = t * 0.02; }
function hang(t){ bRest(ben, t, 0); CHUTE.visible = true; [0, 1].forEach(i => { const s = i ? 1 : -1; ben.sh[i].rotation.set(-2.7, 0, s * 0.35); ben.el[i].rotation.x = -0.2; }); ben.legs[0].rotation.x = 0.15; ben.legs[1].rotation.x = -0.1; }

/* =========================================================
   SZENEN (Sprecherspur Tempo 1,1)
   ========================================================= */
const SCN = [
  { t: 0, set: SPC, mood: MOOD.spc, hook: 1,
    upd(lt){ dT = T; base(); hookBen(T); camW(E.io(seg(lt, 0, 3.46)), HOOK[0], [3.0, 3.4, 7.6, 0, -1.4, -6, 52]); camFin(); } },
  { t: 3.46, set: CLD, mood: MOOD.cld, hud: () => ['KEIN BODEN', 'NUR WOLKEN UND GAS'],
    upd(lt){ dT = T; base(); fallPose(T); place(ben, 0, 0, 0, -0.3); eyeS = 1.4; bFace(ben, -0.9, 0.5); layers((T - 3.46) * 9, 3.2);
      camW(E.io(seg(lt, 0, 2.62)), [3.6, 3.2, 8.0, 0, 0.4, 0, 52], [3.2, 3.2, 7.4, 0, 0.2, 0, 52]); camFin(); } },
  { t: 6.08, set: CUT, mood: MOOD.spc, hud: () => ['FAST NUR GAS', 'WASSERSTOFF UND HELIUM'],
    upd(lt){ dT = T; show(); gasK = E.out(seg(T, 6.2, 6.5)) * (1 - seg(T, 8.3, 8.44));
      camW(E.io(seg(lt, 0, 2.36)), [0, -3.0, 40, 0, -3.0, 0, 50], [0, -3.0, 36, 0, -3.0, 0, 50]); camFin(); } },
  { t: 8.44, set: CLD, mood: MOOD.cld, hud: () => ['IMMER TIEFER', '2,5-FACHE SCHWERKRAFT'],
    upd(lt){ dT = T; base(); hang(T); place(ben, 0, 0, 0, -0.2); ben.torso.rotation.x = 0.15; ben.head.rotation.x = 0.2; eyeS = 1.2; bFace(ben, -0.7, 0.3); layers(25 + (T - 8.44) * 4, 3.6);
      gK = E.out(seg(T, 8.6, 8.9)) * (1 - seg(T, 12.2, 12.34));
      camW(E.io(seg(lt, 0, 3.9)), [4.0, 3.6, 10.0, 0, 3.2, 0, 54], [3.4, 3.4, 9.2, 0, 3.2, 0, 54]); camFin(); } },
  { t: 12.34, set: CLD, mood: MOOD.cld, hud: () => ['STURM', 'ÜBER 600 KM/H'],
    upd(lt){ dT = T; base(); hang(T); const sw = 0.45 + 0.12 * Math.sin(T * 2.2); place(ben, 0, 0, 0, -0.2); ben.root.rotation.z = -sw; eyeS = 1.5; bFace(ben, -1, 0.7); layers(40 + (T - 12.34) * 3, 3.6); streaks(true, T);
      windK = E.out(seg(T, 12.5, 12.8)) * (1 - seg(T, 15.7, 15.84));
      camW(E.io(seg(lt, 0, 3.5)), [-3.0, 3.6, 10.5, 1.0, 3.2, 0, 56], [-2.4, 3.4, 9.8, 1.0, 3.2, 0, 56]); camFin(0.03); } },
  { t: 15.84, set: CLD, mood: MOOD.deep, hud: () => ['GIGANTISCHER DRUCK', 'SONDEN WERDEN ZERSTÖRT'],
    upd(lt){ dT = T; show(); PRB.visible = true; streaks(false, 0); layers(50 + (T - 15.84) * 3, 2.0); const c = E.io(seg(T, 16.6, 19.2)); PRB.position.set(0, 1.0 - (T - 15.84) * 0.4, 0); PRB.rotation.y = T * 0.3; PRB.scale.set(1 + 0.25 * c, 1 - 0.55 * c, 1 + 0.25 * c); PRBM.emissiveIntensity = 0.9 * c;
      prbK = E.out(seg(T, 16.0, 16.3)) * (1 - seg(T, 19.72, 19.88));
      camW(E.io(seg(lt, 0, 4.04)), [3.6, 2.4, 7.0, 0, -0.2, 0, 46], [2.8, 1.6, 5.6, 0, -0.6, 0, 46]); camFin(); } },
  { t: 19.88, set: GRD, mood: MOOD.earth, hud: () => ['UND BEN?', 'LIEBER FESTER BODEN'],
    upd(lt){ dT = T; show(ben); suit(false); CHUTE.visible = false; bRest(ben, T, 0); const ph = ((T - 19.88) % 0.7) / 0.7, y = 0.5 * Math.sin(PI * ph) * (T > 20.3 ? 1 : 0); place(ben, 0, y, 0, 0.2);
      ben.sh[0].rotation.set(-2.6, 0, -0.4); ben.sh[1].rotation.set(-2.6, 0, 0.4); eyeS = 1.1; bFace(ben, 1, 0.4); firmK = E.out(seg(T, 20.2, 20.5)) * (1 - seg(T, 22.55, 22.7));
      camW(E.io(seg(lt, 0, 2.82)), [2.6, 2.8, 8.0, 0, 2.0, 0, 46], [2.0, 2.6, 7.0, 0, 2.0, 0, 46]); camFin(); } },
  { t: 22.7, set: SPC, mood: MOOD.spc, loopin: 1,
    upd(lt){ dT = T - END; base(); hookBen(T - END); camW(0, HOOK[0], HOOK[1]); camFin(); } },
];
const SUBS = __SUBS__;
