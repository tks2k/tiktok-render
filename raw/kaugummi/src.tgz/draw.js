/* =========================================================
   TEXT (neues Format: fett, Großbuchstaben, aktives Wort gelb)
   ========================================================= */
const SANS = '"Arial Black", "Helvetica Neue", Arial, system-ui, sans-serif', SERIF = SANS;
const band = document.createElement('canvas'); band.width = 8; band.height = 512;
(function(){ const x = band.getContext('2d'), g = x.createLinearGradient(0, 0, 0, 512); g.addColorStop(0, 'rgba(10,14,24,0)'); g.addColorStop(0.5, 'rgba(10,14,24,0.42)'); g.addColorStop(1, 'rgba(10,14,24,0)'); x.fillStyle = g; x.fillRect(0, 0, 8, 512); })();
function boldLines(words, cy, size, maxW, act, pop, col){
  g2.save(); g2.font = `900 ${size}px ${SANS}`; g2.textBaseline = 'middle'; g2.lineJoin = 'round';
  const spc = size * 0.28, lines = [[]]; let lw = 0;
  words.forEach((w, i) => { const wd = g2.measureText(w).width; if (lw + wd > maxW && lines[lines.length - 1].length){ lines.push([]); lw = 0; } lines[lines.length - 1].push({ w, wd, i }); lw += wd + spc; });
  const lh = size * 1.12, y0 = cy - (lines.length - 1) * lh / 2;
  lines.forEach((ln, li) => { const tw = ln.reduce((a, b) => a + b.wd, 0) + spc * (ln.length - 1); let x = W / 2 - tw / 2;
    ln.forEach(tk => { const on = tk.i === act, s = on ? 1 + 0.08 * pop : 1, y = y0 + li * lh;
      g2.save(); g2.translate(x + tk.wd / 2, y); g2.scale(s, s);
      g2.lineWidth = size * 0.2; g2.strokeStyle = '#0b1220'; g2.strokeText(tk.w, -tk.wd / 2, 0);
      g2.fillStyle = on ? '#ffd23c' : (col || '#ffffff'); g2.fillText(tk.w, -tk.wd / 2, 0); g2.restore(); x += tk.wd + spc; }); });
  g2.restore();
}
function fitSize(text, size, maxW){ g2.font = `900 ${size}px ${SANS}`; const w = g2.measureText(text).width; return w > maxW ? size * maxW / w : size; }
function drawHook(a, sc){
  if (a <= 0) return; g2.save(); g2.globalAlpha = a; g2.drawImage(band, 0, 340, W, 520);
  const s1 = fitSize('KAUGUMMI GESCHLUCKT', 120, 960), s2 = fitSize('7 JAHRE IM MAGEN?', 120, 900);
  g2.translate(W / 2, 600); g2.scale(sc, sc); g2.translate(-W / 2, -600);
  boldLines(['KAUGUMMI', 'GESCHLUCKT'], 535, s1, 1000, -1, 0); boldLines(['7', 'JAHRE', 'IM', 'MAGEN?'], 670, s2, 940, -1, 0, '#ffd23c');
  g2.restore();
}
function drawSubs(){
  let cur = null; for (const s of SUBS) if (T >= s.s && T < s.e) cur = s; if (!cur) return;
  let act = 0; cur.w.forEach((w, i) => { if (T >= w[1]) act = i; });
  const pop = clamp01(1 - (T - cur.w[act][1]) / 0.18), age = T - cur.s, a = E.out(clamp01(age / 0.08));
  g2.save(); g2.globalAlpha = a; g2.drawImage(band, 0, 1060, W, 400);
  const yy = 1260 + (1 - a) * 14;
  if (cur.ben){ boldLines(cur.w.map(w => w[0]), yy, 112, 880, act, pop, '#ffffff'); g2.font = `900 34px ${SANS}`; g2.textAlign = 'center'; g2.fillStyle = '#ffd23c'; g2.strokeStyle = '#0b1220'; g2.lineWidth = 8; g2.strokeText('— BEN', W / 2, yy + 100); g2.fillText('— BEN', W / 2, yy + 100); }
  else boldLines(cur.w.map(w => w[0]), yy, 78, 880, act, pop);
  g2.restore();
}
function drawHud(h){
  if (!h) return; g2.save(); g2.textAlign = 'center'; g2.textBaseline = 'middle'; g2.lineJoin = 'round';
  const big = fitSize(h[0], 140, 880); g2.font = `900 ${big}px ${SANS}`; g2.lineWidth = 24; g2.strokeStyle = '#0b1220'; g2.strokeText(h[0], W / 2, 400); g2.fillStyle = '#ffffff'; g2.fillText(h[0], W / 2, 400);
  if (h[1]){ g2.font = `900 40px ${SANS}`; g2.lineWidth = 10; g2.strokeText(h[1], W / 2, 500); g2.fillStyle = '#ffd23c'; g2.fillText(h[1], W / 2, 500); }
  g2.restore();
}
function glowDot(x, y, r, col, a){ if (a <= 0) return; const g = g2.createRadialGradient(x, y, 0, x, y, r); g.addColorStop(0, 'rgba(255,255,255,' + Math.min(1, a) + ')'); g.addColorStop(0.25, col.replace('A', Math.min(1, a) * 0.9)); g.addColorStop(1, col.replace('A', 0)); g2.fillStyle = g; g2.fillRect(x - r, y - r, 2 * r, 2 * r); }
function wp(x, y, z){ return proj(new THREE.Vector3(x, y, z)); }
function txt(s, x, y, size, col, al){ g2.font = `900 ${size}px ${SANS}`; g2.textAlign = al || 'center'; g2.textBaseline = 'middle'; g2.lineJoin = 'round'; g2.lineWidth = size * 0.22; g2.strokeStyle = '#0b1220'; g2.strokeText(s, x, y); g2.fillStyle = col; g2.fillText(s, x, y); }
const _p = new THREE.Vector3();
function wl(o, x, y, z){ o.updateWorldMatrix(true, false); return proj(o.localToWorld(_p.set(x, y, z))); }
function along(P, f){ let L = 0; const sg = []; for (let i = 1; i < P.length; i++){ const q = Math.hypot(P[i][0] - P[i - 1][0], P[i][1] - P[i - 1][1]); sg.push(q); L += q; } let r = f * L;
  for (let i = 0; i < sg.length; i++){ if (r <= sg[i]){ const k = r / sg[i]; return [lerp(P[i][0], P[i + 1][0], k), lerp(P[i][1], P[i + 1][1], k)]; } r -= sg[i]; } return P[P.length - 1]; }
function path(P){ g2.beginPath(); g2.moveTo(P[0][0], P[0][1]); for (let i = 1; i < P.length; i++) g2.lineTo(P[i][0], P[i][1]); }
function star(x, y, r){ g2.beginPath(); for (let k = 0; k < 3; k++){ const a = k * PI / 3; g2.moveTo(x - Math.cos(a) * r, y - Math.sin(a) * r); g2.lineTo(x + Math.cos(a) * r, y + Math.sin(a) * r); } g2.stroke(); }
function flame(x, y, s, a){ g2.save(); g2.globalAlpha = a; g2.translate(x, y); const w = 1 + 0.08 * Math.sin(T * 14);
  g2.beginPath(); g2.moveTo(0, -1.1 * s * w); g2.bezierCurveTo(0.7 * s, -0.4 * s, 0.6 * s, 0.5 * s, 0, 0.55 * s); g2.bezierCurveTo(-0.6 * s, 0.5 * s, -0.7 * s, -0.4 * s, 0, -1.1 * s * w); g2.fillStyle = '#ff5a1f'; g2.fill();
  g2.beginPath(); g2.moveTo(0, -0.5 * s * w); g2.bezierCurveTo(0.35 * s, -0.1 * s, 0.3 * s, 0.4 * s, 0, 0.45 * s); g2.bezierCurveTo(-0.3 * s, 0.4 * s, -0.35 * s, -0.1 * s, 0, -0.5 * s * w); g2.fillStyle = '#ffd23c'; g2.fill(); g2.restore(); }

const X0 = W / 2, ESO = [[X0, 700], [X0, 790], [X0 + 25, 860], [X0 + 75, 900]], STC = [X0 + 95, 935];
const INT = [[X0 + 15, 1005], [X0 - 110, 1035], [X0 - 170, 1090], [X0 - 70, 1125], [X0 + 120, 1110], [X0 + 175, 1170], [X0 + 50, 1215], [X0 - 150, 1225], [X0 - 130, 1300], [X0 + 100, 1310], [X0 + 60, 1385], [X0, 1440]];
const GUT = [STC].concat(INT);
function blob(x, y, r, g){ const c1 = [255, 111, 179], c2 = [150, 150, 166], c = c1.map((v, i) => Math.round(lerp(v, c2[i], g)));
  g2.beginPath(); g2.arc(x, y, r, 0, 7); g2.fillStyle = `rgb(${c[0]},${c[1]},${c[2]})`; g2.fill(); g2.lineWidth = 6; g2.strokeStyle = '#0b1220'; g2.stroke();
  g2.beginPath(); g2.arc(x - r * 0.3, y - r * 0.35, r * 0.25, 0, 7); g2.fillStyle = 'rgba(255,255,255,0.55)'; g2.fill(); }
function gumAt(t){ if (t < 2.8) return ESO[0]; if (t < 3.9) return along(ESO.concat([STC]), E.io(seg(t, 2.8, 3.9)));
  if (t < 11.4) { const w = t > 9.4 ? 10 * Math.sin(t * 6) : 4 * Math.sin(t * 2); return [STC[0] + w, STC[1] + 0.6 * w]; }
  if (t < 12.85) return along(GUT, 0.55 * E.io(seg(t, 11.4, 12.85))); return along(GUT, lerp(0.55, 1, E.io(seg(t, 12.95, 14.8)))); }
function drawXray(a){ if (a <= 0) return; g2.save(); g2.globalAlpha = a; g2.fillStyle = 'rgba(6,14,30,0.62)'; g2.fillRect(0, 0, W, H);
  g2.lineWidth = 6; g2.strokeStyle = 'rgba(160,200,255,0.75)'; g2.fillStyle = 'rgba(120,170,255,0.10)';
  g2.beginPath(); g2.arc(X0, 590, 125, 0, 7); g2.fill(); g2.stroke(); g2.beginPath(); g2.roundRect(X0 - 300, 745, 600, 760, 60); g2.fill(); g2.stroke();
  g2.lineCap = 'round'; g2.lineJoin = 'round';
  path(ESO); g2.lineWidth = 40; g2.strokeStyle = 'rgba(255,160,185,0.35)'; g2.stroke(); g2.lineWidth = 4; g2.strokeStyle = 'rgba(255,190,205,0.7)'; g2.stroke();
  path(INT); g2.lineWidth = 50; g2.strokeStyle = 'rgba(255,150,170,0.30)'; g2.stroke(); g2.lineWidth = 4; g2.strokeStyle = 'rgba(255,180,195,0.6)'; g2.stroke();
  const kn = T > 9.4 && T < 12.0 ? 1 : 0, wb = kn * 0.07 * Math.sin(T * 6);
  g2.save(); g2.translate(STC[0], STC[1]); g2.rotate(-0.35); g2.beginPath(); g2.ellipse(0, 0, 150 * (1 + wb), 92 * (1 - wb), 0, 0, 7); g2.fillStyle = 'rgba(255,140,170,0.32)'; g2.fill(); g2.lineWidth = 6; g2.strokeStyle = 'rgba(255,190,205,0.85)'; g2.stroke();
  if (kn) for (let i = 0; i < 2; i++){ const ph = ((T - 9.4) * 0.8 + i * 0.5) % 1, x = lerp(-120, 120, ph); g2.globalAlpha = a * Math.sin(PI * ph); g2.beginPath(); g2.moveTo(x, -80); g2.quadraticCurveTo(x - 20, 0, x, 80); g2.lineWidth = 10; g2.strokeStyle = '#ff8fb0'; g2.stroke(); }
  g2.restore(); g2.globalAlpha = a;
  txt('MAGEN', STC[0] + 175, STC[1] - 95, 34, '#ffc4d4'); txt('DARM', X0 - 230, 1160, 30, '#ffc4d4');
  if (lumpK <= 0 && T < 14.9){ const p = gumAt(T), gr = seg(T, 4.7, 6.6); blob(p[0], p[1], 28, gr);
    for (let i = 0; i < 10; i++){ const ph = (T - 4.6 - i * 0.18) / 0.9; if (ph <= 0 || ph >= 1) continue; const an = i * 2.4; const x = p[0] + Math.cos(an) * (30 + 70 * ph), y = p[1] + Math.sin(an) * (30 + 50 * ph) - 40 * ph;
      g2.globalAlpha = a * Math.sin(PI * ph); g2.lineWidth = 5; g2.strokeStyle = '#ffd23c'; star(x, y, 12); }
    g2.globalAlpha = a;
    if (T > 6.95 && T < 9.3){ g2.globalAlpha = a * E.out(seg(T, 6.95, 7.2)); txt('GUMMI-BASE', p[0] - 10, p[1] - 70, 40, '#ffffff'); if (T > 8.0) txt('≈ KUNSTSTOFF', p[0] - 10, p[1] + 72, 36, '#ffd23c'); }
    if (T > 4.6 && T < 6.85){ g2.globalAlpha = a * E.out(seg(T, 4.7, 4.95)); txt('ZUCKER LÖST SICH', p[0] - 40, p[1] - 70, 36, '#ffd23c'); } }
  if (lumpK > 0){ const L = along(INT, 0.12), n = 12; let got = 0;
    for (let i = 0; i < n; i++){ const t0 = 16.8 + i * 0.22, u = seg(T, t0, t0 + 0.9); if (u >= 1){ got++; continue; } if (u <= 0) continue; const p = along(GUT, lerp(0, 0.17, E.io(u))); blob(p[0], p[1], 18, 0.5); }
    const r = 22 + 46 * (got / n); blob(L[0], L[1], r, 0.6);
    if (T > 19.6){ const pk = 0.5 + 0.5 * Math.sin((T - 19.6) * 6); g2.beginPath(); g2.arc(L[0], L[1], r + 26 + 10 * pk, 0, 7); g2.lineWidth = 9; g2.strokeStyle = `rgba(255,74,58,${0.55 + 0.4 * pk})`; g2.stroke(); txt('STAU!', L[0] - 10, L[1] - r - 60, 50, '#ff6a5a'); } }
  g2.restore(); }
function drawClock(a){ if (a <= 0) return; g2.save(); g2.globalAlpha = a; const cx = W - 200, cy = 660; g2.fillStyle = 'rgba(11,18,32,0.7)'; g2.beginPath(); g2.roundRect(cx - 150, cy - 110, 300, 250, 26); g2.fill();
  g2.beginPath(); g2.arc(cx, cy - 10, 70, 0, 7); g2.fillStyle = '#ffffff'; g2.fill(); g2.lineWidth = 8; g2.strokeStyle = '#0b1220'; g2.stroke();
  const an = (T - 12.95) * 2 * PI * 0.9 - PI / 2; g2.lineCap = 'round'; g2.lineWidth = 9; g2.strokeStyle = '#0b1220'; g2.beginPath(); g2.moveTo(cx, cy - 10); g2.lineTo(cx + Math.cos(an) * 52, cy - 10 + Math.sin(an) * 52); g2.stroke();
  g2.lineWidth = 7; g2.beginPath(); g2.moveTo(cx, cy - 10); g2.lineTo(cx + Math.cos(an / 12) * 34, cy - 10 + Math.sin(an / 12) * 34); g2.stroke();
  txt('+1–2 TAGE', cx, cy + 100, 40, '#ffd23c'); g2.restore(); }

function heart(x, y, s){ g2.beginPath(); g2.moveTo(x, y + 0.35 * s); g2.bezierCurveTo(x - 1.1 * s, y - 0.35 * s, x - 0.45 * s, y - 1.0 * s, x, y - 0.45 * s); g2.bezierCurveTo(x + 0.45 * s, y - 1.0 * s, x + 1.1 * s, y - 0.35 * s, x, y + 0.35 * s); g2.closePath(); }
function drawHeart(a){ if (a <= 0) return; const ph = (T * 2.5) % 1, beat = ph < 0.15 ? Math.sin(ph / 0.15 * PI) : 0, s = 70 * (1 + 0.22 * beat);
  g2.save(); g2.globalAlpha = a; heart(W / 2, 660, s); g2.fillStyle = '#ff3b3b'; g2.fill(); g2.lineWidth = 10; g2.strokeStyle = '#0b1220'; g2.stroke(); g2.restore(); }
const vig = document.createElement('canvas'); vig.width = 270; vig.height = 480;
(function(){ const x = vig.getContext('2d'), g = x.createRadialGradient(135, 240, 120, 135, 240, 330); g.addColorStop(0, 'rgba(0,0,0,0)'); g.addColorStop(1, 'rgba(0,0,0,0.38)'); x.fillStyle = g; x.fillRect(0, 0, 270, 480); })();
function draw2D(sc, lt, dur){
  g2.globalAlpha = 1; g2.globalCompositeOperation = 'source-over'; g2.drawImage(renderer.domElement, 0, 0, W, H);
  g2.globalAlpha = 1; g2.globalCompositeOperation = 'source-over'; g2.drawImage(vig, 0, 0, W, H);
  if (flashA > 0){ g2.fillStyle = `rgba(255,250,240,${Math.min(1, flashA)})`; g2.fillRect(0, 0, W, H); }
  if (fadeBlk > 0){ g2.fillStyle = `rgba(0,0,0,${fadeBlk})`; g2.fillRect(0, 0, W, H); }
  drawXray(xrK); drawClock(clockK);
  if (sc.hud) drawHud(sc.hud());
  if (sc.hook) drawHook(clamp01((dur - lt) / 0.15), 1);
  if (sc.loopin){ const k = clamp01((T - (END - 0.14)) / 0.14); drawHook(k, 1 + 0.25 * (1 - k)); }
  if (!sc.hook) drawSubs();
}
