/* =========================================================
   STIMMUNG: Zimmer (Tag)
   ========================================================= */
function sky(stops){
  const c = document.createElement('canvas'); c.width = 4; c.height = 256; const x = c.getContext('2d'), g = x.createLinearGradient(0, 0, 0, 256);
  stops.forEach(s => g.addColorStop(s[0], s[1])); x.fillStyle = g; x.fillRect(0, 0, 4, 256); const t = new THREE.CanvasTexture(c); t.encoding = THREE.sRGBEncoding; return t;
}
const MOOD = { room: { sky: sky([[0, '#e8dcc8'], [1, '#e8dcc8']]), fog: [0xe8dcc8, 60, 200], hemi: [0xfff6ea, 0x8a7458, 0.95], sun: [0xfff0dc, 0.9], env: 1 } };
const SR = 8; { const c = sun.shadow.camera; c.left = -SR; c.right = SR; c.top = SR; c.bottom = -SR; c.near = 1; c.far = 60; c.updateProjectionMatrix(); }
sun.target.position.set(0, 1.5, -1); sun.position.set(-6, 14, 12);
function setMood(m){
  scene.background = m.sky; scene.fog.color.set(m.fog[0]); scene.fog.near = m.fog[1]; scene.fog.far = m.fog[2]; scene.environment = m.env ? envDay : envNight;
  hemi.color.set(m.hemi[0]); hemi.groundColor.set(m.hemi[1]); hemi.intensity = m.hemi[2]; sun.color.set(m.sun[0]); sun.intensity = m.sun[1];
  fill.color.set(0xffffff); fill.intensity = 0.35; fill.position.set(10, 8, 20);
}

/* =========================================================
   SET: Zimmer mit Tisch (Kaugummi-Packung), Fenster, WC-Tür
   ========================================================= */
const room = new THREE.Group(); scene.add(room);
const PACK = new THREE.Vector3(1.45, 1.74, -0.25);
let door = null, stick = null;
(function(){
  const fl = new THREE.Mesh(new THREE.PlaneGeometry(40, 30), new THREE.MeshStandardMaterial({ color: 0xb98a5a, roughness: 0.85 })); fl.rotation.x = -PI / 2; fl.receiveShadow = true; room.add(fl);
  const wm = new THREE.MeshStandardMaterial({ color: 0xece2d0, roughness: 0.95 });
  const bw = new THREE.Mesh(new THREE.PlaneGeometry(40, 14), wm); bw.position.set(0, 7, -3.2); bw.receiveShadow = true; room.add(bw);
  P(room, rbox(40, 0.3, 0.12, 0.03, 1), mat(0xffffff), 0, 0.15, -3.12);
  // Fenster
  const win = new THREE.Mesh(new THREE.PlaneGeometry(2.0, 1.8), new THREE.MeshBasicMaterial({ color: 0xbfe0fa })); win.position.set(2.4, 3.6, -3.18); room.add(win);
  [[0, 0.95, 2.2, 0.16], [0, -0.95, 2.2, 0.16], [1.05, 0, 0.16, 2.06], [-1.05, 0, 0.16, 2.06], [0, 0, 0.08, 1.8]].forEach(([x, y, w, h]) => P(room, rbox(w, h, 0.1, 0.03, 1), mat(0xffffff), 2.4 + x, 3.6 + y, -3.12));
  // Tisch + Packung
  const wood = mat(0x8a5a36, { roughness: 0.6 });
  P(room, rbox(1.8, 0.12, 1.1, 0.04, 1), wood, 1.95, 1.6, -0.2); [[-0.8, -0.45], [0.8, -0.45], [-0.8, 0.45], [0.8, 0.45]].forEach(([x, z]) => P(room, rbox(0.1, 1.55, 0.1, 0.03, 1), wood, 1.95 + x, 0.78, -0.2 + z));
  P(room, rbox(0.52, 0.12, 0.3, 0.03, 1), mat(0xff5fa8, { roughness: 0.4 }), PACK.x, PACK.y - 0.06, PACK.z);
  P(room, rbox(0.4, 0.02, 0.18, 0.01, 1), mat(0xffffff), PACK.x, PACK.y + 0.005, PACK.z);
  // Pflanze
  P(room, new THREE.CylinderGeometry(0.35, 0.28, 0.7, 14), mat(0xc8694a), -1.4, 0.35, -2.5); P(room, new THREE.SphereGeometry(0.75, 14, 10), mat(0x4f9a46, { roughness: 0.9 }), -1.4, 1.35, -2.5);
  // WC-Tür
  [[-3.65, 2.35, 0.16, 4.7], [-2.15, 2.35, 0.16, 4.7], [-2.9, 4.62, 1.66, 0.16]].forEach(([x, y, w, h]) => P(room, rbox(w, h, 0.22, 0.03, 1), mat(0xffffff), x, y, -3.1));
  const dark = new THREE.Mesh(new THREE.PlaneGeometry(1.4, 4.5), new THREE.MeshBasicMaterial({ color: 0x3a3a44 })); dark.position.set(-2.9, 2.25, -3.17); room.add(dark);
  door = new THREE.Group(); door.position.set(-3.6, 0, -3.05); room.add(door); P(door, rbox(1.4, 4.45, 0.1, 0.03, 1), mat(0xf4efe6, { roughness: 0.7 }), 0.7, 2.25, 0);
  const sc = document.createElement('canvas'); sc.width = 128; sc.height = 64; const x = sc.getContext('2d'); x.fillStyle = '#2a5ab8'; x.fillRect(0, 0, 128, 64); x.fillStyle = '#ffffff'; x.font = '900 44px Arial'; x.textAlign = 'center'; x.textBaseline = 'middle'; x.fillText('WC', 64, 34);
  const st = new THREE.CanvasTexture(sc); st.encoding = THREE.sRGBEncoding; const sg = new THREE.Mesh(new THREE.PlaneGeometry(0.6, 0.3), new THREE.MeshBasicMaterial({ map: st })); sg.position.set(0.7, 3.4, 0.06); door.add(sg);
  stick = P(room, rbox(0.3, 0.05, 0.12, 0.02, 1), mat(0xff5fa8, { roughness: 0.4 }), 0, 0, 0);
})();
const SETS = [room];

/* =========================================================
   FIGUREN
   ========================================================= */
const SCAR = new THREE.Group(); ben.head.add(SCAR);
(function(){ const m = mat(0xa8463f, { roughness: 0.7 }); const s = new THREE.Mesh(rbox(0.075, 0.72, 0.03, 0.012, 1), m); s.position.set(0.25, 0.55, 0.522); s.rotation.z = -0.13; SCAR.add(s);
  for (const y of [0.36, 0.55, 0.74]){ const c = new THREE.Mesh(rbox(0.16, 0.035, 0.03, 0.01, 1), m); c.position.set(0.25 + (y - 0.55) * 0.13, y, 0.528); c.rotation.z = -0.13; SCAR.add(c); } })();
const BUB = new THREE.Mesh(new THREE.SphereGeometry(1, 28, 18), new THREE.MeshStandardMaterial({ color: 0xff7fc0, roughness: 0.25, envMapIntensity: 0.8 })); ben.head.add(BUB);
ben.L1 = 0.46; ben.L2 = 0.56;
const _ia = new THREE.Vector3(), _ib = new THREE.Vector3(), _ic = new THREE.Vector3(), _id = new THREE.Vector3(), _ie = new THREE.Vector3(), _if = new THREE.Vector3(), _ig = new THREE.Vector3(), _ih = new THREE.Vector3();
const _iq = new THREE.Quaternion(), _qa = new THREE.Quaternion(), _qb = new THREE.Quaternion(), _dn = new THREE.Vector3(0, -1, 0);
function ik(r, i, tw, pw){
  r.torso.updateWorldMatrix(true, false);
  const tl = r.torso.worldToLocal(_ia.copy(tw)); r.torso.getWorldQuaternion(_iq); const pl = _ib.copy(pw).applyQuaternion(_iq.invert());
  const S = _ic.set(i ? 0.67 : -0.67, 0.92, 0), D = _id.subVectors(tl, S), L1 = r.L1, L2 = r.L2;
  const d = Math.min(Math.max(D.length(), 0.15), L1 + L2 - 0.002); D.normalize();
  const a = Math.acos(Math.max(-1, Math.min(1, (L1 * L1 + d * d - L2 * L2) / (2 * L1 * d))));
  const n = _ie.crossVectors(D, pl).normalize(), e = _if.copy(D).applyAxisAngle(n, a);
  _qa.setFromUnitVectors(_dn, e); r.sh[i].quaternion.copy(_qa);
  const f = _ih.subVectors(tl, _ig.copy(S).addScaledVector(e, L1)).normalize().applyQuaternion(_qb.copy(_qa).invert());
  r.el[i].quaternion.setFromUnitVectors(_dn, f);
}
const POLE = new THREE.Vector3(0.6, -1, 0.3), MOUTH = new THREE.Vector3(0.05, 2.33, 0.62), REST = new THREE.Vector3(0.74, 0.93, 0.05);
function bubble(s){ BUB.visible = s > 0.01; BUB.scale.setScalar(Math.max(0.01, s)); BUB.position.set(0.02, 0.2, 0.55 + s * 0.92); }
function chew(t){ bFace(ben, 0.2, 0.12 + 0.12 * Math.sin(t * 9)); }

/* =========================================================
   KAMERA + Zustand
   ========================================================= */
const cL = new THREE.Vector3();
let blurAmt = 0, fadeBlk = 0, T = 0, flashA = 0, eyeS = 1, talk = 0, dT = 0;
let xrK = 0, clockK = 0, lumpK = 0;
function camW(p, a, b){ cam.position.set(lerp(a[0], b[0], p), lerp(a[1], b[1], p), lerp(a[2], b[2], p)); cL.set(lerp(a[3], b[3], p), lerp(a[4], b[4], p), lerp(a[5], b[5], p)); cam.fov = lerp(a[6], b[6], p); }
function camFin(sh){ cam.position.x += Math.sin(dT * 0.7) * 0.012; cam.position.y += Math.sin(dT * 0.9 + 1) * 0.008; if (sh){ cam.position.x += Math.sin(T * 23) * sh; cam.position.y += Math.cos(T * 17) * sh; } cam.up.set(0, 1, 0); cam.lookAt(cL); cam.updateProjectionMatrix(); cam.updateMatrixWorld(); }
const imp = at => T >= at ? Math.exp(-(T - at) * 3) : 0;
const HOOK = [[0.5, 3.05, 7.8, 0.1, 2.8, 0, 34], [0.4, 3.0, 7.0, 0.1, 2.85, 0, 33]];
const MID = [0.4, 2.6, 12.0, 0.3, 2.2, 0, 40];
function base(){ show(ben); bubble(0); stick.visible = false; door.rotation.y = 0; }
function stand(){ bRest(ben, T, 0); place(ben, 0, 0, 0, 0); }
function hookPose(t){ base(); stand(); chew(t); eyeS = 1; }

/* =========================================================
   SZENEN (gekürzte Sprecherspur, Tempo 1,2)
   ========================================================= */
const SCN = [
  { t: 0, set: room, mood: MOOD.room, hook: 1,
    upd(lt){ dT = T; base(); stand(); const POP = 1.55, G = 2.0;
      if (T < POP){ const q = seg(T, 0.15, 0.45); bubble(0.4 * E.out(seg(T, 0.25, POP))); bFace(ben, lerp(0.2, 0.1, q), lerp(0.12 + 0.12 * Math.sin(T * 9), 0.25, q)); eyeS = 1 + 0.3 * seg(T, 0.8, 1.5); }
      else { const g = bump(T, G - 0.05, G + 0.4); eyeS = 1.5 - 0.6 * g; bFace(ben, -0.9, 0.25 + 0.3 * (1 - g)); ben.head.rotation.x = 0.28 * g; ben.head.position.y += 0.03 * imp(POP);
        const k = E.io(seg(T, 1.75, 2.0)) * (1 - E.io(seg(T, 2.35, 2.65))); if (k > 0) ik(ben, 1, _ih.copy(REST).lerp(new THREE.Vector3(0.1, 2.05, 0.45), k), POLE); }
      camW(E.io(seg(lt, 0, 2.65)), HOOK[0], HOOK[1]); camFin(0.025 * imp(POP)); } },
  { t: 2.65, set: room, mood: MOOD.room, hud: () => ['7 JAHRE?', 'DER BERÜHMTE MYTHOS'],
    upd(lt){ dT = T; base(); stand(); eyeS = 1.3; bFace(ben, -0.5, 0.2); xrK = E.out(seg(T, 2.65, 2.85));
      camW(E.io(seg(lt, 0, 1.9)), HOOK[1], MID); camFin(); } },
  { t: 4.5, set: room, mood: MOOD.room, hud: () => ['ZUCKER + AROMA', 'SOFORT AUFGELÖST'],
    upd(lt){ dT = T; base(); stand(); bFace(ben, 0.2, 0.05); xrK = 1; camW(0, MID, MID); camFin(); } },
  { t: 6.85, set: room, mood: MOOD.room, hud: () => ['KAUMASSE', 'UNVERDAULICH'],
    upd(lt){ dT = T; base(); stand(); bFace(ben, -0.2, 0.1); xrK = 1; camW(0, MID, MID); camFin(); } },
  { t: 9.35, set: room, mood: MOOD.room, hud: () => ['MAGEN KNETET', 'SCHIEBT ALLES WEITER'],
    upd(lt){ dT = T; base(); stand(); bFace(ben, 0.1, 0.05); xrK = 1; camW(0, MID, MID); camFin(); } },
  { t: 12.85, set: room, mood: MOOD.room, hud: () => T < 15.05 ? ['1–2 TAGE', 'DANN IST ER DRAUSSEN'] : ['GANZ NORMAL', 'ÜBERS KLO'],
    upd(lt){ dT = T; base(); xrK = 1 - E.io(seg(T, 14.95, 15.2)); clockK = E.out(seg(T, 12.95, 13.25)) * (1 - seg(T, 14.85, 15.05));
      if (T < 15.05){ stand(); bFace(ben, 0.1, 0.05); camW(0, MID, MID); }
      else { bRest(ben, T, 0); door.rotation.y = -1.35 * E.out(seg(T, 15.1, 15.5)); const w = E.io(seg(T, 15.3, 16.2));
        place(ben, lerp(-2.9, -1.7, w), 0, lerp(-3.4, -0.9, w), lerp(0, 0.35, w)); if (w > 0 && w < 1) wlk(ben, w * PI * 3, Math.sin(PI * w));
        const up = E.out(seg(T, 16.1, 16.4)); if (up > 0){ ben.sh[0].rotation.set(-2.6 * up, 0, -0.3 * up); ben.sh[1].rotation.set(-2.6 * up, 0, 0.3 * up); }
        bFace(ben, 0.7, 0.2); eyeS = 0.6; camW(E.io(seg(T, 15.05, 16.6)), [0.6, 3.0, 9.8, -2.2, 2.0, -1.6, 40], [0.4, 2.9, 9.2, -2.0, 2.0, -1.4, 40]); }
      camFin(); } },
  { t: 16.6, set: room, mood: MOOD.room, hud: () => ['NUR BEI MASSEN', 'KLUMPEN VERSTOPFT DEN DARM'],
    upd(lt){ dT = T; base(); stand(); bFace(ben, -0.6, 0.2); eyeS = 1.2; xrK = E.out(seg(T, 16.6, 16.85)) * (1 - seg(T, 21.05, 21.25)); lumpK = xrK;
      camW(0, MID, MID); camFin(); } },
  { t: 21.25, set: room, mood: MOOD.room, hud: () => ['UND BEN?', 'DER NÄCHSTE …'],
    upd(lt){ dT = T - END; base(); stand(); const r = E.io(seg(T, 21.35, 21.8)), m = E.io(seg(T, 21.85, 22.3)), b = E.io(seg(T, 22.35, 22.75));
      const hand = new THREE.Vector3().copy(REST).lerp(PACK, r * (1 - m)).lerp(MOUTH, m * (1 - b));
      if (r > 0 && b < 1) ik(ben, 1, hand, POLE);
      stick.visible = T > 21.8 && T < 22.32; stick.position.copy(hand).add(new THREE.Vector3(-0.08, 0.05, 0.08));
      if (T < 22.32) bFace(ben, 0.5, m > 0.5 ? 0.3 : 0.05); else chew(T - END);
      ben.head.rotation.y = 0.35 * r * (1 - m); eyeS = 1;
      camW(E.io(seg(lt, 0, 1.6)), MID, HOOK[0]); camFin(); } },
  { t: 22.85, set: room, mood: MOOD.room, loopin: 1,
    upd(lt){ dT = T - END; hookPose(T - END); camW(0, HOOK[0], HOOK[1]); camFin(); } },
];
const SUBS = __SUBS__;
