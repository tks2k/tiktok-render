/* =========================================================
   STIMMUNG: Skipiste (statischer Himmel)
   ========================================================= */
function sky(){
  const c = document.createElement('canvas'); c.width = 4; c.height = 512; const x = c.getContext('2d'), g = x.createLinearGradient(0, 0, 0, 512);
  g.addColorStop(0, '#2d6fc2'); g.addColorStop(0.55, '#8fc0ec'); g.addColorStop(1, '#e6f2fb'); x.fillStyle = g; x.fillRect(0, 0, 4, 512);
  const t = new THREE.CanvasTexture(c); t.encoding = THREE.sRGBEncoding; return t;
}
const MOOD = { snow: { sky: sky(), fog: [0xdfeaf4, 50, 260], hemi: [0xeaf4ff, 0xb0bccc, 0.95], sun: [0xfff6e6, 1.25], sp: [10, 20, 14] } };
const SR = 14; { const c = sun.shadow.camera; c.left = -SR; c.right = SR; c.top = SR; c.bottom = -SR; c.near = 1; c.far = 90; c.updateProjectionMatrix(); }
function setMood(m){
  scene.background = m.sky; scene.fog.color.set(m.fog[0]); scene.fog.near = m.fog[1]; scene.fog.far = m.fog[2]; scene.environment = envDay;
  hemi.color.set(m.hemi[0]); hemi.groundColor.set(m.hemi[1]); hemi.intensity = m.hemi[2]; sun.color.set(m.sun[0]); sun.intensity = m.sun[1];
  sun.position.set(m.sp[0], m.sp[1], m.sp[2]); sun.target.position.set(0, 0, 0); fill.color.set(0xdfe8ff); fill.intensity = 0.35; fill.position.set(-12, 6, 16);
}

/* =========================================================
   SET: Hang, Bäume, Lawine
   ========================================================= */
const SLOPE = new THREE.Group(); scene.add(SLOPE); const SETS = [SLOPE];
const SNOWM = mat(0xf4f7fb, { roughness: 0.9 });
const GROUND = P(SLOPE, new THREE.PlaneGeometry(500, 500), SNOWM, 0, 0, 0); GROUND.rotation.x = -PI / 2;
const DEEP = P(SLOPE, new THREE.PlaneGeometry(500, 500), mat(0xeef3f9, { roughness: 1 }), 0, -0.01, 0); DEEP.rotation.x = -PI / 2;
(function(){ const tr = mat(0x5a3e28), nd = [mat(0x2f6a46, { roughness: 0.9 }), mat(0x3a7a52, { roughness: 0.9 })];
  [[-9, -6], [-12, 2], [10, -4], [13, 4], [-16, -14], [17, -16], [-20, 6], [21, -2]].forEach(([x, z], i) => { P(SLOPE, new THREE.CylinderGeometry(0.25, 0.3, 1.4, 8), tr, x, 0.7, z);
    P(SLOPE, new THREE.ConeGeometry(1.6, 3.2, 9), nd[i % 2], x, 2.6, z); P(SLOPE, new THREE.ConeGeometry(1.2, 2.4, 9), nd[(i + 1) % 2], x, 4.0, z); });
  const pk = mat(0xf4f7fb, { roughness: 0.85, flatShading: true }), rk = mat(0x7a7680, { roughness: 1, flatShading: true });
  [[-30, 18, -120, 40, 46, pk], [25, 22, -140, 48, 56, pk], [70, 14, -110, 30, 36, rk], [-75, 12, -100, 32, 34, rk]].forEach(([x, y, z, r, h, m]) => { const c = P(SLOPE, new THREE.ConeGeometry(r, h, 8, 1), m, x, y, z); c.castShadow = false; });
})();
const AVAL = new THREE.Group(); SLOPE.add(AVAL); const AB = [];
(function(){ const m = mat(0xc4cfdc, { roughness: 1 }); for (let r = 0; r < 3; r++) for (let i = -6; i <= 6; i++){ const s = 5.0 + 2.4 * hsh(i * 7 + r) + r * 1.2; const b = P(AVAL, new THREE.SphereGeometry(1, 22, 14), m, i * 5.5 + hsh(i + r * 13) * 1.5, s * 0.6, -r * 5 - hsh(i + 3) * 1.5); b.scale.setScalar(s); b.castShadow = false; AB.push([b, s, i + r * 11]); } })();
function aval(z, k, t){ AVAL.visible = k > 0; AVAL.position.set(0, 0, z); AVAL.scale.set(1, Math.max(0.01, k), 1); AB.forEach(([b, s, i]) => b.scale.setScalar(s * (1 + 0.06 * Math.sin(t * 2.2 + i)))); }
const SKIS = []; [0, 1].forEach(i => { const s = P(ben.legs[i], rbox(0.24, 0.08, 2.3, 0.04, 1), mat(0xd8352a, { roughness: 0.4 }), 0, -1.04, 0.25); SKIS.push(s); });
const pro = boxer({ top: 0xd8352a, pants: 0x2a2a34, shoe: 0x1c1c22, hair: 0x5a3a22, skin: 0xf2c6a2 }); ALL.push(pro); scene.add(pro.root);
const BEEP = P(pro.el[1], rbox(0.22, 0.34, 0.1, 0.04, 1), mat(0xf2c21a, { roughness: 0.4 }), 0, -0.72, 0.12);

/* =========================================================
   BEN
   ========================================================= */
const SCAR = new THREE.Group(); ben.head.add(SCAR);
(function(){ const m = mat(0xa8463f, { roughness: 0.7 }); const s = new THREE.Mesh(rbox(0.075, 0.72, 0.03, 0.012, 1), m); s.position.set(0.25, 0.55, 0.522); s.rotation.z = -0.13; SCAR.add(s);
  for (const y of [0.36, 0.55, 0.74]){ const c = new THREE.Mesh(rbox(0.16, 0.035, 0.03, 0.01, 1), m); c.position.set(0.25 + (y - 0.55) * 0.13, y, 0.528); c.rotation.z = -0.13; SCAR.add(c); } })();
function skiPose(r, t){ const s = Math.sin(t * 1.6); r.body.position.y = 0.88; r.legs[0].rotation.set(-0.35, 0, -0.04); r.legs[1].rotation.set(-0.35, 0, 0.04); r.torso.rotation.set(0.35, 0.12 * s, 0); r.head.rotation.x = -0.3;
  r.sh[0].rotation.set(-0.5, 0, -0.35); r.sh[1].rotation.set(-0.5, 0, 0.35); r.el[0].rotation.x = -0.7; r.el[1].rotation.x = -0.7; }
function swim(r, t, k){ const a = t * 6; r.sh[0].rotation.set(-1.6 - 1.4 * Math.sin(a) * k, 0, -0.3); r.sh[1].rotation.set(-1.6 - 1.4 * Math.sin(a + PI) * k, 0, 0.3); r.el[0].rotation.x = -0.2; r.el[1].rotation.x = -0.2; r.torso.rotation.x = 0.15; }

/* =========================================================
   KAMERA + Zustand
   ========================================================= */
const cL = new THREE.Vector3();
let blurAmt = 0, fadeBlk = 0, T = 0, flashA = 0, eyeS = 1, talk = 0, dT = 0;
let spdK = 0, airK = 0, betK = 0, surK = 0, beepK = 0, snowY = 0;
function camW(p, a, b){ cam.position.set(lerp(a[0], b[0], p), lerp(a[1], b[1], p), lerp(a[2], b[2], p)); cL.set(lerp(a[3], b[3], p), lerp(a[4], b[4], p), lerp(a[5], b[5], p)); cam.fov = lerp(a[6], b[6], p); }
function camFin(sh){ cam.position.x += Math.sin(dT * 0.7) * 0.02; cam.position.y += Math.sin(dT * 0.9 + 1) * 0.015; if (sh){ cam.position.x += Math.sin(T * 23) * sh; cam.position.y += Math.cos(T * 17) * sh; } cam.up.set(0, 1, 0); cam.lookAt(cL); cam.updateProjectionMatrix(); cam.updateMatrixWorld(); }
const HOOK = [[3.4, 4.6, 13.5, 0.2, 3.0, -4, 40], [3.0, 4.3, 12.4, 0.2, 2.9, -4, 40]];
function snow(y){ snowY = y; GROUND.position.y = y; }
function base(){ show(ben); pro.root.visible = false; snow(0); AVAL.visible = false; SKIS.forEach(s => s.visible = true); }
// Lawinenfront (z): kommt von hinten, erreicht Ben bei T=6.6
function avZ(t){ return -45 + 6.8 * t; }
function hookBen(t){ bRest(ben, t, 0); place(ben, 0.4 * Math.sin(t * 0.8), 0, 0, 0.15 * Math.sin(t * 0.8)); skiPose(ben, t); eyeS = 1; bFace(ben, 0.3, 0.05); }

/* =========================================================
   SZENEN (Sprecherspur Tempo 1,05)
   ========================================================= */
const SCN = [
  { t: 0, set: SLOPE, mood: MOOD.snow, hook: 1,
    upd(lt){ dT = T; base(); hookBen(T); aval(avZ(T), 1, T); camW(E.io(seg(lt, 0, 2.95)), HOOK[0], HOOK[1]); camFin(); } },
  { t: 2.95, set: SLOPE, mood: MOOD.snow, hud: () => ['ÜBER 100 KM/H', 'SCHNELLER ALS BEN'],
    upd(lt){ dT = T; base(); hookBen(T); ben.head.rotation.y = -0.9 * E.io(seg(T, 3.2, 3.8)) * (1 - seg(T, 4.6, 5.0)); eyeS = 1.35; bFace(ben, -0.8, 0.45); aval(avZ(T), 1, T);
      spdK = E.out(seg(T, 3.3, 3.6)) * (1 - seg(T, 6.6, 6.86)); camW(E.io(seg(lt, 0, 3.91)), HOOK[1], [-5.5, 4.0, 13, 0.5, 3.0, -12, 40]); camFin(0.05 * seg(T, 5.6, 6.86)); } },
  { t: 6.86, set: SLOPE, mood: MOOD.snow, hud: () => ['SCHWIMMEN!', 'OBEN BLEIBEN'],
    upd(lt){ dT = T; base(); snow(1.0 + 0.1 * Math.sin(T * 5)); bRest(ben, T, 0); place(ben, 0, 0.1 * Math.sin(T * 4), 0, 0.2 * Math.sin(T * 1.5)); swim(ben, T, 1); ben.root.rotation.z = 0.12 * Math.sin(T * 3);
      eyeS = 1.3; bFace(ben, -0.7, 0.4); camW(E.io(seg(lt, 0, 2.89)), [3.6, 3.8, 11.5, 0, 1.9, 0, 40], [3.2, 3.6, 10.4, 0, 2.0, 0, 40]); camFin(0.03); } },
  { t: 9.75, set: SLOPE, mood: MOOD.snow, hud: () => ['HAND VORS GESICHT', 'FÜR EINE ATEMHÖHLE'],
    upd(lt){ dT = T; base(); const s = E.io(seg(T, 9.8, 12.4)); snow(lerp(1.0, 2.45, s)); bRest(ben, T, 0); place(ben, 0, 0, 0, 0.1); swim(ben, T, 1 - E.io(seg(T, 10.6, 11.6)));
      const h = E.io(seg(T, 11.0, 11.8)); ben.sh[1].rotation.set(lerp(ben.sh[1].rotation.x, -1.9, h), 0, lerp(0.3, -0.55, h)); ben.el[1].rotation.x = lerp(-0.2, -1.5, h);
      eyeS = 1.2; bFace(ben, -0.5, 0.25); airK = E.out(seg(T, 12.0, 12.3)) * (1 - seg(T, 13.1, 13.28));
      camW(E.io(seg(lt, 0, 3.53)), [3.2, 3.6, 10.4, 0, 2.0, 0, 40], [2.0, 3.6, 7.4, 0, 2.8, 0, 40]); camFin(); } },
  { t: 13.28, set: SLOPE, mood: MOOD.snow, hud: () => ['HART WIE BETON', 'BEN KANN SICH NICHT BEWEGEN'],
    upd(lt){ dT = T; base(); snow(2.62); bRest(ben, 0, 0); place(ben, 0, 0, 0, 0.1); swim(ben, 0, 0); ben.sh[1].rotation.set(-1.9, 0, -0.55); ben.el[1].rotation.x = -1.5;
      eyeS = 1.1 - 0.15 * Math.sin(T * 4); bFace(ben, -0.6, 0.1); betK = E.out(seg(T, 13.6, 13.9)) * (1 - seg(T, 15.55, 15.75));
      camW(E.io(seg(lt, 0, 2.47)), [2.0, 3.6, 7.4, 0, 2.8, 0, 40], [1.6, 3.9, 6.6, 0, 3.0, 0, 40]); camFin(); } },
  { t: 15.75, set: SLOPE, mood: MOOD.snow, hud: () => T < 19.0 ? ['IN 15 MIN GEFUNDEN?', 'DANN ÜBERLEBT MAN MEISTENS'] : ['LAWINENPIEPSER', 'SENDET BENS POSITION'],
    upd(lt){ dT = T; base(); snow(2.62); bRest(ben, 0, 0); place(ben, 0, 0, 0, 0.1); swim(ben, 0, 0); ben.sh[1].rotation.set(-1.9, 0, -0.55); ben.el[1].rotation.x = -1.5; eyeS = 1.0; bFace(ben, -0.2, 0.1);
      pro.root.visible = true; bRest(pro, T, 2); const w = seg(T, 16.0, 19.6), px = lerp(-12, -1.8, w); place(pro, px, snowY, 1.2, PI / 2 - 0.2); if (w < 1) wlk(pro, T * 9, 1); pro.sh[1].rotation.set(-1.2, 0, 0.1); pro.el[1].rotation.x = -0.6; bFace(pro, 0.3, 0.1);
      surK = E.out(seg(T, 16.0, 16.3)) * (1 - seg(T, 18.8, 19.0)); beepK = E.out(seg(T, 19.0, 19.3)) * (1 - seg(T, 20.45, 20.65));
      camW(E.io(seg(lt, 0, 4.9)), [3.8, 6.4, 15.5, -2.5, 2.6, 0, 40], [3.2, 6.0, 14.0, -1.5, 2.6, 0, 40]); camFin(); } },
  { t: 20.65, set: SLOPE, mood: MOOD.snow, hud: () => ['UND BEN?', 'NÄCHSTE ABFAHRT …'],
    upd(lt){ dT = T - END; base(); hookBen(T - END); aval(avZ(T - END), 1, T - END); camW(E.io(seg(T, 20.65, 22.9)), [5.0, 5.4, 15.5, 0.2, 2.6, -4, 40], HOOK[0]); camFin(); } },
  { t: 23.1, set: SLOPE, mood: MOOD.snow, loopin: 1,
    upd(lt){ dT = T - END; base(); hookBen(T - END); aval(avZ(T - END), 1, T - END); camW(0, HOOK[0], HOOK[1]); camFin(); } },
];
const SUBS = __SUBS__;
