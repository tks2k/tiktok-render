/* =========================================================
   STIMMUNG: Stadtmarathon, Vormittag
   ========================================================= */
function sky(stops){
  const c = document.createElement('canvas'); c.width = 4; c.height = 256; const x = c.getContext('2d'), g = x.createLinearGradient(0, 0, 0, 256);
  stops.forEach(s => g.addColorStop(s[0], s[1])); x.fillStyle = g; x.fillRect(0, 0, 4, 256); const t = new THREE.CanvasTexture(c); t.encoding = THREE.sRGBEncoding; return t;
}
const MOOD = { day: { sky: sky([[0, '#3d8fe0'], [0.6, '#8cc4f2'], [1, '#dcefff']]), fog: [0xcfe6f7, 60, 260], hemi: [0xe8f3ff, 0x8a8070, 0.85], sun: [0xfff2dc, 1.3] } };
const SR = 18; { const c = sun.shadow.camera; c.left = -SR; c.right = SR; c.top = SR; c.bottom = -SR; c.near = 1; c.far = 120; c.updateProjectionMatrix(); }
function setMood(m){
  scene.background = m.sky; scene.fog.color.set(m.fog[0]); scene.fog.near = m.fog[1]; scene.fog.far = m.fog[2]; scene.environment = envDay;
  hemi.color.set(m.hemi[0]); hemi.groundColor.set(m.hemi[1]); hemi.intensity = m.hemi[2]; sun.color.set(m.sun[0]); sun.intensity = m.sun[1];
  sun.position.set(-20, 40, 25); fill.color.set(0xffffff); fill.intensity = 0.3; fill.position.set(20, 10, 40);
}

/* =========================================================
   SET: Laufstrecke entlang x (Bahn z -3 … 3), Absperrgitter, Häuser, Zielbogen bei x = ZX
   ========================================================= */
const CITY = new THREE.Group(); scene.add(CITY); const SETS = [CITY];
const ZX = 60;
function sign(text, col){ const c = document.createElement('canvas'); c.width = 256; c.height = 128; const x = c.getContext('2d'); x.fillStyle = col; x.fillRect(0, 0, 256, 128); x.fillStyle = '#ffffff'; x.font = '900 64px sans-serif'; x.textAlign = 'center'; x.textBaseline = 'middle'; x.fillText(text, 128, 68); const t = new THREE.CanvasTexture(c); t.encoding = THREE.sRGBEncoding; return new THREE.MeshBasicMaterial({ map: t }); }
(function(){
  const as = mat(0x4a4a50, { roughness: 0.9 }), sw = mat(0xb8b4aa, { roughness: 0.95 }), bl = mat(0x2a6ad8), wh = mat(0xf2f2f2);
  const r = new THREE.Mesh(new THREE.PlaneGeometry(400, 8), as); r.rotation.x = -PI / 2; r.receiveShadow = true; CITY.add(r);
  [-1, 1].forEach(s => { const w = new THREE.Mesh(new THREE.PlaneGeometry(400, 10), sw); w.rotation.x = -PI / 2; w.position.set(0, 0.01, s * 9); w.receiveShadow = true; CITY.add(w); });
  P(CITY, new THREE.BoxGeometry(400, 0.02, 0.25), wh, 0, 0.02, 0);
  // Absperrgitter (blau) beidseitig
  for (let i = -40; i <= 40; i++) [-1, 1].forEach(s => { P(CITY, new THREE.BoxGeometry(2.3, 1.0, 0.1), bl, i * 2.5, 0.6, s * 4.2); });
  // Häuser
  const cols = [0xe8d8c0, 0xd8a890, 0xc8d8e0, 0xe0c8a0, 0xb8c8a8];
  for (let i = -16; i <= 16; i++) [-1, 1].forEach(s => { const h = 8 + hsh(i * 3 + s) * 10; const m = mat(cols[(i + 20 + s) % 5], { roughness: 0.9 });
    P(CITY, new THREE.BoxGeometry(9.5, h, 8), m, i * 10, h / 2, s * 19); const wn = mat(0x7aa8c8, { roughness: 0.2 }); for (let f = 1; f < h / 3; f++) P(CITY, new THREE.BoxGeometry(7, 1.2, 0.1), wn, i * 10, f * 3, s * 19 - s * 4.05); });
  // Zielbogen
  const ar = mat(0xd83a2a, { roughness: 0.5 }); P(CITY, new THREE.BoxGeometry(0.8, 7, 0.8), ar, ZX, 3.5, -4.6); P(CITY, new THREE.BoxGeometry(0.8, 7, 0.8), ar, ZX, 3.5, 4.6);
  const bn = new THREE.Mesh(new THREE.BoxGeometry(0.6, 1.8, 10), ar); bn.position.set(ZX, 7.4, 0); CITY.add(bn);
  const zt = new THREE.Mesh(new THREE.PlaneGeometry(7, 1.6), sign('ZIEL', '#d83a2a')); zt.position.set(ZX - 0.32, 7.4, 0); zt.rotation.y = -PI / 2; CITY.add(zt);
  P(CITY, new THREE.BoxGeometry(0.4, 0.03, 8), wh, ZX, 0.03, 0);
})();
// Kilometerschilder
const KMS = {}; [5, 30, 42].forEach((k, i) => { const g = new THREE.Group(); P(g, new THREE.CylinderGeometry(0.08, 0.08, 3, 8), mat(0x888888), 0, 1.5, 0); const s = new THREE.Mesh(new THREE.PlaneGeometry(2, 1), sign('KM ' + k, k === 30 ? '#e8402a' : '#2a6ad8')); s.position.set(0, 3.2, 0.06); g.add(s); g.position.set(0, 0, -3.8); CITY.add(g); KMS[k] = g; });
// Zuschauer hinter dem Gitter
const FANS = []; (function(){ const cs = [0xe0483c, 0x2f7fd8, 0x3cae6a, 0xf2c21a, 0x8a4ad8]; for (let i = 0; i < 46; i++){ const s = i % 2 ? 1 : -1, g = new THREE.Group(); P(g, rbox(0.8, 1.4, 0.5, 0.1), mat(cs[i % 5]), 0, 1.2, 0); P(g, rbox(0.6, 0.6, 0.6, 0.1), mat(0xf0c8a0), 0, 2.2, 0);
  const a = P(g, rbox(0.2, 0.9, 0.2, 0.05), mat(cs[i % 5]), 0.5, 2.1, 0); g.userData.a = a; g.position.set(-55 + i * 2.6 + hsh(i) * 1.2, 0, s * (5.2 + hsh(i + 3) * 1.2)); g.rotation.y = s > 0 ? PI : 0; CITY.add(g); FANS.push(g); } })();
function fans(t){ FANS.forEach((f, i) => { f.userData.a.rotation.z = 0.4 + 0.5 * Math.sin(t * 9 + i * 1.7); f.position.y = 0.12 * Math.max(0, Math.sin(t * 7 + i)); }); }
// Uhr am Zielbogen
const CLK = (function(){ const c = document.createElement('canvas'); c.width = 512; c.height = 160; const t = new THREE.CanvasTexture(c); const m = new THREE.Mesh(new THREE.PlaneGeometry(4, 1.25), new THREE.MeshBasicMaterial({ map: t })); m.position.set(ZX - 0.35, 5.3, 0); m.rotation.y = -PI / 2; CITY.add(m); return { c, t, last: '' }; })();
function clock(s){ const h = Math.floor(s / 3600), mi = Math.floor(s / 60) % 60, se = Math.floor(s) % 60, txt = h + ':' + String(mi).padStart(2, '0') + ':' + String(se).padStart(2, '0'); if (txt === CLK.last) return; CLK.last = txt;
  const x = CLK.c.getContext('2d'); x.fillStyle = '#101418'; x.fillRect(0, 0, 512, 160); x.fillStyle = '#ffd23f'; x.font = '900 110px monospace'; x.textAlign = 'center'; x.textBaseline = 'middle'; x.fillText(txt, 256, 86); CLK.t.needsUpdate = true; }
// Hammer (Bild für den „Mann mit dem Hammer“)
const HAM = new THREE.Group(); CITY.add(HAM); P(HAM, new THREE.CylinderGeometry(0.15, 0.15, 4, 10), mat(0x8a5a2a), 0, 2, 0); P(HAM, rbox(1.6, 1.0, 1.0, 0.15), mat(0x5a5a64, { metalness: 0.6, roughness: 0.3 }), 0, 4.2, 0);

/* =========================================================
   FIGUREN: Ben (Startnummer), Weltrekordläufer
   ========================================================= */
const SCAR = new THREE.Group(); ben.head.add(SCAR);
(function(){ const m = mat(0xa8463f, { roughness: 0.7 }); const s = new THREE.Mesh(rbox(0.075, 0.72, 0.03, 0.012, 1), m); s.position.set(0.25, 0.55, 0.522); s.rotation.z = -0.13; SCAR.add(s);
  for (const y of [0.36, 0.55, 0.74]){ const c = new THREE.Mesh(rbox(0.16, 0.035, 0.03, 0.01, 1), m); c.position.set(0.25 + (y - 0.55) * 0.13, y, 0.528); c.rotation.z = -0.13; SCAR.add(c); } })();
const BIB = new THREE.Mesh(new THREE.PlaneGeometry(0.62, 0.44), sign('4711', '#f2f2f2')); BIB.material.map.image.getContext('2d'); BIB.position.set(0, 0.62, 0.3); ben.torso.add(BIB);
(function(){ const c = BIB.material.map.image, x = c.getContext('2d'); x.fillStyle = '#ffffff'; x.fillRect(0, 0, 256, 128); x.fillStyle = '#101418'; x.font = '900 70px sans-serif'; x.textAlign = 'center'; x.textBaseline = 'middle'; x.fillText('4711', 128, 68); BIB.material.map.needsUpdate = true; })();
const MED = new THREE.Group(); ben.torso.add(MED); P(MED, new THREE.CylinderGeometry(0.2, 0.2, 0.05, 18), mat(0xe8b83a, { metalness: 0.8, roughness: 0.25 }), 0, 0.55, 0.33).rotation.x = PI / 2; P(MED, new THREE.BoxGeometry(0.08, 0.5, 0.02), mat(0xd83a2a), -0.15, 0.85, 0.31).rotation.z = 0.3; P(MED, new THREE.BoxGeometry(0.08, 0.5, 0.02), mat(0xd83a2a), 0.15, 0.85, 0.31).rotation.z = -0.3;
const pro = boxer({ top: 0x2f9a4a, pants: 0x1a1a1a, shoe: 0xf2f2f2, hair: 0x1a1a1a, skin: 0x7a4a2a }); ALL.push(pro); scene.add(pro.root);
// Laufen: Phase ph, Stärke a
function run(r, ph, a){ const s = Math.sin(ph); r.legs[0].rotation.x = s * 0.95 * a; r.legs[1].rotation.x = -s * 0.95 * a; r.sh[0].rotation.x = -s * 0.9 * a; r.sh[1].rotation.x = s * 0.9 * a; r.el[0].rotation.x = -1.4; r.el[1].rotation.x = -1.4;
  r.body.position.y = 1 + (Math.abs(Math.cos(ph)) * 0.16 - 0.05) * a; r.torso.rotation.x = 0.18; }

/* =========================================================
   KAMERA + Zustand
   ========================================================= */
const cL = new THREE.Vector3();
let blurAmt = 0, fadeBlk = 0, T = 0, flashA = 0, eyeS = 1, talk = 0, dT = 0;
let kmK = 0, kmV = 0, kcalV = 0, enK = 0, enV = 1, recK = 0, finK = 0;
function camW(p, a, b){ cam.position.set(lerp(a[0], b[0], p), lerp(a[1], b[1], p), lerp(a[2], b[2], p)); cL.set(lerp(a[3], b[3], p), lerp(a[4], b[4], p), lerp(a[5], b[5], p)); cam.fov = lerp(a[6], b[6], p); }
function camFin(sh){ cam.position.x += Math.sin(dT * 0.7) * 0.03; cam.position.y += Math.sin(dT * 0.9 + 1) * 0.02; if (sh){ cam.position.x += Math.sin(T * 23) * sh; cam.position.y += Math.cos(T * 17) * sh; } cam.up.set(0, 1, 0); cam.lookAt(cL); cam.updateProjectionMatrix(); cam.updateMatrixWorld(); }
// Kamera fährt mit Ben mit (relativ zu bx)
function camRel(p, bx, a, b){ camW(p, [a[0] + bx, a[1], a[2], a[3] + bx, a[4], a[5], a[6]], [b[0] + bx, b[1], b[2], b[3] + bx, b[4], b[5], b[6]]); }
const HOOK = [[3.2, 2.4, 7.4, 0.6, 2.0, 0, 50], [3.0, 2.3, 7.0, 0.6, 2.0, 0, 50]];
function base(){ show(ben); MED.visible = false; HAM.visible = false; KMS[5].visible = KMS[30].visible = KMS[42].visible = false; fans(T); clock(0); }
// Hook: Ben läuft los (x = vt), lächelt
function hookBen(t){ const x = -50 + 3.0 * t; bRest(ben, t, 0); place(ben, x, 0, 1.2, PI / 2); run(ben, t * 9, 1); eyeS = 1.1; bFace(ben, 0.9, 0.2); return x; }

/* =========================================================
   SZENEN (Sprecherspur Tempo 1,1)
   ========================================================= */
const SCN = [
  { t: 0, set: CITY, mood: MOOD.day, hook: 1,
    upd(lt){ dT = T; base(); const x = hookBen(T); camRel(E.io(seg(lt, 0, 3.58)), x, HOOK[0], [2.4, 2.0, 6.4, 0.8, 1.9, 0, 50]); camFin(); } },
  { t: 3.58, set: CITY, mood: MOOD.day, hud: () => ['42,195 KILOMETER', 'FAST 3000 KALORIEN'],
    upd(lt){ dT = T; base(); KMS[5].visible = true; KMS[5].position.x = -30; const x = -36 + 3.0 * (T - 3.58); bRest(ben, T, 0); place(ben, x, 0, 1.2, PI / 2); run(ben, T * 9, 1); eyeS = 1.0; bFace(ben, 0.5, 0.25);
      kmK = E.out(seg(T, 3.8, 4.1)) * (1 - seg(T, 6.9, 7.05)); kmV = 42.195 * E.out(seg(T, 3.9, 5.0)); kcalV = 3000 * E.out(seg(T, 5.0, 6.4));
      camRel(E.io(seg(lt, 0, 3.47)), x, [-3.0, 2.6, 7.0, 0.6, 2.0, 0, 52], [-2.4, 2.4, 6.4, 0.6, 2.0, 0, 52]); camFin(); } },
  { t: 7.05, set: CITY, mood: MOOD.day, hud: () => T < 10.4 ? ['KILOMETER 30', 'DER MANN MIT DEM HAMMER'] : ['SPEICHER LEER', 'BEINE WIE BLEI'],
    upd(lt){ dT = T; base(); KMS[30].visible = true; KMS[30].position.x = -10; const sl = seg(T, 9.8, 11.2), v = lerp(3.0, 0.9, sl), x = -14 + 3.0 * (T - 7.05) - (T > 9.8 ? (3.0 - v) * 0 : 0);
      const xx = -14 + (T < 9.8 ? 3.0 * (T - 7.05) : 3.0 * 2.75 + (T - 9.8) * lerp(3.0, 0.9, 0.5 * sl));
      bRest(ben, T, 0); place(ben, xx, 0, 1.2, PI / 2); run(ben, T * lerp(9, 5, sl), lerp(1, 0.35, sl)); ben.torso.rotation.x = 0.18 + 0.3 * sl; ben.head.rotation.x = 0.3 * sl; eyeS = lerp(1.0, 0.55, sl); bFace(ben, -0.9 * sl, 0.4 * sl);
      HAM.visible = T > 9.3 && T < 10.6; const hs = seg(T, 9.4, 9.85); HAM.position.set(xx - 1.2, 0, 1.2); HAM.rotation.set(0, 0, 1.6 * (1 - E.io(hs)) - 0.25);
      enK = E.out(seg(T, 7.4, 7.7)) * (1 - seg(T, 13.35, 13.53)); enV = lerp(1, 0.04, E.io(seg(T, 9.6, 11.0)));
      camRel(E.io(seg(lt, 0, 6.48)), xx, [3.0, 2.4, 7.2, 0.4, 2.0, 0, 52], [2.0, 2.2, 6.2, 0.2, 1.9, 0, 50]); camFin(0.02 * bump(T, 9.85, 10.2)); } },
  { t: 13.53, set: CITY, mood: MOOD.day, hud: () => ['WELTREKORD', '1:59:30 · SABASTIAN SAWE'],
    upd(lt){ dT = T; base(); show(ben, pro); const tt = T - 13.53, bx = 10 + 0.9 * tt; bRest(ben, T, 0); place(ben, bx, 0, 1.6, PI / 2); run(ben, T * 5, 0.35); ben.torso.rotation.x = 0.45; eyeS = 0.6; bFace(ben, -0.8, 0.3);
      const px = bx - 14 + 6.0 * tt; bRest(pro, T, 0); place(pro, px, 0, -1.2, PI / 2); run(pro, T * 13, 1.1); pro.torso.rotation.x = 0.12; ben.head.rotation.y = -0.6 * clamp01((px - bx + 2) / 4);
      recK = E.out(seg(T, 13.8, 14.1)) * (1 - seg(T, 20.7, 20.85));
      camW(E.io(seg(lt, 0, 7.32)), [bx - 1.0, 2.6, 8.6, bx + 1.0, 1.9, 0, 54], [bx + 4.8, 2.6, 9.4, bx + 4.0, 1.9, 0, 54]); camFin(); } },
  { t: 20.85, set: CITY, mood: MOOD.day, hud: () => ['UND BEN?', T < 22.75 ? 'GLEICH IM ZIEL …' : 'NACH 5 STUNDEN!'],
    upd(lt){ dT = T; base(); const x = ZX - 6 + 2.6 * Math.min(T - 20.85, 2.6) + 0.6 * Math.max(0, T - 23.45); bRest(ben, T, 0); place(ben, x, 0, 0.6, PI / 2);
      const fin = seg(T, 22.9, 23.3); run(ben, T * 8, 0.8 * (1 - fin)); ben.sh[0].rotation.set(0, 0, -2.6 * fin - 0.07); ben.sh[1].rotation.set(0, 0, 2.6 * fin + 0.07); if (fin > 0){ ben.el[0].rotation.x = -0.2; ben.el[1].rotation.x = -0.2; }
      MED.visible = T > 23.2; eyeS = 1.2; bFace(ben, 1, 0.5); clock(4 * 3600 + 59 * 60 + 45 + (T - 20.85) * 6);
      finK = E.out(seg(T, 21.0, 21.3)) * (1 - seg(T, 23.5, 23.65));
      camW(E.io(seg(lt, 0, 2.8)), [ZX + 5.0, 3.6, 7.2, ZX - 2.0, 3.2, 0, 56], [ZX + 6.0, 3.2, 6.0, ZX - 0.5, 3.0, 0, 56]); camFin(); } },
  { t: 23.65, set: CITY, mood: MOOD.day, loopin: 1,
    upd(lt){ dT = T - END; base(); const x = hookBen(T - END); camRel(0, x, HOOK[0], HOOK[1]); camFin(); } },
];
const SUBS = __SUBS__;
