/* =========================================================
   STIMMUNG: Mars (Butterscotch-Himmel, schwache Sonne)
   ========================================================= */
function sky(stops){
  const c = document.createElement('canvas'); c.width = 4; c.height = 256; const x = c.getContext('2d'), g = x.createLinearGradient(0, 0, 0, 256);
  stops.forEach(s => g.addColorStop(s[0], s[1])); x.fillStyle = g; x.fillRect(0, 0, 4, 256); const t = new THREE.CanvasTexture(c); t.encoding = THREE.sRGBEncoding; return t;
}
const MOOD = { mars: { sky: sky([[0, '#7a4a3a'], [0.5, '#c88a62'], [1, '#e8c29a']]), fog: [0xd8a880, 40, 150], hemi: [0xffe0c8, 0x6a3a28, 0.85], sun: [0xfff0dc, 1.15] } };
const SR = 14; { const c = sun.shadow.camera; c.left = -SR; c.right = SR; c.top = SR; c.bottom = -SR; c.near = 1; c.far = 120; c.updateProjectionMatrix(); }
function setMood(m){
  scene.background = m.sky; scene.fog.color.set(m.fog[0]); scene.fog.near = m.fog[1]; scene.fog.far = m.fog[2]; scene.environment = envDay;
  hemi.color.set(m.hemi[0]); hemi.groundColor.set(m.hemi[1]); hemi.intensity = m.hemi[2]; sun.color.set(m.sun[0]); sun.intensity = m.sun[1];
  sun.position.set(-14, 24, 16); sun.target.position.set(0, 0, 0); fill.color.set(0xffd8c0); fill.intensity = 0.3; fill.position.set(10, 8, 20);
}

/* =========================================================
   SET: roter Sand, Steine, Berge, Lander (1 m = 2 Einheiten)
   ========================================================= */
const MARS = new THREE.Group(); scene.add(MARS); const SETS = [MARS];
(function(){
  const g = new THREE.Mesh(new THREE.PlaneGeometry(300, 300), mat(0xc0643a, { roughness: 1 })); g.rotation.x = -PI / 2; g.receiveShadow = true; MARS.add(g);
  const rk = [mat(0x6a3424, { roughness: 1, flatShading: true }), mat(0x8a4a30, { roughness: 1, flatShading: true })];
  for (let i = 0; i < 70; i++){ const x = (hsh(i) - 0.5) * 50, z = -2 - hsh(i + 9) * 40 + (hsh(i + 3) < 0.25 ? 30 : 0); if (Math.abs(z) < 3 && Math.abs(x) < 8) continue;
    const r = 0.15 + hsh(i + 5) * 0.7; P(MARS, new THREE.DodecahedronGeometry(r, 0), rk[i % 2], x, r * 0.35, z).rotation.set(hsh(i) * 3, hsh(i + 1) * 3, 0); }
  const mm = mat(0x9a5638, { roughness: 1, flatShading: true });
  for (let i = 0; i < 9; i++){ const h = 8 + hsh(i * 4) * 10; P(MARS, new THREE.ConeGeometry(14 + hsh(i) * 10, h, 6), mm, -70 + i * 18, h / 2 - 1, -80 - hsh(i * 2) * 20); }
})();
const LND = new THREE.Group(); MARS.add(LND); const LX = -3.2, LZ = -1.6;
(function(){ const w = mat(0xe8e8ec, { roughness: 0.4, metalness: 0.3 }), d = mat(0x3a3a44, { metalness: 0.5, roughness: 0.4 }), gd = mat(0xd8a830, { metalness: 0.7, roughness: 0.3 });
  P(LND, new THREE.CylinderGeometry(1.3, 1.5, 1.6, 12), gd, 0, 1.6, 0); P(LND, new THREE.CylinderGeometry(0.6, 1.3, 1.2, 12), w, 0, 3.0, 0);
  [0, 1, 2, 3].forEach(k => { const a = k * PI / 2 + PI / 4; rod(LND, d, [Math.cos(a) * 1.2, 1.2, Math.sin(a) * 1.2], [Math.cos(a) * 2.0, 0.08, Math.sin(a) * 2.0], 0.07); P(LND, new THREE.CylinderGeometry(0.28, 0.3, 0.08, 10), d, Math.cos(a) * 2.0, 0.04, Math.sin(a) * 2.0); });
  P(LND, rbox(0.9, 1.2, 0.1, 0.03), d, 0, 1.6, 1.47); })();
const FLM = new THREE.Mesh(new THREE.ConeGeometry(0.6, 2.2, 14, 1, true), new THREE.MeshBasicMaterial({ color: 0xffb050, transparent: true, opacity: 0.7, blending: THREE.AdditiveBlending, depthWrite: false, fog: false })); FLM.rotation.x = PI; FLM.position.y = -0.1; LND.add(FLM);
const ND = 46, DUST = []; { const dm = new THREE.MeshStandardMaterial({ color: 0xd8946a, transparent: true, opacity: 0.6, roughness: 1, depthWrite: false }); for (let i = 0; i < ND; i++){ const d = new THREE.Mesh(new THREE.SphereGeometry(0.25 + hsh(i) * 0.3, 8, 6), dm); MARS.add(d); DUST.push(d); } }
function dust(s, cx, cz){ DUST.forEach((d, i) => { d.visible = s > 0 && s < 2.2; if (!d.visible) return; const a = hsh(i * 2.3) * 6.283, r = 1.5 + s * (2 + hsh(i * 3.1) * 3); d.position.set(cx + Math.cos(a) * r, 0.2 + s * 0.4 * hsh(i * 5.5), cz + Math.sin(a) * r); d.scale.setScalar(0.6 + s * 0.8); d.material.opacity = 0.55 * clamp01(1 - s / 2.2); }); }
// kleiner Staubteufel in der Ferne
const DEV = new THREE.Mesh(new THREE.CylinderGeometry(1.6, 0.4, 9, 14, 1, true), new THREE.MeshStandardMaterial({ color: 0xd8a07a, transparent: true, opacity: 0.32, depthWrite: false, side: THREE.DoubleSide })); DEV.position.set(14, 4.5, -26); MARS.add(DEV);

/* =========================================================
   BEN: Narbe, Raumhelm + Rucksack
   ========================================================= */
const SCAR = new THREE.Group(); ben.head.add(SCAR);
(function(){ const m = mat(0xa8463f, { roughness: 0.7 }); const s = new THREE.Mesh(rbox(0.075, 0.72, 0.03, 0.012, 1), m); s.position.set(0.25, 0.55, 0.522); s.rotation.z = -0.13; SCAR.add(s);
  for (const y of [0.36, 0.55, 0.74]){ const c = new THREE.Mesh(rbox(0.16, 0.035, 0.03, 0.01, 1), m); c.position.set(0.25 + (y - 0.55) * 0.13, y, 0.528); c.rotation.z = -0.13; SCAR.add(c); } })();
const SUIT = new THREE.Group(); const HELM = new THREE.Group(); ben.head.add(HELM); ben.torso.add(SUIT);
(function(){ const gl = new THREE.Mesh(new THREE.SphereGeometry(0.98, 24, 18), new THREE.MeshStandardMaterial({ color: 0xcfeaff, transparent: true, opacity: 0.22, roughness: 0.05, metalness: 0.2, depthWrite: false })); gl.position.y = 0.58; gl.renderOrder = 3; HELM.add(gl);
  const ring = new THREE.Mesh(new THREE.TorusGeometry(0.62, 0.1, 10, 28), mat(0xe8e8ec, { metalness: 0.4, roughness: 0.3 })); ring.rotation.x = PI / 2; ring.position.y = -0.08; HELM.add(ring);
  P(SUIT, rbox(0.9, 0.95, 0.42, 0.08), mat(0xe8e8ec, { roughness: 0.5 }), 0, 0.55, -0.5); P(SUIT, rbox(0.5, 0.18, 0.06, 0.03, 1), mat(0xd04030), 0, 0.85, -0.73);
  rod(SUIT, mat(0x8a8a90), [0.3, 0.95, -0.4], [0.3, 1.25, 0.0], 0.05); })();
function suit(on){ SUIT.visible = on; HELM.visible = on; }
// Sprung unter Mars-Schwerkraft: g = 3,71 m/s² = 7,42 E/s²
const GM = 7.42;
function jumpY(t, t0, h){ const v = Math.sqrt(2 * GM * h), tf = 2 * v / GM, s = t - t0; return (s > 0 && s < tf) ? v * s - GM / 2 * s * s : 0; }
function crouch(k){ ben.legs[0].rotation.x = -0.6 * k; ben.legs[1].rotation.x = -0.6 * k; ben.body.position.y = 1 - 0.18 * k; ben.torso.rotation.x = 0.25 * k; }

/* =========================================================
   KAMERA + Zustand
   ========================================================= */
const cL = new THREE.Vector3();
let blurAmt = 0, fadeBlk = 0, T = 0, flashA = 0, eyeS = 1, talk = 0, dT = 0;
let gravK = 0, coldK = 0, airK = 0, noK = 0, redK = 0, hopK = 0;
function camW(p, a, b){ cam.position.set(lerp(a[0], b[0], p), lerp(a[1], b[1], p), lerp(a[2], b[2], p)); cL.set(lerp(a[3], b[3], p), lerp(a[4], b[4], p), lerp(a[5], b[5], p)); cam.fov = lerp(a[6], b[6], p); }
function camFin(sh){ cam.position.x += Math.sin(dT * 0.7) * 0.03; cam.position.y += Math.sin(dT * 0.9 + 1) * 0.02; if (sh){ cam.position.x += Math.sin(T * 23) * sh; cam.position.y += Math.cos(T * 17) * sh; } cam.up.set(0, 1, 0); cam.lookAt(cL); cam.updateProjectionMatrix(); cam.updateMatrixWorld(); }
const TD = 1.2, TJ = 1.9;   // Aufsetzen, Ben springt aus der Luke
const HOOK = [[1.6, 4.2, 12.5, -2.0, 4.4, -1.4, 48], [1.4, 4.0, 12.2, -2.0, 4.0, -1.4, 48]];
function base(){ show(ben); suit(true); LND.position.set(LX, 0, LZ); FLM.visible = false; DUST.forEach(d => d.visible = false); DEV.rotation.y = T * 2; DEV.position.x = 14 - T * 0.25; }
function hookScene(t){ const ld = E.out(seg(t, -0.4, TD)); LND.position.y = 7 * (1 - ld); FLM.visible = t < TD + 0.15; FLM.scale.set(1, 0.8 + 0.3 * Math.sin(t * 40), 1); if (t > TD) dust((t - TD) * 1.3, LX, LZ);
  bRest(ben, t, 0); const s = t - TJ;
  if (s < 0){ ben.root.visible = t > TJ - 0.5; place(ben, LX, 0.9 + LND.position.y, LZ + 1.0, 0); crouch(seg(t, TJ - 0.5, TJ)); }
  else { const v = 2.2, tf = (v + Math.sqrt(v * v + 2 * GM * 0.9)) / GM, k = Math.min(s, tf), y = Math.max(0, 0.9 + v * k - GM / 2 * k * k);
    place(ben, LX + 1.6 * k, y, LZ + 1.0 + 0.9 * k, 0.5); if (s < tf){ ben.sh[0].rotation.set(-0.3, 0, -1.2); ben.sh[1].rotation.set(-0.3, 0, 1.2); ben.legs[0].rotation.x = -0.4; ben.legs[1].rotation.x = 0.2; } else crouch(0.6 * Math.exp(-(s - tf) * 5)); }
  eyeS = 1.2; bFace(ben, 0.8, 0.25); }
const BX = LX + 2.4, BZ = LZ + 1.75;   // Ben nach der Landung

/* =========================================================
   SZENEN (Sprecherspur Tempo 1,2)
   ========================================================= */
const SCN = [
  { t: 0, set: MARS, mood: MOOD.mars, hook: 1,
    upd(lt){ dT = T; base(); hookScene(T); camW(E.io(seg(lt, 0, 3.28)), HOOK[0], [1.2, 2.6, 10.0, -1.6, 1.6, -0.6, 48]); camFin(0.03 * bump(T, TD, TD + 0.4)); } },
  { t: 3.28, set: MARS, mood: MOOD.mars, hud: () => ['SCHWERKRAFT', 'NUR 38 % VON DER ERDE'],
    upd(lt){ dT = T; base(); bRest(ben, T, 0); const t0 = 6.4, y = jumpY(T, t0, 2.6); place(ben, BX, y, BZ, 0.25);
      if (y > 0){ ben.sh[0].rotation.set(-2.6, 0, -0.3); ben.sh[1].rotation.set(-2.6, 0, 0.3); ben.legs[0].rotation.x = -0.5; ben.legs[1].rotation.x = -0.2; eyeS = 1.4; bFace(ben, 1, 0.5); }
      else { crouch(seg(T, 5.9, 6.4) * (T < t0 ? 1 : 0) + 0.6 * Math.exp(-Math.max(0, T - 8.07) * 5) * (T > 8.07 ? 1 : 0)); eyeS = 1.1; bFace(ben, 0.6, 0.1); }
      gravK = E.out(seg(T, 3.5, 3.8)) * (1 - seg(T, 8.3, 8.5));
      camW(E.io(seg(lt, 0, 5.22)), [BX + 3.4, 2.4, BZ + 8.6, BX, 2.6, BZ, 50], [BX + 2.6, 2.6, BZ + 8.0, BX, 2.9, BZ, 50]); camFin(); } },
  { t: 8.5, set: MARS, mood: MOOD.mars, hud: () => T < 11.6 ? ['EISKALT', 'IM SCHNITT −60 °C'] : ['KAUM LUFT', '100× DÜNNER · FAST NUR CO₂'],
    upd(lt){ dT = T; base(); bRest(ben, T, 0); place(ben, BX, 0, BZ, 0.25 + 0.6 * Math.sin(T * 0.6) * seg(T, 8.6, 9.5)); ben.head.rotation.y = 0.3 * Math.sin(T * 0.9); eyeS = 1.1; bFace(ben, 0, 0.1);
      coldK = E.out(seg(T, 9.9, 10.2)) * (1 - seg(T, 11.45, 11.6)); airK = E.out(seg(T, 11.7, 12.0)) * (1 - seg(T, 16.45, 16.63));
      camW(E.io(seg(lt, 0, 8.13)), [BX - 6.0, 3.0, BZ + 7.0, BX, 1.9, BZ, 48], [BX + 5.0, 3.2, BZ + 7.4, BX, 1.9, BZ, 48]); camFin(); } },
  { t: 16.63, set: MARS, mood: MOOD.mars, hud: () => ['OHNE RAUMANZUG?', 'BEWUSSTLOS NACH ~15 S'],
    upd(lt){ dT = T; base(); suit(false); LND.visible = true; bRest(ben, T, 0); const s = seg(T, 18.2, 20.2); place(ben, BX, 0, BZ, 0.1);
      ben.sh[0].rotation.set(-2.2, 0, 0.5); ben.sh[1].rotation.set(-2.2, 0, -0.5); ben.el[0].rotation.x = -1.4; ben.el[1].rotation.x = -1.4;
      ben.legs[0].rotation.x = -1.2 * s; ben.legs[1].rotation.x = -1.2 * s; ben.body.position.y = 1 - 0.55 * s; ben.torso.rotation.x = 0.25 * s + 0.05 * Math.sin(T * 7) * (1 - s);
      eyeS = lerp(1.5, 0.15, seg(T, 18.6, 20.4)); bFace(ben, -1, 0.6 * (1 - s)); redK = 0.6 * seg(T, 16.7, 17.2) + 0.3 * s; noK = E.out(seg(T, 16.9, 17.2)) * (1 - seg(T, 20.55, 20.75));
      camW(E.io(seg(lt, 0, 4.12)), [BX + 2.2, 2.6, BZ + 6.0, BX, 2.0, BZ, 46], [BX + 1.6, 2.2, BZ + 5.0, BX, 1.6, BZ, 46]); camFin(); } },
  { t: 20.75, set: MARS, mood: MOOD.mars, hud: () => ['UND BEN?', 'HÜPFT IM RAUMANZUG'],
    upd(lt){ dT = T; base(); bRest(ben, T, 0); const per = 1.02, ph = ((T - 20.75) % per + per) % per, y = jumpY(ph, 0.05, 0.8); place(ben, BX - 1.0 + 1.7 * (T - 20.75), y, BZ + 0.4, PI / 2 - 0.25);
      ben.legs[0].rotation.x = y > 0 ? -0.35 : -0.2; ben.legs[1].rotation.x = y > 0 ? -0.15 : -0.2; ben.sh[0].rotation.set(-0.5, 0, -0.9); ben.sh[1].rotation.set(-0.5, 0, 0.9); eyeS = 1.15; bFace(ben, 1, 0.35);
      hopK = E.out(seg(T, 22.2, 22.5)) * (1 - seg(T, 24.25, 24.4));
      camW(E.io(seg(lt, 0, 3.65)), [BX + 0.8, 2.4, BZ + 9.0, BX + 1.2, 1.9, BZ, 48], [BX + 5.2, 2.6, BZ + 9.0, BX + 5.0, 1.9, BZ, 48]); camFin(); } },
  { t: 24.4, set: MARS, mood: MOOD.mars, loopin: 1,
    upd(lt){ dT = T - END; base(); hookScene(T - END); camW(0, HOOK[0], HOOK[1]); camFin(); } },
];
const SUBS = __SUBS__;
