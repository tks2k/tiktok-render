/* =========================================================
   STIMMUNG: Offenes Meer (statischer Himmel)
   ========================================================= */
function sky(top, mid, bot){
  const c = document.createElement('canvas'); c.width = 4; c.height = 512; const x = c.getContext('2d'), g = x.createLinearGradient(0, 0, 0, 512);
  g.addColorStop(0, top); g.addColorStop(0.55, mid); g.addColorStop(1, bot); x.fillStyle = g; x.fillRect(0, 0, 4, 512);
  const t = new THREE.CanvasTexture(c); t.encoding = THREE.sRGBEncoding; return t;
}
const MOOD = { sea: { sky: sky('#3f95dc', '#9fd0f2', '#e2f2fb'), fog: [0xcfe6f5, 60, 300], hemi: [0xeaf6ff, 0x2a6a90, 0.95], sun: [0xfff2da, 1.2], sp: [8, 20, 12] },
  rain: { sky: sky('#5d6f80', '#8fa0ae', '#c2ccd4'), fog: [0xa9b6c0, 40, 220], hemi: [0xd8e2ea, 0x2a4a60, 0.85], sun: [0xe6eef5, 0.75], sp: [6, 20, 10] } };
const SR = 10; { const c = sun.shadow.camera; c.left = -SR; c.right = SR; c.top = SR; c.bottom = -SR; c.near = 1; c.far = 80; c.updateProjectionMatrix(); }
function setMood(m){
  scene.background = m.sky; scene.fog.color.set(m.fog[0]); scene.fog.near = m.fog[1]; scene.fog.far = m.fog[2]; scene.environment = envDay;
  hemi.color.set(m.hemi[0]); hemi.groundColor.set(m.hemi[1]); hemi.intensity = m.hemi[2]; sun.color.set(m.sun[0]); sun.intensity = m.sun[1];
  sun.position.set(m.sp[0], m.sp[1], m.sp[2]); sun.target.position.set(0, 0, 0); fill.color.set(0xffffff); fill.intensity = 0.3; fill.position.set(-12, 6, 16);
}

/* =========================================================
   SET: Meer, Floß, Möwe
   ========================================================= */
const SEA = new THREE.Group(); scene.add(SEA); const SETS = [SEA];
(function(){ const s = new THREE.Mesh(new THREE.PlaneGeometry(800, 800), new THREE.MeshStandardMaterial({ color: 0x2b86b8, roughness: 0.18, metalness: 0.1, envMapIntensity: 1.1 })); s.rotation.x = -PI / 2; s.receiveShadow = true; SEA.add(s); })();
const RAFT = new THREE.Group(); SEA.add(RAFT);
(function(){ const r = P(RAFT, new THREE.TorusGeometry(1.55, 0.42, 16, 40), mat(0xf07a24, { roughness: 0.5 }), 0, 0.25, 0); r.rotation.x = PI / 2; r.scale.set(1, 1.25, 1);
  const f = P(RAFT, new THREE.CylinderGeometry(1.5, 1.5, 0.12, 40), mat(0xd8642a, { roughness: 0.7 }), 0, 0.1, 0); const st = P(RAFT, new THREE.TorusGeometry(1.55, 0.06, 8, 40), mat(0xfff2c8), 0, 0.5, 0); st.rotation.x = PI / 2; st.scale.set(1, 1.25, 1); })();
const CUP = new THREE.Group(); ben.el[1].add(CUP); CUP.position.set(0, -0.72, 0.12);
(function(){ P(CUP, new THREE.CylinderGeometry(0.2, 0.16, 0.36, 18), mat(0xeaeaea, { roughness: 0.4 }), 0, 0, 0); P(CUP, new THREE.CylinderGeometry(0.17, 0.17, 0.02, 18), mat(0x5fb0e0, { roughness: 0.1 }), 0, 0.12, 0); })();
const GULL = new THREE.Group(), GW = []; SEA.add(GULL);
(function(){ const w = mat(0xf6f6f2, { roughness: 0.6 }), g = mat(0x8a9098, { roughness: 0.6 }), y = mat(0xf2b318);
  const b = P(GULL, new THREE.SphereGeometry(1, 20, 14), w, 0, 0, 0); b.scale.set(0.55, 0.3, 0.3); P(GULL, new THREE.SphereGeometry(0.22, 16, 12), w, 0.5, 0.2, 0);
  const bk = P(GULL, new THREE.ConeGeometry(0.06, 0.28, 8), y, 0.78, 0.17, 0); bk.rotation.z = -PI / 2;
  [-1, 1].forEach(s => { P(GULL, new THREE.SphereGeometry(0.035, 8, 6), mat(0x111111), 0.6, 0.26, s * 0.15); const wg = new THREE.Group(); wg.position.set(0, 0.1, s * 0.2); GULL.add(wg); const p = P(wg, rbox(0.5, 0.05, 0.9, 0.02, 1), g, 0, 0, s * 0.45); GW.push([wg, s]);
    P(GULL, rbox(0.04, 0.3, 0.04, 0.01, 1), y, 0, -0.35, s * 0.1); });
  const t = P(GULL, rbox(0.35, 0.05, 0.25, 0.02, 1), g, -0.6, 0.05, 0); })();
function gull(x, y, z, yaw, flap, t){ GULL.visible = true; GULL.position.set(x, y, z); GULL.rotation.set(0, yaw, 0); GW.forEach(([wg, s]) => wg.rotation.x = s * (flap ? 0.7 * Math.sin(t * 12) : -0.15)); }

/* =========================================================
   BEN
   ========================================================= */
const SCAR = new THREE.Group(); ben.head.add(SCAR);
(function(){ const m = mat(0xa8463f, { roughness: 0.7 }); const s = new THREE.Mesh(rbox(0.075, 0.72, 0.03, 0.012, 1), m); s.position.set(0.25, 0.55, 0.522); s.rotation.z = -0.13; SCAR.add(s);
  for (const y of [0.36, 0.55, 0.74]){ const c = new THREE.Mesh(rbox(0.16, 0.035, 0.03, 0.01, 1), m); c.position.set(0.25 + (y - 0.55) * 0.13, y, 0.528); c.rotation.z = -0.13; SCAR.add(c); } })();
// Trinkbewegung k: 0 = Becher im Wasser, 1 = am Mund
function drink(r, k){ r.sh[1].rotation.set(lerp(-0.7, -2.2, k), 0, lerp(0.5, -0.25, k)); r.el[1].rotation.x = lerp(-0.2, -1.55, k); r.head.rotation.x = lerp(0.25, -0.2, k); r.torso.rotation.x = lerp(0.3, 0.05, k); r.torso.rotation.z = lerp(-0.12, 0, k); }

/* =========================================================
   KAMERA + Zustand
   ========================================================= */
const cL = new THREE.Vector3();
let blurAmt = 0, fadeBlk = 0, T = 0, flashA = 0, eyeS = 1, talk = 0, dT = 0;
let saltK = 0, kidK = 0, dryK = 0, glandK = 0, rainK = 0;
function camW(p, a, b){ cam.position.set(lerp(a[0], b[0], p), lerp(a[1], b[1], p), lerp(a[2], b[2], p)); cL.set(lerp(a[3], b[3], p), lerp(a[4], b[4], p), lerp(a[5], b[5], p)); cam.fov = lerp(a[6], b[6], p); }
function camFin(sh){ cam.position.x += Math.sin(dT * 0.7) * 0.02; cam.position.y += Math.sin(dT * 0.9 + 1) * 0.015; if (sh){ cam.position.x += Math.sin(T * 23) * sh; cam.position.y += Math.cos(T * 17) * sh; } cam.up.set(0, 1, 0); cam.lookAt(cL); cam.updateProjectionMatrix(); cam.updateMatrixWorld(); }
const HOOK = [[3.0, 3.6, 11.5, 0.2, 2.9, 0, 40], [2.6, 3.4, 10.4, 0.2, 2.8, 0, 40]];
const CMW = [2.6, 2.4, 10.0, 0.3, 1.2, 0, 40];
function bob(t){ const y = 0.08 * Math.sin(t * 1.4), rx = 0.05 * Math.sin(t * 1.1 + 0.5), rz = 0.04 * Math.sin(t * 0.9); RAFT.position.set(0, y, 0); RAFT.rotation.set(rx, 0, rz); return [y, rx, rz]; }
function seat(t){ const [y, rx, rz] = bob(t); bRest(ben, t, 0); place(ben, 0, y + 0.05, -0.1, 0.3); ben.root.rotation.x = rx; ben.root.rotation.z = rz; sit(ben, 0.12); ben.legs[0].rotation.x = -1.4; ben.legs[1].rotation.x = -1.4; ben.sh[0].rotation.set(-0.2, 0, -0.35); }
function base(){ show(ben); GULL.visible = false; CUP.visible = true; }
function hookBen(t){ seat(t); const k = E.io(seg(t, 0.9, 2.0)); drink(ben, k); eyeS = 1; bFace(ben, k > 0.8 ? 0.3 : 0.1, k > 0.8 ? 0.4 : 0.05); }

/* =========================================================
   SZENEN (Sprecherspur Tempo 1,15)
   ========================================================= */
const SCN = [
  { t: 0, set: SEA, mood: MOOD.sea, hook: 1,
    upd(lt){ dT = T; base(); hookBen(T); camW(E.io(seg(lt, 0, 3.36)), HOOK[0], HOOK[1]); camFin(); } },
  { t: 3.36, set: SEA, mood: MOOD.sea, hud: () => ['FAST 4× SO SALZIG', 'WIE BENS BLUT'],
    upd(lt){ dT = T; base(); seat(T); drink(ben, 1 - E.io(seg(T, 3.4, 4.0)) * 0.3); eyeS = 1.3; bFace(ben, -0.8, 0.2); saltK = E.out(seg(T, 3.6, 3.9)) * (1 - seg(T, 6.1, 6.31));
      camW(E.io(seg(lt, 0, 2.95)), HOOK[1], CMW); camFin(); } },
  { t: 6.31, set: SEA, mood: MOOD.sea, hud: () => ['DIE NIERE', 'MUSS DAS SALZ RAUSSPÜLEN'],
    upd(lt){ dT = T; base(); seat(T); drink(ben, 0.7 * (1 - seg(T, 6.4, 7.0))); eyeS = 1.1; bFace(ben, -0.4, 0.05); kidK = E.out(seg(T, 6.5, 6.8)) * (1 - seg(T, 11.0, 11.22));
      camW(E.io(seg(lt, 0, 4.91)), CMW, [2.2, 2.4, 9.2, 0.3, 1.3, 0, 40]); camFin(); } },
  { t: 11.22, set: SEA, mood: MOOD.sea, hud: () => T < 13.5 ? ['BEN TROCKNET AUS', 'SCHNELLER ALS OHNE TRINKEN'] : ['NOCH MEHR DURST', 'EIN TEUFELSKREIS'],
    upd(lt){ dT = T; base(); seat(T); const d = E.io(seg(T, 11.3, 14.5)); drink(ben, 0); ben.torso.rotation.x = 0.25 + 0.25 * d; ben.head.rotation.x = 0.2 + 0.25 * d; ben.sh[1].rotation.set(-0.3, 0, 0.3);
      eyeS = 1 - 0.45 * d; bFace(ben, -0.9 * d, 0.2 * d); dryK = E.out(seg(T, 11.4, 11.7)) * (1 - seg(T, 15.0, 15.2));
      camW(E.io(seg(lt, 0, 3.98)), [2.2, 2.4, 9.2, 0.3, 1.3, 0, 40], [3.2, 2.6, 10.5, 0.4, 1.3, 0, 40]); camFin(); } },
  { t: 15.2, set: SEA, mood: MOOD.sea, hud: () => ['MÖWEN KÖNNEN DAS', 'SALZDRÜSE ÜBER DEN AUGEN'],
    upd(lt){ dT = T; base(); seat(T); drink(ben, 0); ben.torso.rotation.x = 0.4; ben.head.rotation.set(0.1, 0.5, 0); ben.sh[1].rotation.set(-0.3, 0, 0.3); eyeS = 1.1; bFace(ben, -0.3, 0.1);
      const l = E.out(seg(T, 15.2, 16.4)); gull(lerp(6, 1.25, l), lerp(5, 0.92, l) + RAFT.position.y, lerp(-3, 0.75, l), PI * 0.85, l < 0.95, T); glandK = E.out(seg(T, 16.4, 16.7)) * (1 - seg(T, 18.6, 18.8));
      camW(E.io(seg(lt, 0, 3.6)), [3.2, 2.6, 10.5, 0.4, 1.3, 0, 40], [2.8, 2.2, 7.8, 0.8, 1.0, 0.4, 40]); camFin(); } },
  { t: 18.8, set: SEA, mood: MOOD.rain, hud: () => ['BEN BRAUCHT', 'SÜSSWASSER – ZUM BEISPIEL REGEN'],
    upd(lt){ dT = T; base(); seat(T); const u = E.io(seg(T, 19.0, 19.6)); ben.sh[1].rotation.set(lerp(-0.3, -2.9, u), 0, lerp(0.3, -0.1, u)); ben.el[1].rotation.x = -0.2; ben.head.rotation.x = -0.35 * u;
      eyeS = 1.2; bFace(ben, 0.6 * u, 0.5 * u); rainK = E.out(seg(T, 18.9, 19.3)) * (1 - seg(T, 21.0, 21.18));
      camW(E.io(seg(lt, 0, 2.38)), [3.6, 2.6, 11.5, 0.3, 1.4, 0, 40], [3.2, 2.5, 10.7, 0.3, 1.4, 0, 40]); camFin(); } },
  { t: 21.18, set: SEA, mood: MOOD.sea, hud: () => ['UND BEN?', 'NÄCHSTER REGENTROPFEN …'],
    upd(lt){ dT = T - END; base(); hookBen(T - END); camW(E.io(seg(T, 21.18, 23.5)), [4.2, 4.0, 12.5, 0.3, 2.6, 0, 40], HOOK[0]); camFin(); } },
  { t: 23.9, set: SEA, mood: MOOD.sea, loopin: 1,
    upd(lt){ dT = T - END; base(); hookBen(T - END); camW(0, HOOK[0], HOOK[1]); camFin(); } },
];
const SUBS = __SUBS__;
