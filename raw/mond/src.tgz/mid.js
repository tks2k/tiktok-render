/* =========================================================
   STIMMUNGEN: Erde (Wiese), Mars (Wüste), Mond (schwarzer Himmel)
   ========================================================= */
function sky(stops, stars){
  const c = document.createElement('canvas'); c.width = stars ? 540 : 4; c.height = stars ? 960 : 256; const x = c.getContext('2d'), g = x.createLinearGradient(0, 0, 0, c.height);
  stops.forEach(s => g.addColorStop(s[0], s[1])); x.fillStyle = g; x.fillRect(0, 0, c.width, c.height);
  if (stars){ let sd = 7; const r = () => { sd = (sd * 16807) % 2147483647; return sd / 2147483647; };
    for (let i = 0; i < 160; i++){ const px = r() * 540, py = r() * 700, s = 0.8 + r() * 1.6; x.globalAlpha = 0.35 + 0.5 * r(); x.fillStyle = '#ffffff'; x.beginPath(); x.arc(px, py, s, 0, 7); x.fill(); } x.globalAlpha = 1; }
  const t = new THREE.CanvasTexture(c); t.encoding = THREE.sRGBEncoding; return t;
}
const MOOD = {
  earth: { sky: sky([[0, '#5aa6e8'], [0.6, '#a9d4f5'], [1, '#e6f3ff']]), fog: [0xcfe6f7, 60, 220], hemi: [0xeaf4ff, 0x6a8a4a, 0.95], sun: [0xfff2d8, 1.1], env: 1, sp: [-4, 26, 16] },
  mars: { sky: sky([[0, '#c98a5e'], [0.6, '#e0a77c'], [1, '#f0c8a0']]), fog: [0xe0a77c, 60, 240], hemi: [0xffe2c8, 0x8a4a2a, 0.85], sun: [0xffe6c8, 1.05], env: 1, sp: [-8, 24, 14] },
  moon: { sky: sky([[0, '#05060b'], [1, '#0d1020']], 1), fog: [0x000000, 400, 900], hemi: [0xbfc8e0, 0x3a3a40, 0.55], sun: [0xffffff, 1.55], env: 1, sp: [-14, 18, 12] },
};
const SR = 12; { const c = sun.shadow.camera; c.left = -SR; c.right = SR; c.top = SR; c.bottom = -SR; c.near = 1; c.far = 90; c.updateProjectionMatrix(); }
function setMood(m){
  scene.background = m.sky; scene.fog.color.set(m.fog[0]); scene.fog.near = m.fog[1]; scene.fog.far = m.fog[2]; scene.environment = m.env ? envDay : envNight;
  hemi.color.set(m.hemi[0]); hemi.groundColor.set(m.hemi[1]); hemi.intensity = m.hemi[2]; sun.color.set(m.sun[0]); sun.intensity = m.sun[1];
  sun.position.set(m.sp[0], m.sp[1], m.sp[2]); sun.target.position.set(0, 0, 0); fill.color.set(0xffffff); fill.intensity = 0.3; fill.position.set(-20, 12, 30);
}

/* =========================================================
   SETS
   ========================================================= */
function ground(par, col, rough){ const g = new THREE.Mesh(new THREE.PlaneGeometry(400, 400), new THREE.MeshStandardMaterial({ color: col, roughness: rough || 1 })); g.rotation.x = -PI / 2; g.receiveShadow = true; par.add(g); return g; }
const EARTH = new THREE.Group(), MARS = new THREE.Group(), MOON = new THREE.Group(); scene.add(EARTH, MARS, MOON);
(function(){
  ground(EARTH, 0x74ad4e);
  const trunk = mat(0x6b4a2e), leaf = [mat(0x3e8a3e, { roughness: 0.9 }), mat(0x4f9a46, { roughness: 0.9 })];
  [[-12, -18], [-3, -24], [7, -20], [15, -26], [-20, -30], [22, -18]].forEach(([x, z], i) => { P(EARTH, new THREE.CylinderGeometry(0.4, 0.55, 4, 10), trunk, x, 2, z); P(EARTH, new THREE.SphereGeometry(2.8, 16, 12), leaf[i % 2], x, 5.6, z); });
  [[-6, -6], [6.5, -8], [-9, 2]].forEach(([x, z]) => P(EARTH, new THREE.SphereGeometry(0.9, 12, 10), leaf[1], x, 0.5, z));
  ground(MARS, 0xc1643a);
  const mr = mat(0x9a4a2c, { roughness: 0.95 });
  [[-6, -4, 0.8], [5, -6, 1.1], [-3, 3, 0.5], [8, 1, 0.6], [-10, -10, 1.4]].forEach(([x, z, s]) => P(MARS, new THREE.DodecahedronGeometry(s, 0), mr, x, s * 0.4, z));
  [[-30, -80, 22, 10], [20, -95, 30, 14], [60, -70, 18, 8], [-70, -60, 26, 12]].forEach(([x, z, w, h]) => P(MARS, new THREE.BoxGeometry(w, h, 14), mat(0xa8583a, { roughness: 1 }), x, h / 2, z));
  ground(MOON, 0x8d8d92);
  const mm = mat(0x77777c, { roughness: 1 });
  [[-6, -5, 2.2], [7, -9, 3.2], [-12, -16, 4], [4, 3.5, 1.3], [14, -3, 2.4]].forEach(([x, z, r]) => { const c = new THREE.Mesh(new THREE.TorusGeometry(r, 0.22, 8, 32), mm); c.rotation.x = -PI / 2; c.scale.set(1, 1, 0.5); c.position.set(x, 0.02, z); c.receiveShadow = true; MOON.add(c); });
  [[-4, -2, 0.5], [6, -4, 0.8], [-9, 1, 0.4], [10, -12, 1.2]].forEach(([x, z, s]) => P(MOON, new THREE.DodecahedronGeometry(s, 0), mat(0x6c6c72, { roughness: 1 }), x, s * 0.4, z));
  const ea = new THREE.Mesh(new THREE.SphereGeometry(10, 32, 20), new THREE.MeshBasicMaterial({ color: 0x3d7fd8, fog: false })); ea.position.set(-38, 62, -160); MOON.add(ea);
  [[-2, 4, 4], [3, -3, 3.5], [-5, -4, 2.8]].forEach(([dx, dy, r]) => { const l = new THREE.Mesh(new THREE.SphereGeometry(r, 16, 12), new THREE.MeshBasicMaterial({ color: 0x5aa060, fog: false })); l.position.set(-38 + dx, 62 + dy, -160 + 8.6); l.scale.z = 0.3; MOON.add(l); });
})();
const SETS = [EARTH, MARS, MOON];

/* =========================================================
   FIGUREN (Helm + Rucksack für Mars / Mond)
   ========================================================= */
const SCAR = new THREE.Group(); ben.head.add(SCAR);
(function(){ const m = mat(0xa8463f, { roughness: 0.7 }); const s = new THREE.Mesh(rbox(0.075, 0.72, 0.03, 0.012, 1), m); s.position.set(0.25, 0.55, 0.522); s.rotation.z = -0.13; SCAR.add(s);
  for (const y of [0.36, 0.55, 0.74]){ const c = new THREE.Mesh(rbox(0.16, 0.035, 0.03, 0.01, 1), m); c.position.set(0.25 + (y - 0.55) * 0.13, y, 0.528); c.rotation.z = -0.13; SCAR.add(c); } })();
const pro = boxer({ top: 0x3cae6a, pants: 0x1f2a44, shoe: 0x1c1c22, hair: 0x8a5a2a, skin: 0xf2c6a2 }); ALL.push(pro); scene.add(pro.root);
const GLASS = new THREE.MeshStandardMaterial({ color: 0xdfefff, transparent: true, opacity: 0.16, roughness: 0.05, metalness: 0.1, envMapIntensity: 1.4, depthWrite: false });
function suitUp(r){ const H = new THREE.Group(); const g = new THREE.Mesh(new THREE.SphereGeometry(1.05, 32, 20), GLASS); g.position.y = 0.55; g.renderOrder = 5; H.add(g);
  const ring = new THREE.Mesh(new THREE.TorusGeometry(0.62, 0.09, 10, 32), mat(0xe8e8ec, { roughness: 0.5 })); ring.rotation.x = PI / 2; ring.position.y = -0.18; ring.castShadow = true; H.add(ring); r.head.add(H);
  const B = new THREE.Group(); P(B, rbox(0.92, 1.0, 0.42, 0.08), mat(0xeeeef2, { roughness: 0.55 }), 0, 0.62, -0.5); P(B, rbox(0.5, 0.12, 0.06, 0.03, 1), mat(0x3a7ad8), 0, 0.9, -0.72); r.torso.add(B); return [H, B]; }
const BSUIT = suitUp(ben), PSUIT = suitUp(pro);
function suit(r, on){ (r === ben ? BSUIT : PSUIT).forEach(o => o.visible = on); }
const MU = 1.83;   // 1 Meter in Szenen-Einheiten (Ben = 1,8 m)
// Hocke k (0..1): Körper runter, Beine nach vorn, Oberkörper vor, Arme zurück
function crouch(r, k){ r.body.position.y = 1 - 0.2 * k; r.legs[0].rotation.x = -0.62 * k; r.legs[1].rotation.x = -0.62 * k; r.torso.rotation.x = 0.45 * k; r.sh[0].rotation.x = 0.8 * k; r.sh[1].rotation.x = 0.8 * k; r.head.rotation.x = -0.3 * k; }
// Sprung: Absprung t0, Flugzeit th, Höhe hu (Einheiten); liefert y der Füße
function jump(r, t, t0, th, hu){ const a = t - t0;
  if (a < 0){ crouch(r, E.io(seg(t, t0 - 0.45, t0 - 0.05)) * (1 - seg(t, t0 - 0.05, t0))); return 0; }
  if (a < th){ const u = a / th, y = 4 * hu * u * (1 - u); r.sh[0].rotation.set(-2.5 + 1.2 * u, 0, -0.25); r.sh[1].rotation.set(-2.5 + 1.2 * u, 0, 0.25); r.legs[0].rotation.x = 0.12 * Math.sin(u * PI); r.legs[1].rotation.x = -0.12 * Math.sin(u * PI); return y; }
  crouch(r, 0.7 * (1 - E.out(seg(a - th, 0, 0.45))) * (a - th < 0.08 ? (a - th) / 0.08 : 1)); return 0; }

/* =========================================================
   KAMERA + Zustand
   ========================================================= */
const cL = new THREE.Vector3();
let blurAmt = 0, fadeBlk = 0, T = 0, flashA = 0, eyeS = 1, talk = 0, dT = 0;
let rulK = 0, timK = 0, gK = 0, suitK = 0, fallK = 0, RUL = null, TIM = [0, ''];
function camW(p, a, b){ cam.position.set(lerp(a[0], b[0], p), lerp(a[1], b[1], p), lerp(a[2], b[2], p)); cL.set(lerp(a[3], b[3], p), lerp(a[4], b[4], p), lerp(a[5], b[5], p)); cam.fov = lerp(a[6], b[6], p); }
function camFin(sh){ cam.position.x += Math.sin(dT * 0.7) * 0.012; cam.position.y += Math.sin(dT * 0.9 + 1) * 0.008; if (sh){ cam.position.x += Math.sin(T * 23) * sh; cam.position.y += Math.cos(T * 17) * sh; } cam.up.set(0, 1, 0); cam.lookAt(cL); cam.updateProjectionMatrix(); cam.updateMatrixWorld(); }
const imp = at => T >= at ? Math.exp(-(T - at) * 3) : 0;
const air = (t, t0, th) => Math.max(0, Math.min(t - t0, th));
const HOOK = [[0.4, 2.4, 12.6, 0, 2.0, 0, 40], [0.8, 2.3, 11.4, 0, 1.9, 0, 40]];
function base(){ show(ben); ben.torso.scale.set(1, 1, 1); suit(ben, true); suit(pro, true); pro.root.visible = false; }
function hookBen(t){ bRest(ben, T, 0); place(ben, 0, 0, 0, 0.15); const sw = Math.sin(t * 2.6);
  crouch(ben, 0.75 + 0.08 * sw); ben.sh[0].rotation.x = 0.6 + 0.5 * sw; ben.sh[1].rotation.x = 0.6 + 0.5 * sw; eyeS = 1; bFace(ben, 0.5, 0.05); }

/* =========================================================
   SZENEN (gekürzte Sprecherspur, Tempo 1,35)
   ========================================================= */
const SCN = [
  { t: 0, set: MOON, mood: MOOD.moon, hook: 1,
    upd(lt){ dT = T; base(); hookBen(T); camW(E.io(seg(lt, 0, 3.0)), HOOK[0], HOOK[1]); camFin(); } },
  { t: 3.0, set: EARTH, mood: MOOD.earth, hud: () => ['ERDE: 0,5 M', 'SCHWERKRAFT 1 G'],
    upd(lt){ dT = T; base(); suit(ben, false); bRest(ben, T, 0); place(ben, 0, 0, 0, 0.1);
      const a = T < 4.9 ? jump(ben, T, 3.8, 0.64, 0.5 * MU) : jump(ben, T, 5.45, 0.64, 0.5 * MU); ben.root.position.y = a; eyeS = 1; bFace(ben, a > 0 ? -0.3 : 0.4, a > 0 ? 0.4 : 0.05);
      RUL = { x: 2.4, max: 1, peak: 0.5, lab: '0,5 M' }; rulK = E.out(seg(T, 3.2, 3.5)) * (1 - seg(T, 6.55, 6.75));
      TIM = [T < 4.9 ? air(T, 3.8, 0.64) : air(T, 5.45, 0.64), 'IN DER LUFT']; timK = rulK;
      camW(E.io(seg(lt, 0, 3.75)), [1.6, 2.6, 13.2, 0.7, 2.3, 0, 40], [1.4, 2.6, 12.4, 0.7, 2.3, 0, 40]); camFin(); } },
  { t: 6.75, set: MARS, mood: MOOD.mars, hud: () => ['MARS: 1,3 M', 'SCHWERKRAFT 0,38 G'],
    upd(lt){ dT = T; base(); bRest(ben, T, 0); place(ben, 0, 0, 0, 0.1);
      const a = jump(ben, T, 7.6, 1.64, 1.32 * MU); ben.root.position.y = a; eyeS = a > 0 ? 1.3 : 1; bFace(ben, a > 0 ? -0.6 : 0.3, a > 0 ? 0.6 : 0.05);
      RUL = { x: 2.6, max: 2, peak: 1.3, lab: '1,3 M' }; rulK = E.out(seg(T, 6.9, 7.2)) * (1 - seg(T, 10.4, 10.55)); TIM = [air(T, 7.6, 1.64), 'IN DER LUFT']; timK = rulK;
      camW(E.io(seg(lt, 0, 3.8)), [1.8, 3.3, 15.6, 0.7, 3.0, 0, 40], [1.6, 3.3, 15.0, 0.7, 3.1, 0, 40]); camFin(); } },
  { t: 10.55, set: MOON, mood: MOOD.moon, hud: () => ['MOND: 3 M!', 'SCHWERKRAFT 0,17 G'],
    upd(lt){ dT = T; base(); bRest(ben, T, 0); place(ben, 0, 0, 0, 0.1);
      const a = jump(ben, T, 10.75, 3.85, 3.0 * MU); ben.root.position.y = a; eyeS = a > 0 ? 1.4 : 1; bFace(ben, a > 0 ? -0.8 : 0.3, a > 0 ? 0.9 : 0.05);
      RUL = { x: 2.9, max: 3.5, peak: 3.0, lab: '3 M' }; rulK = E.out(seg(T, 10.65, 10.95)) * (1 - seg(T, 14.55, 14.75)); TIM = [air(T, 10.75, 3.85), 'IN DER LUFT']; timK = rulK;
      gK = E.out(seg(T, 11.4, 11.7)) * (1 - seg(T, 14.5, 14.7));
      const ly = 2.2 + 0.75 * a; camW(0, [1.8, 0, 17.0, 0.8, 0, 0, 40], [1.8, 0, 17.0, 0.8, 0, 0, 40]); cam.position.y = 2.6 + 0.55 * a; cL.y = ly; camFin(); } },
  { t: 14.75, set: MOON, mood: MOOD.moon, hud: () => T < 16.4 ? ['RAUMANZUG', 'SO SCHWER WIE BEN'] : ['STEIF WIE EIN BALLON', 'UNTER DRUCK AUFGEBLÄHT'],
    upd(lt){ dT = T; base(); bRest(ben, T, 0); place(ben, 0, 0, 0, 0.1); const inf = E.out(seg(T, 16.5, 16.9));
      ben.torso.scale.set(1 + 0.12 * inf, 1 + 0.03 * inf, 1 + 0.18 * inf); ben.sh[0].rotation.set(0, 0, -0.07 - 0.5 * inf); ben.sh[1].rotation.set(0, 0, 0.07 + 0.5 * inf); ben.el[0].rotation.set(-0.02, 0, 0); ben.el[1].rotation.set(-0.02, 0, 0);
      eyeS = 1; bFace(ben, inf > 0.5 ? -0.4 : 0.2, inf > 0.5 ? 0.4 : 0.05); suitK = E.out(seg(T, 14.9, 15.2)) * (1 - seg(T, 16.3, 16.5));
      camW(E.io(seg(lt, 0, 3.15)), [1.0, 2.6, 11.4, 0.2, 2.2, 0, 40], [0.6, 2.5, 10.6, 0.2, 2.2, 0, 40]); camFin(); } },
  { t: 17.9, set: MOON, mood: MOOD.moon, hud: () => ['PROFI', 'KÄNGURU-HÜPFER'],
    upd(lt){ dT = T; base(); ben.root.visible = false; pro.root.visible = true; bRest(pro, T, 2);
      const per = 1.2, ph = ((T - 17.95) / per) % 1, hop = Math.max(0, ph < 0.82 ? Math.sin(PI * ph / 0.82) : 0), x = -3.2 + 2.6 * (T - 17.95);
      place(pro, x, 0.55 * hop, 0, PI / 2); pro.legs[0].rotation.x = -0.25 * hop; pro.legs[1].rotation.x = -0.25 * hop; pro.body.position.y = 1 - 0.12 * (1 - hop);
      pro.sh[0].rotation.set(-0.5 - 0.4 * hop, 0, -0.15); pro.sh[1].rotation.set(-0.5 - 0.4 * hop, 0, 0.15); pro.torso.rotation.x = 0.15; bFace(pro, 0.4, 0.05);
      camW(0, [x + 0.6, 2.4, 12.6, x, 1.9, 0, 40], [x + 0.6, 2.4, 12.6, x, 1.9, 0, 40]); camFin(); } },
  { t: 20.3, set: MOON, mood: MOOD.moon, hud: () => ['HINFALLEN?', 'GANZ GEMÜTLICH'],
    upd(lt){ dT = T; base(); bRest(ben, T, 0); const f = E.io(seg(T, 20.5, 22.0)) * (1 - E.io(seg(T, 22.6, 23.3)));
      place(ben, 0, 0, 0, 0.1); ben.root.rotation.x = 1.08 * f; const arm = Math.min(1, f * 1.6);
      ben.sh[0].rotation.set(-1.5 * arm, 0, -0.15); ben.sh[1].rotation.set(-1.5 * arm, 0, 0.15); ben.el[0].rotation.set(-0.1, 0, 0); ben.el[1].rotation.set(-0.1, 0, 0);
      eyeS = 1.3; bFace(ben, -0.5, 0.5 * f); fallK = E.out(seg(T, 20.8, 21.1)) * (1 - seg(T, 23.1, 23.3)); TIM = [air(T, 20.5, 1.5), 'STURZ']; timK = fallK;
      camW(E.io(seg(lt, 0, 3.0)), [8.6, 2.6, 7.4, 0, 1.5, 1.0, 40], [8.0, 2.4, 6.8, 0, 1.4, 1.0, 40]); camFin(); } },
  { t: 23.3, set: MOON, mood: MOOD.moon, hud: () => ['UND BEN?', 'NÄCHSTER SPRUNG'],
    upd(lt){ dT = T; base(); const k = E.io(seg(T, 23.8, 24.9)); hookBen(T - END); const st = 1 - k;
      crouch(ben, (0.75 + 0.08 * Math.sin((T - END) * 2.6)) * k); ben.sh[0].rotation.x *= k; ben.sh[1].rotation.x *= k;
      camW(E.io(seg(lt, 0, 1.8)), [3.4, 2.6, 12.8, 0.2, 2.1, 0, 40], HOOK[0]); camFin(); } },
  { t: 25.1, set: MOON, mood: MOOD.moon, loopin: 1,
    upd(lt){ dT = T - END; base(); hookBen(T - END); camW(0, HOOK[0], HOOK[1]); camFin(); } },
];
const SUBS = __SUBS__;
