/* =========================================================
   STIMMUNG: Sauna (warm) + Eisbecken (kühl)
   ========================================================= */
function grad(a, b){ const c = document.createElement('canvas'); c.width = 4; c.height = 256; const x = c.getContext('2d'), g = x.createLinearGradient(0, 0, 0, 256); g.addColorStop(0, a); g.addColorStop(1, b); x.fillStyle = g; x.fillRect(0, 0, 4, 256); const t = new THREE.CanvasTexture(c); t.encoding = THREE.sRGBEncoding; return t; }
const MOOD = { sauna: { sky: grad('#3a1f10', '#6a3a1c'), fog: [0x6a3a1c, 30, 90], hemi: [0xffd9a8, 0x5a3418, 0.85], sun: [0xffb870, 1.1], sp: [4, 9, 8] },
  pool: { sky: grad('#cfe2ee', '#eaf3f8'), fog: [0xe2eef5, 30, 90], hemi: [0xeaf6ff, 0x8aa0b0, 0.95], sun: [0xffffff, 1.0], sp: [4, 10, 8] } };
const SR = 8; { const c = sun.shadow.camera; c.left = -SR; c.right = SR; c.top = SR; c.bottom = -SR; c.near = 1; c.far = 40; c.updateProjectionMatrix(); }
function setMood(m){
  scene.background = m.sky; scene.fog.color.set(m.fog[0]); scene.fog.near = m.fog[1]; scene.fog.far = m.fog[2]; scene.environment = envDay;
  hemi.color.set(m.hemi[0]); hemi.groundColor.set(m.hemi[1]); hemi.intensity = m.hemi[2]; sun.color.set(m.sun[0]); sun.intensity = m.sun[1];
  sun.position.set(m.sp[0], m.sp[1], m.sp[2]); sun.target.position.set(0, 1, 0); fill.color.set(0xffe2c0); fill.intensity = 0.35; fill.position.set(-6, 4, 10);
}

/* =========================================================
   SETS
   ========================================================= */
function planks(col, dark){ const c = document.createElement('canvas'); c.width = 256; c.height = 256; const x = c.getContext('2d'); x.fillStyle = col; x.fillRect(0, 0, 256, 256);
  for (let i = 0; i < 4; i++){ x.fillStyle = dark; x.fillRect(0, i * 64, 256, 3); } const t = new THREE.CanvasTexture(c); t.encoding = THREE.sRGBEncoding; t.wrapS = t.wrapT = THREE.RepeatWrapping; t.anisotropy = 4; return t; }
const SAUNA = new THREE.Group(), POOL = new THREE.Group(); scene.add(SAUNA, POOL); const SETS = [SAUNA, POOL];
const STONES = new THREE.Vector3(2.6, 1.25, -1.2), HANDLE = new THREE.Vector3(1.35, 1.0, -0.9);
(function(){
  const wt = planks('#c98b4e', '#9a6234'); wt.repeat.set(3, 2); const wm = new THREE.MeshStandardMaterial({ map: wt, roughness: 0.8 });
  const back = new THREE.Mesh(new THREE.PlaneGeometry(12, 8), wm); back.position.set(0, 4, -3.2); back.receiveShadow = true; SAUNA.add(back);
  const side = new THREE.Mesh(new THREE.PlaneGeometry(10, 8), wm); side.position.set(-4.5, 4, 1.5); side.rotation.y = PI / 2; side.receiveShadow = true; SAUNA.add(side);
  const side2 = side.clone(); side2.position.set(5, 4, 1.5); side2.rotation.y = -PI / 2; SAUNA.add(side2);
  const fl = new THREE.Mesh(new THREE.PlaneGeometry(12, 10), mat(0x8a5a32, { roughness: 0.9 })); fl.rotation.x = -PI / 2; fl.receiveShadow = true; SAUNA.add(fl);
  const bw = mat(0xe0a868, { roughness: 0.75 });
  P(SAUNA, rbox(6.5, 0.18, 1.0, 0.04), bw, -1.0, 1.15, -2.55); P(SAUNA, rbox(6.5, 1.15, 0.12, 0.03), mat(0xb7814a), -1.0, 0.57, -2.05);
  P(SAUNA, rbox(6.5, 0.16, 0.8, 0.04), bw, -1.0, 0.55, -1.6);
  const st = mat(0x2a2a30, { roughness: 0.5, metalness: 0.6 }); P(SAUNA, rbox(1.2, 1.1, 1.0, 0.06), st, STONES.x, 0.55, STONES.z); P(SAUNA, rbox(1.3, 0.12, 1.1, 0.04), mat(0x3a3a40, { metalness: 0.6 }), STONES.x, 1.1, STONES.z);
  for (let i = 0; i < 9; i++){ const s = P(SAUNA, new THREE.DodecahedronGeometry(0.2 + 0.06 * hsh(i), 0), mat(0x6a6a72, { roughness: 1, flatShading: true }), STONES.x - 0.4 + (i % 3) * 0.4, 1.3 + Math.floor(i / 3) * 0.08, STONES.z - 0.3 + Math.floor(i / 3) * 0.3); s.rotation.set(i, i * 2, 0); }
  P(SAUNA, new THREE.CylinderGeometry(0.26, 0.22, 0.4, 16), mat(0xb07a42, { roughness: 0.8 }), HANDLE.x, 0.83, HANDLE.z);
  const h = P(SAUNA, new THREE.TorusGeometry(0.24, 0.035, 8, 20, PI), mat(0xcfd4dc, { roughness: 0.25, metalness: 0.9 }), HANDLE.x, 1.02, HANDLE.z); h.rotation.y = 0.3;
  const lamp = P(SAUNA, rbox(0.6, 0.3, 0.12, 0.05), mat(0xffcf8a, { emissive: 0xffa040, emissiveIntensity: 0.9 }), -3.2, 3.4, -3.1);
  const tf = planks('#dfe9f0', '#b4c4d0'); tf.repeat.set(6, 6); const fm = new THREE.MeshStandardMaterial({ map: tf, roughness: 0.4 });
  const pf = new THREE.Mesh(new THREE.PlaneGeometry(14, 14), fm); pf.rotation.x = -PI / 2; pf.receiveShadow = true; POOL.add(pf);
  const pw = new THREE.Mesh(new THREE.PlaneGeometry(14, 8), fm); pw.position.set(0, 4, -4); POOL.add(pw);
  P(POOL, rbox(3.6, 0.5, 3.6, 0.1), mat(0xbcd0dc, { roughness: 0.4 }), 0, 0.25, -0.6);
  const wat = P(POOL, rbox(3.2, 0.1, 3.2, 0.04), mat(0x5fc0e8, { roughness: 0.1, metalness: 0.1, transparent: true, opacity: 0.85 }), 0, 0.46, -0.6); wat.castShadow = false;
  for (let i = 0; i < 6; i++) P(POOL, rbox(0.35, 0.3, 0.35, 0.05), mat(0xf2fbff, { roughness: 0.2, transparent: true, opacity: 0.9 }), -1.1 + hsh(i) * 2.2, 0.5, -1.7 + hsh(i + 5) * 2.2);
})();
const HAT = new THREE.Group(); ben.head.add(HAT); P(HAT, new THREE.CylinderGeometry(0.45, 0.62, 0.55, 18), mat(0xe8dcc4, { roughness: 1 }), 0, 1.18, 0); P(HAT, new THREE.CylinderGeometry(0.66, 0.66, 0.1, 18), mat(0xd8c8a8, { roughness: 1 }), 0, 0.92, 0);
const LADLE = new THREE.Group(); ben.el[1].add(LADLE); LADLE.position.set(0, -0.68, 0.12); const lh = P(LADLE, rbox(0.08, 0.08, 1.1, 0.03, 1), mat(0x9a6234), 0, 0, 0.5); P(LADLE, new THREE.SphereGeometry(0.16, 12, 8, 0, 2 * PI, PI / 2, PI / 2), mat(0x9a6234), 0, 0.05, 1.05);

/* =========================================================
   BEN
   ========================================================= */
const SCAR = new THREE.Group(); ben.head.add(SCAR);
(function(){ const m = mat(0xa8463f, { roughness: 0.7 }); const s = new THREE.Mesh(rbox(0.075, 0.72, 0.03, 0.012, 1), m); s.position.set(0.25, 0.55, 0.522); s.rotation.z = -0.13; SCAR.add(s);
  for (const y of [0.36, 0.55, 0.74]){ const c = new THREE.Mesh(rbox(0.16, 0.035, 0.03, 0.01, 1), m); c.position.set(0.25 + (y - 0.55) * 0.13, y, 0.528); c.rotation.z = -0.13; SCAR.add(c); } })();
function seated(t){ bRest(ben, t, 0); place(ben, -0.4, 0, -2.45, 0.15); sit(ben, 1.24); ben.legs[0].rotation.x = -1.35; ben.legs[1].rotation.x = -1.35; ben.sh[0].rotation.set(-0.25, 0, -0.25); ben.sh[1].rotation.set(-0.25, 0, 0.25); ben.el[0].rotation.x = -0.4; ben.el[1].rotation.x = -0.4; ben.torso.rotation.x = 0.06 + 0.02 * Math.sin(t * 2); }

/* =========================================================
   KAMERA + Zustand
   ========================================================= */
const cL = new THREE.Vector3();
let blurAmt = 0, fadeBlk = 0, T = 0, flashA = 0, eyeS = 1, talk = 0, dT = 0;
let sweatK = 0, thermK = 0, wvK = 0, condK = 0, touchK = 0, steamK = 0, timeK = 0, splashT = -9;
function camW(p, a, b){ cam.position.set(lerp(a[0], b[0], p), lerp(a[1], b[1], p), lerp(a[2], b[2], p)); cL.set(lerp(a[3], b[3], p), lerp(a[4], b[4], p), lerp(a[5], b[5], p)); cam.fov = lerp(a[6], b[6], p); }
function camFin(sh){ cam.position.x += Math.sin(dT * 0.7) * 0.015; cam.position.y += Math.sin(dT * 0.9 + 1) * 0.012; if (sh){ cam.position.x += Math.sin(T * 23) * sh; cam.position.y += Math.cos(T * 17) * sh; } cam.up.set(0, 1, 0); cam.lookAt(cL); cam.updateProjectionMatrix(); cam.updateMatrixWorld(); }
const HOOK = [[1.2, 3.4, 8.6, 0.0, 3.0, -2, 40], [1.0, 3.3, 7.8, 0.0, 2.95, -2, 40]];
const CW = [2.2, 3.0, 9.6, 0.4, 2.0, -1.5, 40];
function base(){ show(ben); LADLE.visible = false; HAT.visible = true; }
function hookBen(t){ seated(t); eyeS = 0.9; bFace(ben, 0.25, 0.08); sweatK = 1; thermK = 1; }

/* =========================================================
   SZENEN (Sprecherspur Tempo 1,2)
   ========================================================= */
const SCN = [
  { t: 0, set: SAUNA, mood: MOOD.sauna, hook: 1,
    upd(lt){ dT = T; base(); hookBen(T); camW(E.io(seg(lt, 0, 3.45)), HOOK[0], HOOK[1]); camFin(); } },
  { t: 3.45, set: SAUNA, mood: MOOD.sauna, hud: () => ['100 °C WASSER?', 'SOFORT VERBRÜHT'],
    upd(lt){ dT = T; base(); seated(T); eyeS = 1.3; bFace(ben, -0.7, 0.3); sweatK = 1; wvK = E.out(seg(T, 3.7, 4.0)) * (1 - seg(T, 6.05, 6.23)); camW(E.io(seg(lt, 0, 2.78)), HOOK[1], CW); camFin(); } },
  { t: 6.23, set: SAUNA, mood: MOOD.sauna, hud: () => T < 8.38 ? ['TROCKENE LUFT', 'LEITET WÄRME SCHLECHT'] : ['SCHWEISS KÜHLT', 'BEIM VERDUNSTEN'],
    upd(lt){ dT = T; base(); seated(T); eyeS = 1; bFace(ben, 0.35, 0.05); sweatK = 1; condK = E.out(seg(T, 6.4, 6.7)) * (1 - seg(T, 10.2, 10.38));
      camW(E.io(seg(lt, 0, 4.15)), CW, [1.4, 3.3, 7.6, -0.2, 2.6, -2, 40]); camFin(); } },
  { t: 10.38, set: SAUNA, mood: MOOD.sauna, hud: () => T < 12.13 ? ['HOLZ: KEIN PROBLEM', 'LEITET WÄRME KAUM'] : ['METALL: AUTSCH!', 'LEITET WÄRME SUPER'],
    upd(lt){ dT = T; base(); seated(T); const r = E.io(seg(T, 12.2, 12.7)) * (1 - E.out(seg(T, 12.75, 13.0))); ben.torso.rotation.y = -0.35 * r; ben.sh[1].rotation.set(lerp(-0.25, -1.1, r), 0, lerp(0.25, 0.9, r)); ben.el[1].rotation.x = lerp(-0.4, -0.2, r);
      eyeS = T > 12.7 ? 1.4 : 1; bFace(ben, T > 12.7 ? -0.9 : 0.3, T > 12.7 ? 0.5 : 0.05); touchK = E.out(seg(T, 10.5, 10.8)) * (1 - seg(T, 13.5, 13.67)); flashA = 0.2 * bump(T, 12.7, 12.95);
      camW(E.io(seg(lt, 0, 3.29)), [1.6, 3.0, 8.8, 0.4, 1.9, -1.8, 40], [1.8, 2.9, 8.2, 0.6, 1.8, -1.6, 40]); camFin(0.03 * bump(T, 12.7, 13.0)); } },
  { t: 13.67, set: SAUNA, mood: MOOD.sauna, hud: () => T < 15.68 ? ['AUFGUSS!', 'DIE LUFT WIRD FEUCHT'] : ['DAMPF KONDENSIERT', 'FÜHLT SICH VIEL HEISSER AN'],
    upd(lt){ dT = T; base(); seated(T); LADLE.visible = T < 15.2; const p = E.io(seg(T, 13.8, 14.4)) * (1 - E.io(seg(T, 14.9, 15.3))); ben.torso.rotation.y = -0.6 * p; ben.sh[1].rotation.set(lerp(-0.25, -1.3, p), 0, lerp(0.25, 1.0, p)); ben.el[1].rotation.x = lerp(-0.4, -0.3, p);
      const hot = E.io(seg(T, 15.5, 16.5)); eyeS = lerp(1, 0.4, hot); bFace(ben, -0.9 * hot, 0.35 * hot); sweatK = 1 + hot; steamK = E.out(seg(T, 14.3, 14.7)) * (1 - seg(T, 18.4, 18.68));
      camW(E.io(seg(lt, 0, 5.01)), [2.6, 3.2, 9.4, 1.0, 1.9, -1.6, 40], [1.4, 3.3, 7.8, 0.0, 2.7, -2, 40]); camFin(); } },
  { t: 18.7, set: SAUNA, mood: MOOD.sauna, hud: () => ['8 BIS 15 MINUTEN', 'DANN RAUS'],
    upd(lt){ dT = T; base(); seated(T); eyeS = 1; bFace(ben, 0.3, 0.1); sweatK = 1; timeK = E.out(seg(T, 18.85, 19.15)) * (1 - seg(T, 21.05, 21.25));
      camW(E.io(seg(lt, 0, 2.55)), [1.4, 3.3, 7.8, 0.0, 2.7, -2, 40], [2.4, 3.2, 9.6, 0.0, 2.4, -2, 40]); camFin(); } },
  { t: 21.25, set: POOL, mood: MOOD.pool, hud: () => ['UND BEN?', 'AB INS EISBECKEN'],
    upd(lt){ dT = T; base(); HAT.visible = false; bRest(ben, T, 0); const j = seg(T, 21.4, 22.2), y = j < 1 ? 1.6 + 2.2 * Math.sin(PI * j * 0.6) - 4.0 * j * j : -0.85; place(ben, lerp(-2.4, 0, Math.min(1, j * 1.3)), Math.max(-0.85, y), -0.6, 0.4);
      ben.sh[0].rotation.set(-2.6 * (1 - seg(T, 22.0, 22.3)), 0, -0.3); ben.sh[1].rotation.set(-2.6 * (1 - seg(T, 22.0, 22.3)), 0, 0.3); eyeS = 1.3; bFace(ben, T > 22.1 ? -0.8 : 0.6, 0.5);
      camW(0, [3.4, 3.6, 8.0, 0, 1.2, -0.6, 40], [3.4, 3.6, 8.0, 0, 1.2, -0.6, 40]); camFin(0.04 * bump(T, 22.15, 22.5)); } },
  { t: 22.9, set: SAUNA, mood: MOOD.sauna, loopin: 1,
    upd(lt){ dT = T - END; base(); hookBen(T - END); camW(0, HOOK[0], HOOK[1]); camFin(); } },
];
const SUBS = __SUBS__;
