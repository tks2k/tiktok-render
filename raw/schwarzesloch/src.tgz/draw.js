/* =========================================================
   TEXT (neues Format: fett, Großbuchstaben, aktives Wort gelb)
   ========================================================= */
const SANS = '"Arial Black", "Helvetica Neue", Arial, system-ui, sans-serif', SERIF = SANS;
const band = document.createElement('canvas'); band.width = 8; band.height = 512;
(function(){ const x = band.getContext('2d'), g = x.createLinearGradient(0, 0, 0, 512); g.addColorStop(0, 'rgba(10,14,24,0)'); g.addColorStop(0.5, 'rgba(10,14,24,0.42)'); g.addColorStop(1, 'rgba(10,14,24,0)'); x.fillStyle = g; x.fillRect(0, 0, 8, 512); })();
function boldLines(words, cy, size, maxW, act, pop, col){
  g2.save(); g2.font = `900 ${size}px ${SANS}`; g2.textBaseline = 'middle'; g2.lineJoin = 'round';
  const spc = size * 0.28, lines = [[]]; let lw = 0;
  words.forEach((w, i) => { const wd = g2.measureText(w).width; if (lw + wd > maxW && lines[lines.length - 1].length){ lines.push([]); lw = 0; } lines[lines.length - 1].push({ w, wd, i }); lw += wd + spc; });
  const lh = size * 1.12, y0 = cy - (lines.length - 1) * lh / 2;
  lines.forEach((ln, li) => { const tw = ln.reduce((a, b) => a + b.wd, 0) + spc * (ln.length - 1); let x = W / 2 - tw / 2;
    ln.forEach(tk => { const on = tk.i === act, s = on ? 1 + 0.08 * pop : 1, y = y0 + li * lh;
      g2.save(); g2.translate(x + tk.wd / 2, y); g2.scale(s, s);
      g2.lineWidth = size * 0.2; g2.strokeStyle = '#0b1220'; g2.strokeText(tk.w, -tk.wd / 2, 0);
      g2.fillStyle = on ? '#ffd23c' : (col || '#ffffff'); g2.fillText(tk.w, -tk.wd / 2, 0); g2.restore(); x += tk.wd + spc; }); });
  g2.restore();
}
function fitSize(text, size, maxW){ g2.font = `900 ${size}px ${SANS}`; const w = g2.measureText(text).width; return w > maxW ? size * maxW / w : size; }
function drawHook(a, sc){
  if (a <= 0) return; g2.save(); g2.globalAlpha = a; g2.drawImage(band, 0, 340, W, 520);
  const s1 = fitSize('SCHWARZES LOCH', 120, 960), s2 = fitSize('WAS PASSIERT?', 120, 900);
  g2.translate(W / 2, 600); g2.scale(sc, sc); g2.translate(-W / 2, -600);
  boldLines(['SCHWARZES', 'LOCH'], 535, s1, 1000, -1, 0); boldLines(['WAS', 'PASSIERT?'], 670, s2, 940, -1, 0, '#ffd23c');
  g2.restore();
}
function drawSubs(){
  let cur = null; for (const s of SUBS) if (T >= s.s && T < s.e) cur = s; if (!cur) return;
  let act = 0; cur.w.forEach((w, i) => { if (T >= w[1]) act = i; });
  const pop = clamp01(1 - (T - cur.w[act][1]) / 0.18), age = T - cur.s, a = E.out(clamp01(age / 0.08));
  g2.save(); g2.globalAlpha = a; g2.drawImage(band, 0, 1060, W, 400);
  const yy = 1260 + (1 - a) * 14;
  if (cur.ben){ boldLines(cur.w.map(w => w[0]), yy, 112, 880, act, pop, '#ffffff'); g2.font = `900 34px ${SANS}`; g2.textAlign = 'center'; g2.fillStyle = '#ffd23c'; g2.strokeStyle = '#0b1220'; g2.lineWidth = 8; g2.strokeText('— BEN', W / 2, yy + 100); g2.fillText('— BEN', W / 2, yy + 100); }
  else boldLines(cur.w.map(w => w[0]), yy, 78, 880, act, pop);
  g2.restore();
}
function drawHud(h){
  if (!h) return; g2.save(); g2.textAlign = 'center'; g2.textBaseline = 'middle'; g2.lineJoin = 'round';
  const big = fitSize(h[0], 140, 880); g2.font = `900 ${big}px ${SANS}`; g2.lineWidth = 24; g2.strokeStyle = '#0b1220'; g2.strokeText(h[0], W / 2, 400); g2.fillStyle = '#ffffff'; g2.fillText(h[0], W / 2, 400);
  if (h[1]){ g2.font = `900 40px ${SANS}`; g2.lineWidth = 10; g2.strokeText(h[1], W / 2, 500); g2.fillStyle = '#ffd23c'; g2.fillText(h[1], W / 2, 500); }
  g2.restore();
}
function glowDot(x, y, r, col, a){ if (a <= 0) return; const g = g2.createRadialGradient(x, y, 0, x, y, r); g.addColorStop(0, 'rgba(255,255,255,' + Math.min(1, a) + ')'); g.addColorStop(0.25, col.replace('A', Math.min(1, a) * 0.9)); g.addColorStop(1, col.replace('A', 0)); g2.fillStyle = g; g2.fillRect(x - r, y - r, 2 * r, 2 * r); }
function wp(x, y, z){ return proj(new THREE.Vector3(x, y, z)); }
function txt(s, x, y, size, col, al){ g2.font = `900 ${size}px ${SANS}`; g2.textAlign = al || 'center'; g2.textBaseline = 'middle'; g2.lineJoin = 'round'; g2.lineWidth = size * 0.22; g2.strokeStyle = '#0b1220'; g2.strokeText(s, x, y); g2.fillStyle = col; g2.fillText(s, x, y); }
const _p = new THREE.Vector3();
function wl(o, x, y, z){ o.updateWorldMatrix(true, false); return proj(o.localToWorld(_p.set(x, y, z))); }
function along(P, f){ let L = 0; const sg = []; for (let i = 1; i < P.length; i++){ const q = Math.hypot(P[i][0] - P[i - 1][0], P[i][1] - P[i - 1][1]); sg.push(q); L += q; } let r = f * L;
  for (let i = 0; i < sg.length; i++){ if (r <= sg[i]){ const k = r / sg[i]; return [lerp(P[i][0], P[i + 1][0], k), lerp(P[i][1], P[i + 1][1], k)]; } r -= sg[i]; } return P[P.length - 1]; }
function path(P){ g2.beginPath(); g2.moveTo(P[0][0], P[0][1]); for (let i = 1; i < P.length; i++) g2.lineTo(P[i][0], P[i][1]); }
function star(x, y, r){ g2.beginPath(); for (let k = 0; k < 3; k++){ const a = k * PI / 3; g2.moveTo(x - Math.cos(a) * r, y - Math.sin(a) * r); g2.lineTo(x + Math.cos(a) * r, y + Math.sin(a) * r); } g2.stroke(); }
function flame(x, y, s, a){ g2.save(); g2.globalAlpha = a; g2.translate(x, y); const w = 1 + 0.08 * Math.sin(T * 14);
  g2.beginPath(); g2.moveTo(0, -1.1 * s * w); g2.bezierCurveTo(0.7 * s, -0.4 * s, 0.6 * s, 0.5 * s, 0, 0.55 * s); g2.bezierCurveTo(-0.6 * s, 0.5 * s, -0.7 * s, -0.4 * s, 0, -1.1 * s * w); g2.fillStyle = '#ff5a1f'; g2.fill();
  g2.beginPath(); g2.moveTo(0, -0.5 * s * w); g2.bezierCurveTo(0.35 * s, -0.1 * s, 0.3 * s, 0.4 * s, 0, 0.45 * s); g2.bezierCurveTo(-0.3 * s, 0.4 * s, -0.35 * s, -0.1 * s, 0, -0.5 * s * w); g2.fillStyle = '#ffd23c'; g2.fill(); g2.restore(); }

function chip(x, y, w, h){ g2.fillStyle = 'rgba(11,18,32,0.66)'; g2.beginPath(); g2.roundRect(x - w / 2, y - h / 2, w, h, 26); g2.fill(); }
function arrow(x1, y1, x2, y2, w, col){ const a = Math.atan2(y2 - y1, x2 - x1), hl = w * 2.2; g2.lineCap = 'round'; g2.lineJoin = 'round';
  const bx = x2 - Math.cos(a) * hl * 0.8, by = y2 - Math.sin(a) * hl * 0.8;
  for (const [lw, c] of [[w + 10, '#0b1220'], [w, col]]){ g2.lineWidth = lw; g2.strokeStyle = c; g2.beginPath(); g2.moveTo(x1, y1); g2.lineTo(bx, by); g2.stroke();
    g2.fillStyle = c; g2.beginPath(); const e = lw === w ? 0 : 6; g2.moveTo(x2 + Math.cos(a) * e, y2 + Math.sin(a) * e); g2.lineTo(bx + Math.cos(a + PI / 2) * (hl * 0.62 + e), by + Math.sin(a + PI / 2) * (hl * 0.62 + e)); g2.lineTo(bx - Math.cos(a + PI / 2) * (hl * 0.62 + e), by - Math.sin(a + PI / 2) * (hl * 0.62 + e)); g2.closePath(); g2.fill(); } }
// Gezeiten-Pfeile über dem liegenden Ben (Kopf links, Füße rechts)
function drawTidal(a){ if (a <= 0) return; g2.save(); g2.globalAlpha = a;
  [[-1.55, 0.35, '#ffffff', 'KOPF'], [-0.2, 0.8, '#ffb347', ''], [1.1, 1.7, '#ff4a3a', 'FÜSSE']].forEach(([x, L, c, l], i) => {
    const p = wp(x, 1.35, 0), q = wp(x + L * E.out(clamp01(a * 1.2 - i * 0.08)), 1.35, 0); if (!p || !q) return; arrow(p[0], p[1], Math.max(q[0], p[0] + 20), q[1], 16, c);
    if (l) txt(l, p[0] + 10, p[1] - 58, 40, c, 'left'); });
  g2.restore(); }
function drawCalm(a){ if (a <= 0) return; g2.save(); g2.globalAlpha = a; chip(W / 2, 1690, 820, 170); txt('KOPF UND FÜSSE: FAST GLEICH', W / 2, 1655, 44, '#ffffff'); txt('KEIN LANGZIEHEN – NOCH', W / 2, 1722, 36, '#ffd23c'); g2.restore(); }
function drawClock(a){ if (a <= 0) return; const cx = W / 2 - 250, cy = 1690; g2.save(); g2.globalAlpha = a; chip(W / 2, cy, 860, 220);
  g2.fillStyle = '#f4f4f8'; g2.beginPath(); g2.arc(cx, cy, 78, 0, 2 * PI); g2.fill(); g2.lineWidth = 9; g2.strokeStyle = '#0b1220'; g2.stroke();
  for (let k = 0; k < 12; k++){ const an = k / 12 * 2 * PI; g2.lineWidth = 5; g2.beginPath(); g2.moveTo(cx + Math.sin(an) * 60, cy - Math.cos(an) * 60); g2.lineTo(cx + Math.sin(an) * 70, cy - Math.cos(an) * 70); g2.stroke(); }
  const an = CLK[0]; g2.lineWidth = 9; g2.lineCap = 'round'; g2.strokeStyle = '#e0302a'; g2.beginPath(); g2.moveTo(cx, cy); g2.lineTo(cx + Math.sin(an) * 56, cy - Math.cos(an) * 56); g2.stroke();
  g2.fillStyle = '#0b1220'; g2.beginPath(); g2.arc(cx, cy, 9, 0, 2 * PI); g2.fill();
  txt('BENS UHR', cx + 330, cy - 52, 44, '#ffffff'); txt('VON AUSSEN GESEHEN', cx + 330, cy + 2, 30, '#cfd6e6');
  txt('TEMPO ' + Math.round(CLK[1] * 100) + ' %', cx + 330, cy + 56, 46, CLK[1] < 0.15 ? '#ff4a3a' : '#ffd23c'); g2.restore(); }
function bez(p0, p1, p2, n){ const o = []; for (let i = 0; i <= n; i++){ const t = i / n, u = 1 - t; o.push([u * u * p0[0] + 2 * u * t * p1[0] + t * t * p2[0], u * u * p0[1] + 2 * u * t * p1[1] + t * t * p2[1]]); } return o; }
function drawRays(a){ if (a <= 0) return; const b = wp(-1.0, 2.05, 1.6), c = wp(1.6, 2.58, 0); if (!b || !c) return; g2.save(); g2.globalAlpha = a; g2.lineCap = 'round'; g2.lineJoin = 'round';
  const R = Math.hypot(c[0] - b[0], c[1] - b[1]);
  [[-1.55, 0], [-2.15, 0.5], [1.6, 0.25], [2.2, 0.75]].forEach(([ang, off]) => {
    const d = [Math.cos(ang), Math.sin(ang)], ctl = [b[0] + d[0] * 520, b[1] + d[1] * 520], end = c;
    const P = bez(b, ctl, end, 40), f = ((T - 18.05) / 1.6 + off) % 1, n = Math.max(2, Math.round(f * 40)), Q = P.slice(0, n + 1), tail = Math.max(0, n - 26), S = P.slice(tail, n + 1);
    for (const [lw, col] of [[22, '#0b1220'], [12, '#ffe27a']]){ g2.lineWidth = lw; g2.strokeStyle = col; g2.globalAlpha = a * (f > 0.85 ? (1 - f) / 0.15 : 1); path(S); g2.stroke(); }
    const h = Q[Q.length - 1]; glowDot(h[0], h[1], 34, 'rgba(255,230,150,A)', a);
  });
  g2.restore(); }
function drawEsc(a){ if (a <= 0) return; g2.save(); g2.globalAlpha = a; chip(W / 2, 1690, 860, 180); txt('NÖTIG: SCHNELLER ALS LICHT', W / 2, 1655, 46, '#ffffff'); txt('NICHTS IST SCHNELLER → GEFANGEN', W / 2, 1722, 34, '#ff6a4a'); g2.restore(); }

function heart(x, y, s){ g2.beginPath(); g2.moveTo(x, y + 0.35 * s); g2.bezierCurveTo(x - 1.1 * s, y - 0.35 * s, x - 0.45 * s, y - 1.0 * s, x, y - 0.45 * s); g2.bezierCurveTo(x + 0.45 * s, y - 1.0 * s, x + 1.1 * s, y - 0.35 * s, x, y + 0.35 * s); g2.closePath(); }
function drawHeart(a){ if (a <= 0) return; const ph = (T * 2.5) % 1, beat = ph < 0.15 ? Math.sin(ph / 0.15 * PI) : 0, s = 70 * (1 + 0.22 * beat);
  g2.save(); g2.globalAlpha = a; heart(W / 2, 660, s); g2.fillStyle = '#ff3b3b'; g2.fill(); g2.lineWidth = 10; g2.strokeStyle = '#0b1220'; g2.stroke(); g2.restore(); }
const vig = document.createElement('canvas'); vig.width = 270; vig.height = 480;
(function(){ const x = vig.getContext('2d'), g = x.createRadialGradient(135, 240, 120, 135, 240, 330); g.addColorStop(0, 'rgba(0,0,0,0)'); g.addColorStop(1, 'rgba(0,0,0,0.38)'); x.fillStyle = g; x.fillRect(0, 0, 270, 480); })();
function draw2D(sc, lt, dur){
  g2.globalAlpha = 1; g2.globalCompositeOperation = 'source-over'; g2.drawImage(renderer.domElement, 0, 0, W, H);
  g2.globalAlpha = 1; g2.globalCompositeOperation = 'source-over'; g2.drawImage(vig, 0, 0, W, H);
  if (flashA > 0){ g2.fillStyle = `rgba(255,250,240,${Math.min(1, flashA)})`; g2.fillRect(0, 0, W, H); }
  if (fadeBlk > 0){ g2.fillStyle = `rgba(0,0,0,${fadeBlk})`; g2.fillRect(0, 0, W, H); }
  drawTidal(tidK); drawCalm(calmK); drawClock(clkK); drawRays(rayK); drawEsc(escK);
  if (sc.hud) drawHud(sc.hud());
  if (sc.hook) drawHook(clamp01((dur - lt) / 0.15), 1);
  if (sc.loopin){ const k = clamp01((T - (END - 0.14)) / 0.14); drawHook(k, 1 + 0.25 * (1 - k)); }
  if (!sc.hook) drawSubs();
}
