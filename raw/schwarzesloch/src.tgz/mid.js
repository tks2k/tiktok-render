/* =========================================================
   STIMMUNG: Weltraum (statischer Sternenhimmel)
   ========================================================= */
function sky(){
  const c = document.createElement('canvas'); c.width = 540; c.height = 960; const x = c.getContext('2d'), g = x.createLinearGradient(0, 0, 0, 960);
  g.addColorStop(0, '#03040a'); g.addColorStop(0.55, '#070a18'); g.addColorStop(1, '#0b0814'); x.fillStyle = g; x.fillRect(0, 0, 540, 960);
  [[120, 260, 260, 'rgba(70,60,140,0.16)'], [430, 640, 300, 'rgba(140,60,90,0.12)'], [300, 120, 200, 'rgba(50,90,150,0.12)']].forEach(([px, py, r, cc]) => { const n = x.createRadialGradient(px, py, 0, px, py, r); n.addColorStop(0, cc); n.addColorStop(1, 'rgba(0,0,0,0)'); x.fillStyle = n; x.fillRect(0, 0, 540, 960); });
  let sd = 11; const r = () => { sd = (sd * 16807) % 2147483647; return sd / 2147483647; };
  for (let i = 0; i < 260; i++){ const px = r() * 540, py = r() * 960, s = 0.7 + r() * 1.5; x.globalAlpha = 0.3 + 0.55 * r(); x.fillStyle = r() < 0.2 ? '#ffe9c8' : '#ffffff'; x.beginPath(); x.arc(px, py, s, 0, 7); x.fill(); }
  x.globalAlpha = 1; const t = new THREE.CanvasTexture(c); t.encoding = THREE.sRGBEncoding; return t;
}
const MOOD = { space: { sky: sky(), fog: [0x000000, 900, 3000], hemi: [0x7080b0, 0x141420, 0.55], sun: [0xffb878, 1.35], sp: [9, 4, 9] } };
const SR = 12; { const c = sun.shadow.camera; c.left = -SR; c.right = SR; c.top = SR; c.bottom = -SR; c.near = 1; c.far = 90; c.updateProjectionMatrix(); }
function setMood(m){
  scene.background = m.sky; scene.fog.color.set(m.fog[0]); scene.fog.near = m.fog[1]; scene.fog.far = m.fog[2]; scene.environment = envNight;
  hemi.color.set(m.hemi[0]); hemi.groundColor.set(m.hemi[1]); hemi.intensity = m.hemi[2]; sun.color.set(m.sun[0]); sun.intensity = m.sun[1];
  sun.position.set(m.sp[0], m.sp[1], m.sp[2]); sun.target.position.set(0, 0, 0); fill.color.set(0xb8c8ff); fill.intensity = 0.45; fill.position.set(-12, 6, 14);
}

/* =========================================================
   SCHWARZE LÖCHER (Kugel + Photonenring + Akkretionsscheibe)
   ========================================================= */
function radTex(stops, sz){ const c = document.createElement('canvas'); c.width = c.height = sz; const x = c.getContext('2d'), g = x.createRadialGradient(sz / 2, sz / 2, 0, sz / 2, sz / 2, sz / 2);
  stops.forEach(s => g.addColorStop(s[0], s[1])); x.fillStyle = g; x.fillRect(0, 0, sz, sz); return x; }
const DISKX = radTex([[0, 'rgba(0,0,0,0)'], [0.4, 'rgba(0,0,0,0)'], [0.43, 'rgba(255,250,225,1)'], [0.52, 'rgba(255,200,110,0.95)'], [0.68, 'rgba(255,120,50,0.6)'], [0.85, 'rgba(190,50,40,0.22)'], [1, 'rgba(120,20,30,0)']], 512);
(function(){ let sd = 3; const r = () => { sd = (sd * 16807) % 2147483647; return sd / 2147483647; }; DISKX.globalCompositeOperation = 'destination-out';
  for (let i = 0; i < 7; i++){ const a = i / 7 * 2 * PI + r() * 0.5, rr = 256 * (0.55 + r() * 0.3), px = 256 + Math.cos(a) * rr, py = 256 + Math.sin(a) * rr, q = 70 + r() * 40, g = DISKX.createRadialGradient(px, py, 0, px, py, q);
    g.addColorStop(0, 'rgba(0,0,0,0.45)'); g.addColorStop(1, 'rgba(0,0,0,0)'); DISKX.fillStyle = g; DISKX.fillRect(px - q, py - q, 2 * q, 2 * q); } })();
const DISKT = new THREE.CanvasTexture(DISKX.canvas);
const HALOT = new THREE.CanvasTexture(radTex([[0, 'rgba(0,0,0,0)'], [0.6, 'rgba(0,0,0,0)'], [0.625, 'rgba(255,245,220,1)'], [0.66, 'rgba(255,190,110,0.75)'], [0.75, 'rgba(255,120,60,0.28)'], [0.9, 'rgba(160,50,60,0.08)'], [1, 'rgba(0,0,0,0)']], 512).canvas);
const BLK = new THREE.MeshBasicMaterial({ color: 0x000000, fog: false });
function makeBH(disk){
  const G = new THREE.Group(); const s = new THREE.Mesh(new THREE.SphereGeometry(1, 48, 32), BLK); s.renderOrder = 1; G.add(s);
  const h = new THREE.Sprite(new THREE.SpriteMaterial({ map: HALOT, blending: THREE.AdditiveBlending, depthWrite: false, fog: false, transparent: true })); h.scale.set(3.2, 3.2, 1); h.renderOrder = 2; G.add(h);
  if (disk){ const d = new THREE.Mesh(new THREE.RingGeometry(1.25, 2.9, 96, 1), new THREE.MeshBasicMaterial({ map: DISKT, blending: THREE.AdditiveBlending, depthWrite: false, fog: false, transparent: true, side: THREE.DoubleSide }));
    d.rotation.order = 'XYZ'; d.rotation.x = -PI / 2 + 0.26; d.renderOrder = 3; G.add(d); G.userData.disk = d; }
  scene.add(G); return G;
}
const BHM = makeBH(1), BHS = makeBH(1), BHG = makeBH(0);
function bhVis(m, s, g){ BHM.visible = !!m; BHS.visible = !!s; BHG.visible = !!g; }
function bhAt(G, x, y, z, r){ G.position.set(x, y, z); G.scale.setScalar(r); if (G.userData.disk) G.userData.disk.rotation.z = -dT * 0.35; }
const SPACE = new THREE.Group(); scene.add(SPACE); const SETS = [SPACE];

/* =========================================================
   BEN (Narbe, eigene Materialien für Rotverschiebung)
   ========================================================= */
const SCAR = new THREE.Group(); ben.head.add(SCAR);
(function(){ const m = mat(0xa8463f, { roughness: 0.7 }); const s = new THREE.Mesh(rbox(0.075, 0.72, 0.03, 0.012, 1), m); s.position.set(0.25, 0.55, 0.522); s.rotation.z = -0.13; SCAR.add(s);
  for (const y of [0.36, 0.55, 0.74]){ const c = new THREE.Mesh(rbox(0.16, 0.035, 0.03, 0.01, 1), m); c.position.set(0.25 + (y - 0.55) * 0.13, y, 0.528); c.rotation.z = -0.13; SCAR.add(c); } })();
const BMAT = []; ben.root.traverse(o => { if (o.isMesh){ o.material = o.material.clone(); o.material.userData.c0 = o.material.color.clone(); o.material.userData.e0 = o.material.envMapIntensity; BMAT.push(o.material); } });
const REDC = new THREE.Color(0xc0201a);
function benTint(k, dim){ BMAT.forEach(m => { m.color.copy(m.userData.c0).lerp(REDC, k).multiplyScalar(1 - dim); m.envMapIntensity = m.userData.e0 * (1 - dim); }); }
function floatPose(r, t, w){ w = w === undefined ? 1 : w; const a = Math.sin(t * 1.3), b = Math.sin(t * 1.1 + 1);
  r.sh[0].rotation.set(0.25 * a * w, 0, -0.75 - 0.12 * b * w); r.sh[1].rotation.set(-0.25 * a * w, 0, 0.75 + 0.12 * b * w); r.el[0].rotation.set(-0.35, 0, 0); r.el[1].rotation.set(-0.35, 0, 0);
  r.legs[0].rotation.set(0.18 * b * w, 0, -0.1); r.legs[1].rotation.set(-0.18 * b * w, 0, 0.1); r.torso.rotation.x = 0.04 * a; r.head.rotation.x = -0.05; }

/* =========================================================
   KAMERA + Zustand
   ========================================================= */
const cL = new THREE.Vector3();
let blurAmt = 0, fadeBlk = 0, T = 0, flashA = 0, eyeS = 1, talk = 0, dT = 0;
let tidK = 0, clkK = 0, rayK = 0, escK = 0, calmK = 0, CLK = [0, 1], BENP = null;
function camW(p, a, b){ cam.position.set(lerp(a[0], b[0], p), lerp(a[1], b[1], p), lerp(a[2], b[2], p)); cL.set(lerp(a[3], b[3], p), lerp(a[4], b[4], p), lerp(a[5], b[5], p)); cam.fov = lerp(a[6], b[6], p); }
function camFin(sh){ cam.position.x += Math.sin(dT * 0.7) * 0.012; cam.position.y += Math.sin(dT * 0.9 + 1) * 0.008; if (sh){ cam.position.x += Math.sin(T * 23) * sh; cam.position.y += Math.cos(T * 17) * sh; } cam.up.set(0, 1, 0); cam.lookAt(cL); cam.updateProjectionMatrix(); cam.updateMatrixWorld(); }
const HOOK = [[0.9, 2.79, 16.7, 0.9, 2.79, 0, 40], [0.8, 2.7, 15.6, 0.8, 2.7, 0, 40]];
const C2 = [1.0, -1.3, 21, 1.0, -1.3, 0, 40], C3 = [1.4, -1.6, 25.5, 1.4, -1.6, 0, 40];
const C4 = [0, 0.9, 13.4, 0, 0.9, 0, 40], C4b = [0, 0.85, 12.4, 0, 0.85, 0, 40];
const C5 = [0, 0, 34, 0, 0, 0, 40], C6 = [-0.6, 0.4, 30, -0.6, 0.4, 0, 40];
function base(){ show(ben); ben.root.scale.set(1, 1, 1); }
function hookBH(){ bhVis(1, 0, 0); bhAt(BHM, 5.6, 1.93, -40, 4.3); }
function hookBen(t){ bRest(ben, t, 0); place(ben, 0, 0.12 * Math.sin(t * 1.4), 0, 0.25); floatPose(ben, t); ben.root.rotation.z = 0.06 * Math.sin(t * 0.9); eyeS = 1; bFace(ben, -0.3, 0.12); }
// horizontal liegender Ben, Füße zeigen nach +x (Richtung Loch)
function lieBen(x, y, z, t, w){ bRest(ben, t, 0); place(ben, x, y, z, 0); ben.root.rotation.z = PI / 2; floatPose(ben, t, w); }

/* =========================================================
   SZENEN (Sprecherspur Tempo 1,2)
   ========================================================= */
const SCN = [
  { t: 0, set: SPACE, mood: MOOD.space, hook: 1,
    upd(lt){ dT = T; base(); hookBH(); hookBen(T); camW(E.io(seg(lt, 0, 2.35)), HOOK[0], HOOK[1]); camFin(); } },
  { t: 2.35, set: SPACE, mood: MOOD.space, hud: () => ['KLEINES LOCH', 'AN DEN FÜSSEN ZIEHT ES STÄRKER'],
    upd(lt){ dT = T; base(); bhVis(0, 1, 0); bhAt(BHS, 4.4, 0, 0, 0.38); lieBen(1.5, 0.05 * Math.sin(T * 1.2), 0, T, 0.6); eyeS = 1.2; bFace(ben, -0.6, 0.25);
      tidK = E.out(seg(T, 2.7, 3.1)) * (1 - seg(T, 6.5, 6.8)); camW(0, C2, C2); camFin(); } },
  { t: 6.4, set: SPACE, mood: MOOD.space, hud: () => ['SPAGHETTIFIZIERUNG', 'LANGGEZOGEN WIE EINE NUDEL'],
    upd(lt){ dT = T; base(); bhVis(0, 1, 0); bhAt(BHS, 4.4, 0, 0, 0.38); const k = E.io(seg(T, 6.5, 9.7)), sy = 1 + 0.9 * k, sx = 1 / Math.sqrt(sy);
      lieBen(1.5 + 1.95 * (sy - 1), 0.05 * Math.sin(T * 1.2), 0, T, 0.6 + 0.6 * k); ben.root.scale.set(sx, sy, sx); eyeS = 1.35; bFace(ben, -0.9, 0.35 + 0.4 * k);
      tidK = 1 - seg(T, 6.5, 6.8); camW(E.io(seg(T, 6.6, 10.2)), C2, C3); camFin(); } },
  { t: 10.45, set: SPACE, mood: MOOD.space, hud: () => ['RIESIGES LOCH', 'AM RAND: ERSTMAL NICHTS'],
    upd(lt){ dT = T; base(); bhVis(0, 0, 1); bhAt(BHG, 0, -483, -341, 400); bRest(ben, T, 0); place(ben, 0, 0.3 - 0.22 * lt, 0, -0.15); floatPose(ben, T * 0.6, 0.7);
      ben.root.rotation.z = 0.05 * Math.sin(T * 0.8); eyeS = 1; bFace(ben, 0.45, 0.04); calmK = E.out(seg(T, 10.9, 11.2)) * (1 - seg(T, 13.5, 13.75));
      camW(E.io(seg(lt, 0, 3.33)), C4, C4b); camFin(); } },
  { t: 13.78, set: SPACE, mood: MOOD.space, hud: () => T < 16.5 ? ['VON AUSSEN', 'IMMER LANGSAMER UND RÖTER'] : ['EINGEFROREN', 'AM RAND DES LOCHS'],
    upd(lt){ dT = T; base(); bhVis(1, 0, 0); bhAt(BHM, 1.6, 2.58, 0, 2.2); const u = T - 13.78, ph = 3 * (1 - Math.exp(-0.9 * u)) / 0.9;
      lieBen(-1.05 - 6.2 * Math.exp(-1.05 * u), 2.05, 1.6, 13.78 + ph, 1 - seg(u, 0.5, 3.5)); eyeS = 1.3; bFace(ben, -0.7, 0.3);
      benTint(0.85 * E.io(seg(u, 0.4, 3.6)), 0.55 * E.io(seg(u, 1.4, 4.0))); CLK = [ph * 2.2, Math.exp(-0.9 * u)];
      clkK = E.out(seg(T, 14.0, 14.3)) * (1 - seg(T, 17.7, 17.93)); camW(0, C5, C5); camFin(); } },
  { t: 17.93, set: SPACE, mood: MOOD.space, hud: () => ['KEIN WEG ZURÜCK', 'NICHT MAL LICHT KOMMT RAUS'],
    upd(lt){ dT = T; base(); bhVis(1, 0, 0); bhAt(BHM, 1.6, 2.58, 0, 2.2); const ph = 3 / 0.9;
      lieBen(-1.05, 2.05, 1.6, 13.78 + ph, 0); eyeS = 1.3; bFace(ben, -0.7, 0.3); benTint(0.85, 0.55);
      rayK = E.out(seg(T, 18.05, 18.35)) * (1 - seg(T, 20.9, 21.13)); escK = E.out(seg(T, 19.1, 19.4)) * (1 - seg(T, 20.9, 21.13));
      camW(E.io(seg(lt, 0, 3.2)), C5, C6); camFin(); } },
  { t: 21.13, set: SPACE, mood: MOOD.space, hud: () => ['UND BEN?', 'NÄCHSTES LOCH …'],
    upd(lt){ dT = T - END; base(); hookBH(); hookBen(T - END); camW(E.io(seg(T, 21.13, 23.05)), [3.4, 3.4, 19.5, 1.2, 2.6, 0, 40], HOOK[0]); camFin(); } },
  { t: 23.1, set: SPACE, mood: MOOD.space, loopin: 1,
    upd(lt){ dT = T - END; base(); hookBH(); hookBen(T - END); camW(0, HOOK[0], HOOK[1]); camFin(); } },
];
const SUBS = __SUBS__;
