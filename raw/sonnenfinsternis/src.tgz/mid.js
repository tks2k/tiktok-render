/* =========================================================
   STIMMUNG: Wiese, Himmel dunkelt während der Finsternis ab
   ========================================================= */
const BG = new THREE.Color(0x5a9ad8), CDAY = new THREE.Color(0x5a9ad8), CDIM = new THREE.Color(0x2a3e66);
const MOOD = { ecl: { fog: [0x5a9ad8, 60, 220], hemi: [0xe8f3ff, 0x5a6a40, 0.8], sun: [0xfff2dc, 1.1] } };
const SR = 14; { const c = sun.shadow.camera; c.left = -SR; c.right = SR; c.top = SR; c.bottom = -SR; c.near = 1; c.far = 120; c.updateProjectionMatrix(); }
function setMood(m){
  scene.background = BG; scene.fog.color.set(m.fog[0]); scene.fog.near = m.fog[1]; scene.fog.far = m.fog[2]; scene.environment = envDay;
  hemi.color.set(m.hemi[0]); hemi.groundColor.set(m.hemi[1]); hemi.intensity = m.hemi[2]; sun.color.set(m.sun[0]); sun.intensity = m.sun[1];
  sun.position.set(-8, 30, -40); sun.target.position.set(0, 0, 0); fill.color.set(0xffffff); fill.intensity = 0.3; fill.position.set(10, 8, 20);
}
// d: Verdunkelung 0..1
function dim(d){ BG.copy(CDAY).lerp(CDIM, d); scene.background = BG; scene.fog.color.copy(BG); hemi.intensity = 0.8 - 0.4 * d; sun.intensity = 1.1 - 0.75 * d; }

/* =========================================================
   SET: Wiese mit Hügel, Bäume, Sonne + Mond am Himmel (Blickrichtung -z, hoch)
   ========================================================= */
const MEAD = new THREE.Group(); scene.add(MEAD); const SETS = [MEAD];
(function(){
  const g = new THREE.Mesh(new THREE.PlaneGeometry(300, 300), mat(0x5f9a45, { roughness: 1 })); g.rotation.x = -PI / 2; g.receiveShadow = true; MEAD.add(g);
  const hm = mat(0x4f8a3a, { roughness: 1, flatShading: true }); [[-30, -60, 18], [20, -70, 22], [60, -50, 14]].forEach(([x, z, r]) => { const h = new THREE.Mesh(new THREE.SphereGeometry(r, 16, 10), hm); h.position.set(x, -r * 0.55, z); h.scale.y = 0.6; MEAD.add(h); });
  const tr = mat(0x5a3e28), lf = mat(0x2f6b34, { roughness: 0.9, flatShading: true });
  for (let i = 0; i < 18; i++){ const x = -40 + i * 5 + hsh(i) * 3, z = -14 - hsh(i + 2) * 16; P(MEAD, new THREE.CylinderGeometry(0.25, 0.35, 3, 6), tr, x, 1.5, z); P(MEAD, new THREE.DodecahedronGeometry(1.8 + hsh(i) * 0.8, 0), lf, x, 3.8, z); }
  const fl = [mat(0xf2e24a), mat(0xf2f2f2), mat(0xd85ab8)]; for (let i = 0; i < 90; i++) P(MEAD, new THREE.SphereGeometry(0.07, 6, 4), fl[i % 3], (hsh(i * 3) - 0.5) * 20, 0.08, (hsh(i * 5) - 0.5) * 14);
})();
const SKY = new THREE.Group(); MEAD.add(SKY); SKY.position.set(-6, 34, -70);
const SUND = new THREE.Mesh(new THREE.CircleGeometry(4, 48), new THREE.MeshBasicMaterial({ color: 0xfff6c8, fog: false })); SKY.add(SUND);
const SGLOW = new THREE.Mesh(new THREE.CircleGeometry(9, 48), new THREE.MeshBasicMaterial({ color: 0xffe8a0, transparent: true, opacity: 0.35, fog: false, depthWrite: false, blending: THREE.AdditiveBlending })); SGLOW.position.z = -0.1; SKY.add(SGLOW);
const MOON = new THREE.Mesh(new THREE.CircleGeometry(4.05, 48), new THREE.MeshBasicMaterial({ color: 0x1a2030, fog: false })); MOON.position.z = 0.1; SKY.add(MOON);
// c: Bedeckung 0..0.99 → Mond schiebt sich von rechts vor die Sonne
function cover(c){ MOON.position.x = 8.1 * (1 - c) + 0.08; SGLOW.material.opacity = 0.35 * (1 - 0.8 * c); }
SKY.lookAt(new THREE.Vector3(0, 2, 6));

/* =========================================================
   BEN: Narbe, Sonnenbrille, Finsternisbrille; Zuschauer
   ========================================================= */
const SCAR = new THREE.Group(); ben.head.add(SCAR);
(function(){ const m = mat(0xa8463f, { roughness: 0.7 }); const s = new THREE.Mesh(rbox(0.075, 0.72, 0.03, 0.012, 1), m); s.position.set(0.25, 0.55, 0.522); s.rotation.z = -0.13; SCAR.add(s);
  for (const y of [0.36, 0.55, 0.74]){ const c = new THREE.Mesh(rbox(0.16, 0.035, 0.03, 0.01, 1), m); c.position.set(0.25 + (y - 0.55) * 0.13, y, 0.528); c.rotation.z = -0.13; SCAR.add(c); } })();
const SUNG = new THREE.Group(); ben.head.add(SUNG); const ECG = new THREE.Group(); ben.head.add(ECG);
(function(){ const k = mat(0x101014, { roughness: 0.2, metalness: 0.5 }); [-1, 1].forEach(s => P(SUNG, rbox(0.38, 0.24, 0.05, 0.06), k, s * 0.25, 0.58, 0.56)); P(SUNG, rbox(0.95, 0.05, 0.05, 0.02, 1), k, 0, 0.66, 0.56);
  const cb = mat(0xf2f2f2, { roughness: 0.9 }), bk = mat(0x050505, { roughness: 0.3, metalness: 0.4 }); P(ECG, rbox(1.05, 0.36, 0.04, 0.03), cb, 0, 0.58, 0.56); [-1, 1].forEach(s => P(ECG, rbox(0.34, 0.2, 0.02, 0.02, 1), bk, s * 0.25, 0.58, 0.585));
  const lab = mat(0xf2c21a); P(ECG, rbox(0.12, 0.08, 0.02, 0.01, 1), lab, 0, 0.71, 0.585); })();
const PALS = []; [[0x3cae6a, 0x8a5a2a, -3.2, -1.5], [0xe0483c, 0x1a1a1a, 3.4, -2.0]].forEach(([top, hair, x, z]) => { const p = boxer({ top, pants: 0x1f2a44, shoe: 0x1c1c22, hair, skin: 0xf2c6a2 }); ALL.push(p); scene.add(p.root); p.userData = { x, z }; PALS.push(p); });
function lookUp(r, k){ r.head.rotation.x = -0.55 * k; r.torso.rotation.x = -0.08 * k; }

/* =========================================================
   KAMERA + Zustand
   ========================================================= */
const cL = new THREE.Vector3();
let blurAmt = 0, fadeBlk = 0, T = 0, flashA = 0, eyeS = 1, talk = 0, dT = 0;
let pctK = 0, pctV = 0, eyeK = 0, burnK = 0, painK = 0, spotK = 0, sgK = 0, okK = 0;
function camW(p, a, b){ cam.position.set(lerp(a[0], b[0], p), lerp(a[1], b[1], p), lerp(a[2], b[2], p)); cL.set(lerp(a[3], b[3], p), lerp(a[4], b[4], p), lerp(a[5], b[5], p)); cam.fov = lerp(a[6], b[6], p); }
function camFin(sh){ cam.position.x += Math.sin(dT * 0.7) * 0.03; cam.position.y += Math.sin(dT * 0.9 + 1) * 0.02; if (sh){ cam.position.x += Math.sin(T * 23) * sh; cam.position.y += Math.cos(T * 17) * sh; } cam.up.set(0, 1, 0); cam.lookAt(cL); cam.updateProjectionMatrix(); cam.updateMatrixWorld(); }
const HOOK = [[2.0, 1.6, 6.4, -0.6, 3.6, -4.0, 56], [1.9, 1.6, 6.2, -0.6, 3.7, -4.0, 56]];
function base(){ show(ben, PALS[0], PALS[1]); SUNG.visible = false; ECG.visible = false; PALS.forEach((p, i) => { bRest(p, T, 0); place(p, p.userData.x, 0, p.userData.z, 0.25 * (i ? -1 : 1)); lookUp(p, 1); }); PALS.forEach(p => { p.sh[0].rotation.set(-1.5, 0, 0.1); p.el[0].rotation.x = -1.6; }); }
// Hook: Ben blinzelt ungeschützt in die Sonne (Bedeckung wächst)
function hookBen(t){ const c = 0.85 + 0.14 * seg(t, -0.4, 4.9); cover(c); dim(0.35 + 0.4 * seg(t, -0.4, 4.9)); bRest(ben, t, 0); place(ben, 0, 0, 0, 0); lookUp(ben, 1); eyeS = 0.55 + 0.1 * Math.sin(t * 3); bFace(ben, 0.2, 0.15); ben.sh[1].rotation.set(-2.4, 0, -0.35); ben.el[1].rotation.x = -0.9; }

/* =========================================================
   SZENEN (Sprecherspur Tempo 1,0)
   ========================================================= */
const SCN = [
  { t: 0, set: MEAD, mood: MOOD.ecl, hook: 1,
    upd(lt){ dT = T; base(); hookBen(T); camW(E.io(seg(lt, 0, 4.96)), HOOK[0], [1.5, 1.7, 5.4, -0.8, 4.0, -4.0, 54]); camFin(); } },
  { t: 4.96, set: MEAD, mood: MOOD.ecl, hud: () => T < 7.7 ? ['99 % VERDECKT', 'TROTZDEM GEFÄHRLICH'] : ['NETZHAUT', 'VERBRENNT'],
    upd(lt){ dT = T; base(); cover(0.99); dim(0.75); bRest(ben, T, 0); place(ben, 0, 0, 0, 0); lookUp(ben, 1); eyeS = 0.6; bFace(ben, 0.1, 0.1);
      pctK = E.out(seg(T, 5.2, 5.5)) * (1 - seg(T, 7.5, 7.7)); pctV = 99 * E.out(seg(T, 5.3, 6.3)); eyeK = E.out(seg(T, 7.7, 8.0)) * (1 - seg(T, 10.4, 10.58)); burnK = seg(T, 8.6, 9.6);
      camW(E.io(seg(lt, 0, 5.62)), [0.6, 2.0, 2.6, -6, 34, -70, 20], [0.6, 2.0, 2.6, -6, 34, -70, 14]); camFin(); } },
  { t: 10.58, set: MEAD, mood: MOOD.ecl, hud: () => T < 14.0 ? ['KEIN SCHMERZ', 'NETZHAUT HAT KEINE SCHMERZNERVEN'] : ['STUNDEN SPÄTER', 'DUNKLER FLECK IM BILD'],
    upd(lt){ dT = T; base(); cover(T < 14.0 ? 0.99 : 0); dim(T < 14.0 ? 0.75 : 0); bRest(ben, T, 0); place(ben, 0, 0, 0, T < 14.0 ? 0 : 0.4); lookUp(ben, T < 14.0 ? 1 : 0); eyeS = T < 14.0 ? 0.7 : 1.1; bFace(ben, T < 14.0 ? 0.6 : -0.6, 0.15);
      painK = E.out(seg(T, 10.8, 11.1)) * (1 - seg(T, 13.85, 14.0)); spotK = 0.85 * seg(T, 14.6, 16.0) * (1 - seg(T, 16.9, 17.16));
      camW(E.io(seg(lt, 0, 6.58)), [2.6, 2.4, 5.4, 0, 2.6, 0, 46], [2.0, 2.3, 4.6, 0, 2.6, 0, 44]); camFin(); } },
  { t: 17.16, set: MEAD, mood: MOOD.ecl, hud: () => ['SONNENBRILLE?', 'HILFT NICHT!'],
    upd(lt){ dT = T; base(); cover(0.97); dim(0.7); bRest(ben, T, 0); place(ben, 0, 0, 0, 0.15); SUNG.visible = true; lookUp(ben, 0.6); eyeS = 1; bFace(ben, 0.3, 0.1);
      sgK = E.out(seg(T, 17.4, 17.7)) * (1 - seg(T, 19.3, 19.44));
      camW(E.io(seg(lt, 0, 2.28)), [1.6, 2.6, 4.2, 0, 2.9, 0, 40], [1.3, 2.6, 3.8, 0, 2.9, 0, 40]); camFin(); } },
  { t: 19.44, set: MEAD, mood: MOOD.ecl, hud: () => ['UND BEN?', 'MIT ECHTER FINSTERNISBRILLE'],
    upd(lt){ dT = T; base(); cover(0.97); dim(0.7); bRest(ben, T, 0); place(ben, 0, 0, 0, 0.1); ECG.visible = true; lookUp(ben, 1); eyeS = 1; bFace(ben, 1, 0.2); ben.sh[0].rotation.set(-1.4, 0, 0.3); ben.el[0].rotation.x = -1.2;
      okK = E.out(seg(T, 20.3, 20.6)) * (1 - seg(T, 22.2, 22.35));
      camW(E.io(seg(lt, 0, 2.91)), [2.4, 2.0, 5.4, -0.3, 3.0, -2.0, 50], [2.2, 1.9, 5.0, -0.3, 3.1, -2.0, 50]); camFin(); } },
  { t: 22.35, set: MEAD, mood: MOOD.ecl, loopin: 1,
    upd(lt){ dT = T - END; base(); hookBen(T - END); camW(0, HOOK[0], HOOK[1]); camFin(); } },
];
const SUBS = __SUBS__;
