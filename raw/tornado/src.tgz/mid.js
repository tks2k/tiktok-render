/* =========================================================
   STIMMUNG: Gewitterhimmel (grünlich-grau) + Keller
   ========================================================= */
function sky(a, b, c){
  const cv = document.createElement('canvas'); cv.width = 4; cv.height = 512; const x = cv.getContext('2d'), g = x.createLinearGradient(0, 0, 0, 512);
  g.addColorStop(0, a); g.addColorStop(0.6, b); g.addColorStop(1, c); x.fillStyle = g; x.fillRect(0, 0, 4, 512);
  const t = new THREE.CanvasTexture(cv); t.encoding = THREE.sRGBEncoding; return t;
}
const MOOD = {
  storm: { sky: sky('#1e2420', '#4a564c', '#7d8a78'), fog: [0x56604f, 45, 170], hemi: [0xa8b2a4, 0x4a4a38, 0.95], sun: [0xdfe4d4, 0.7], sp: [8, 18, 10], fl: 0.35 },
  cel: { sky: sky('#0c0a08', '#161210', '#1e1814'), fog: [0x16120e, 30, 80], hemi: [0x9a8a78, 0x2a2018, 0.7], sun: [0xffd8a0, 0.45], sp: [3, 12, 6], fl: 0.3 },
};
const SR = 14; { const c = sun.shadow.camera; c.left = -SR; c.right = SR; c.top = SR; c.bottom = -SR; c.near = 1; c.far = 70; c.updateProjectionMatrix(); }
function setMood(m){
  scene.background = m.sky; scene.fog.color.set(m.fog[0]); scene.fog.near = m.fog[1]; scene.fog.far = m.fog[2]; scene.environment = envNight;
  hemi.color.set(m.hemi[0]); hemi.groundColor.set(m.hemi[1]); hemi.intensity = m.hemi[2]; sun.color.set(m.sun[0]); sun.intensity = m.sun[1];
  sun.position.set(m.sp[0], m.sp[1], m.sp[2]); sun.target.position.set(0, 0, 0); fill.color.set(0xffffff); fill.intensity = m.fl; fill.position.set(-4, 6, 10);
}

/* =========================================================
   SET 1: Feld mit Haus, Zaun, Sturmkeller-Luke, Tornado
   ========================================================= */
const FIELD = new THREE.Group(); scene.add(FIELD);
const CELLAR = new THREE.Group(); scene.add(CELLAR); const SETS = [FIELD, CELLAR];
(function(){
  const gr = new THREE.Mesh(new THREE.PlaneGeometry(500, 500), mat(0x5d6b3a, { roughness: 1 })); gr.rotation.x = -PI / 2; gr.receiveShadow = true; FIELD.add(gr);
  const dirt = mat(0x6b5a3e, { roughness: 1 }); for (let i = 0; i < 26; i++){ const t = P(FIELD, rbox(0.5 + hsh(i) * 0.6, 0.08, 0.3 + hsh(i + 3) * 0.4, 0.02, 1), dirt, -16 + hsh(i + 7) * 32, 0.03, -14 + hsh(i + 11) * 26); t.rotation.y = hsh(i + 2) * 3; }
  // Haus mit Fenstern
  const H = new THREE.Group(); H.position.set(-9, 0, -7); FIELD.add(H);
  P(H, rbox(6, 3.6, 5, 0.05), mat(0xd2c2a2, { roughness: 0.9 }), 0, 1.8, 0); const rf = mat(0x7a3a2a, { roughness: 0.8 });
  const r1 = P(H, rbox(6.6, 0.2, 3.3, 0.04), rf, 0, 4.3, 1.25); r1.rotation.x = 0.62; const r2 = P(H, rbox(6.6, 0.2, 3.3, 0.04), rf, 0, 4.3, -1.25); r2.rotation.x = -0.62;
  const gl = mat(0x2a4a66, { roughness: 0.15, metalness: 0.3 }), fr = mat(0xf2efe6);
  [[-1.8, 2.1], [1.8, 2.1]].forEach(([x, y]) => { P(H, rbox(1.3, 1.2, 0.08, 0.02, 1), fr, x, y, 2.52); P(H, rbox(1.1, 1.0, 0.06, 0.01, 1), gl, x, y, 2.56); });
  P(H, rbox(1.0, 2.0, 0.08, 0.02, 1), mat(0x5a3a22), 0, 1.0, 2.52);
  // Zaun
  const wd = mat(0x8a6a44, { roughness: 0.9 }); for (let i = 0; i < 9; i++) P(FIELD, rbox(0.18, 1.2, 0.18, 0.03, 1), wd, 4 + i * 2, 0.6, -4);
  P(FIELD, rbox(16.4, 0.12, 0.08, 0.02, 1), wd, 12, 0.95, -4); P(FIELD, rbox(16.4, 0.12, 0.08, 0.02, 1), wd, 12, 0.5, -4);
  // Baum
  P(FIELD, new THREE.CylinderGeometry(0.25, 0.35, 3, 8), mat(0x5a4030), 11, 1.5, -10); P(FIELD, new THREE.IcosahedronGeometry(2.2, 0), mat(0x3e5a2e, { flatShading: true }), 11, 4.2, -10);
})();
// Sturmkeller-Luke bei (4, 0, 3): Betonrahmen, dunkle Öffnung, zwei Türflügel
const HATCH = new THREE.Group(); HATCH.position.set(4, 0, 3); FIELD.add(HATCH);
const DOORL = new THREE.Group(), DOORR = new THREE.Group();
(function(){ const cn = mat(0x8a8a84, { roughness: 1 });
  P(HATCH, rbox(2.8, 0.34, 0.3, 0.03, 1), cn, 0, 0.17, -1.15); P(HATCH, rbox(2.8, 0.34, 0.3, 0.03, 1), cn, 0, 0.17, 1.15); P(HATCH, rbox(0.3, 0.34, 2.6, 0.03, 1), cn, -1.25, 0.17, 0); P(HATCH, rbox(0.3, 0.34, 2.6, 0.03, 1), cn, 1.25, 0.17, 0);
  const hole = new THREE.Mesh(new THREE.PlaneGeometry(2.2, 2.0), new THREE.MeshBasicMaterial({ color: 0x07070a })); hole.rotation.x = -PI / 2; hole.position.y = 0.02; HATCH.add(hole);
  const dm = mat(0x6a4a2a, { roughness: 0.85 }), bm = mat(0x3a3a3a, { metalness: 0.6, roughness: 0.4 });
  DOORL.position.set(-1.1, 0.36, 0); DOORR.position.set(1.1, 0.36, 0); HATCH.add(DOORL, DOORR);
  P(DOORL, rbox(1.1, 0.1, 2.0, 0.02, 1), dm, 0.55, 0, 0); P(DOORL, rbox(0.12, 0.12, 0.3, 0.03, 1), bm, 0.85, 0.08, 0);
  P(DOORR, rbox(1.1, 0.1, 2.0, 0.02, 1), dm, -0.55, 0, 0); P(DOORR, rbox(0.12, 0.12, 0.3, 0.03, 1), bm, -0.85, 0.08, 0);
})();
function doors(k){ DOORL.rotation.z = 1.85 * k; DOORR.rotation.z = -1.85 * k; }

// Tornado: zwei gedrehte Trichter-Schichten + Staubwalze + Wolkendecke
const STRK = (function(){ const c = document.createElement('canvas'); c.width = 256; c.height = 256; const x = c.getContext('2d'); x.fillStyle = '#80857c'; x.fillRect(0, 0, 256, 256);
  let sd = 9; const r = () => { sd = (sd * 16807) % 2147483647; return sd / 2147483647; };
  for (let i = 0; i < 90; i++){ const y = r() * 256, h = 2 + r() * 7, l = 40 + r() * 140, px = r() * 256; x.fillStyle = r() < 0.5 ? 'rgba(40,44,40,0.5)' : 'rgba(200,205,196,0.45)'; x.save(); x.translate(px, y); x.rotate(-0.25); x.fillRect(-l / 2, 0, l, h); x.fillRect(-l / 2 + 256, 0, l, h); x.fillRect(-l / 2 - 256, 0, l, h); x.restore(); }
  const t = new THREE.CanvasTexture(c); t.encoding = THREE.sRGBEncoding; t.wrapS = t.wrapT = THREE.RepeatWrapping; t.repeat.set(3, 2); return t; })();
const STRK2 = STRK.clone(); STRK2.needsUpdate = true; STRK2.repeat.set(2, 1.5);
const TOR = new THREE.Group(); FIELD.add(TOR);
(function(){ const pts = []; for (let i = 0; i <= 24; i++){ const y = i * 1.75; pts.push(new THREE.Vector2(0.9 + 0.0042 * y * y + 0.6 * Math.max(0, 1 - y / 3), y)); }
  const g = new THREE.LatheGeometry(pts, 40);
  TOR.add(new THREE.Mesh(g, new THREE.MeshStandardMaterial({ color: 0x8a8f86, map: STRK, roughness: 1, transparent: true, opacity: 0.92, side: THREE.DoubleSide, depthWrite: false })));
  const o = new THREE.Mesh(g, new THREE.MeshStandardMaterial({ color: 0x9aa094, map: STRK2, roughness: 1, transparent: true, opacity: 0.4, side: THREE.DoubleSide, depthWrite: false })); o.scale.set(1.25, 1, 1.25); o.renderOrder = 1; TOR.add(o);
  const cl = new THREE.Mesh(new THREE.CylinderGeometry(34, 40, 5, 40), new THREE.MeshStandardMaterial({ color: 0x3e443e, roughness: 1 })); cl.position.y = 44; TOR.add(cl);
})();
const DUST = []; (function(){ const dm = new THREE.MeshStandardMaterial({ color: 0x8e8270, roughness: 1, flatShading: true, transparent: true, opacity: 0.45, depthWrite: false });
  for (let i = 0; i < 16; i++){ const m = new THREE.Mesh(new THREE.IcosahedronGeometry(0.7 + hsh(i) * 0.9, 0), dm); TOR.add(m); DUST.push(m); } })();
const BITS = []; (function(){ const bm = mat(0x4a3a2a); for (let i = 0; i < 26; i++){ const m = P(TOR, rbox(0.4 + hsh(i + 1) * 0.6, 0.12, 0.3, 0.02, 1), bm); BITS.push(m); } })();
function torUpd(x, z){ const T = dT; TOR.position.set(x, 0, z); TOR.rotation.z = 0.04 * Math.sin(T * 0.7); STRK.offset.set(-T * 0.55, -T * 0.08); STRK2.offset.set(-T * 0.8, -T * 0.05);
  DUST.forEach((m, i) => { const a = hsh(i + 20) * 6.283 + T * (1.6 + hsh(i + 5) * 0.6), r = 2.6 + hsh(i + 8) * 2.6; m.position.set(Math.cos(a) * r, 0.6 + hsh(i + 9) * 2.4 + 0.3 * Math.sin(T * 2 + i), Math.sin(a) * r); m.rotation.set(T + i, T * 0.7, 0); });
  BITS.forEach((m, i) => { const y = 3 + 24 * (0.5 + 0.5 * Math.sin(T * 0.35 + hsh(i + 30) * 6.283)), r = 1.6 + 0.0042 * y * y + 1.5 + hsh(i + 2) * 2, a = hsh(i + 40) * 6.283 + T * (2.4 - y * 0.03);
    m.position.set(Math.cos(a) * r, y, Math.sin(a) * r); m.rotation.set(T * 3 + i, T * 2 + i * 0.5, 0); }); }

// Blätter/Gras im Einstrom (Richtung Tornado, also -z)
const LEAVES = []; (function(){ const lm = [mat(0x6a8a3a), mat(0x8a7a3a), mat(0x5a4a2a)]; for (let i = 0; i < 30; i++) LEAVES.push(P(FIELD, rbox(0.22, 0.04, 0.14, 0.01, 1), lm[i % 3])); })();
function leaves(on){ const T = dT; LEAVES.forEach((m, i) => { m.visible = on; if (!on) return; const z = 16 - ((T * 7 + hsh(i + 3) * 64) % 64); m.position.set(-7 + hsh(i) * 14 + Math.sin(T * 1.3 + i) * 0.6, 0.3 + hsh(i + 5) * 3 + 0.4 * Math.sin(T * 3 + i), z); m.rotation.set(T * 4 + i, T * 3, T * 2 + i); }); }

// Trümmer um Ben: Bretter, Ziegel, Ast, Auto
const DEBG = new THREE.Group(); FIELD.add(DEBG); const DEB = [];
(function(){ const wd = mat(0x9a7448, { roughness: 0.9 }), tl = mat(0xa8482e, { roughness: 0.8 }), br = mat(0x5a4030), lf = mat(0x4a6a2e, { flatShading: true });
  const add = (o, R, a0, w, y, sp) => { DEBG.add(o); DEB.push({ o, R, a0, w, y, sp }); };
  for (let i = 0; i < 3; i++){ const g = new THREE.Group(); P(g, rbox(1.8, 0.12, 0.32, 0.03, 1), wd); add(g, 3.2 + i * 1.1, i * 2.1, 1.1 + i * 0.15, -1 + i * 1.2, 2.5); }
  for (let i = 0; i < 5; i++){ const g = new THREE.Group(); P(g, rbox(0.55, 0.08, 0.36, 0.02, 1), tl); add(g, 2.6 + i * 0.7, 0.7 + i * 1.3, 1.5 - i * 0.12, -1.6 + i * 0.9, 4); }
  { const g = new THREE.Group(); const s = P(g, new THREE.CylinderGeometry(0.08, 0.14, 2.4, 6), br); s.rotation.z = PI / 2; P(g, new THREE.IcosahedronGeometry(0.5, 0), lf, 0.9, 0.3, 0); P(g, new THREE.IcosahedronGeometry(0.4, 0), lf, -0.3, 0.35, 0.2); add(g, 4.2, 3.6, 0.9, 1.2, 1.6); }
  { const g = new THREE.Group(); const cb = mat(0x2f6fb5, { roughness: 0.4, metalness: 0.2 }), cw = mat(0x9fc4e0, { roughness: 0.1 }), tr = mat(0x1a1a1a);
    P(g, rbox(3.4, 0.8, 1.6, 0.18), cb, 0, 0, 0); P(g, rbox(1.8, 0.7, 1.4, 0.15), cw, -0.2, 0.7, 0);
    [[-1.1, -0.75], [1.1, -0.75], [-1.1, 0.75], [1.1, 0.75]].forEach(([x, z]) => { const w = P(g, new THREE.CylinderGeometry(0.38, 0.38, 0.3, 12), tr, x, -0.4, z); w.rotation.x = PI / 2; });
    add(g, 6.0, 1.0, 0.75, 4.2, 0.9); }
})();
function debUpd(cx, cy, cz){ DEB.forEach((d, i) => { const a = d.a0 + d.w * T; d.o.position.set(cx + Math.cos(a) * d.R, cy + d.y + 0.5 * Math.sin(T * 1.7 + i), cz + Math.sin(a) * d.R); d.o.rotation.set(T * d.sp + i, T * d.sp * 0.7, T * d.sp * 0.4 + i); }); }

/* =========================================================
   SET 2: Keller (Bank, Regal, Lampe, Treppe)
   ========================================================= */
(function(){ const wm = new THREE.MeshStandardMaterial({ color: 0x6e655c, roughness: 1, side: THREE.BackSide });
  const room = new THREE.Mesh(new THREE.BoxGeometry(9, 3.6, 14), wm); room.position.set(0, 1.8, 1); room.receiveShadow = true; CELLAR.add(room);
  const fl = new THREE.Mesh(new THREE.PlaneGeometry(9, 14), mat(0x4e3c2c, { roughness: 1 })); fl.rotation.x = -PI / 2; fl.position.set(0, 0.01, 1); fl.receiveShadow = true; CELLAR.add(fl);
  const bm = mat(0x5a4030, { roughness: 0.9 }); for (let i = 0; i < 4; i++) { const b = new THREE.Mesh(rbox(9, 0.22, 0.3, 0.02, 1), bm); b.position.set(0, 3.45, -5 + i * 3); CELLAR.add(b); }
  P(CELLAR, rbox(2.6, 0.12, 0.7, 0.03, 1), mat(0x7a5a3a), 0, 0.5, -3.2); P(CELLAR, rbox(0.12, 0.5, 0.6, 0.02, 1), bm, -1.1, 0.25, -3.2); P(CELLAR, rbox(0.12, 0.5, 0.6, 0.02, 1), bm, 1.1, 0.25, -3.2);
  const sh = mat(0x6a4a30); [1.2, 2.2].forEach(y => P(CELLAR, rbox(4, 0.1, 0.5, 0.02, 1), sh, 0, y, -5.7));
  const jc = [0xc8a040, 0xb03a2a, 0x6a8a3a, 0xd8d0c0, 0x3a6a9a]; for (let i = 0; i < 10; i++){ P(CELLAR, new THREE.CylinderGeometry(0.16, 0.16, 0.42, 10), mat(jc[i % 5], { roughness: 0.3 }), -1.7 + (i % 5) * 0.85, i < 5 ? 1.46 : 2.46, -5.65); }
  const st = mat(0x8a8a84, { roughness: 1 }); for (let i = 0; i < 6; i++) P(CELLAR, rbox(1.6, 0.3, 0.6, 0.02, 1), st, 3.6, 0.15 + i * 0.55, -1 + i * 0.6).scale.y = 1 + i * 1.83;
  const bulb = new THREE.Mesh(new THREE.SphereGeometry(0.14, 12, 8), new THREE.MeshBasicMaterial({ color: 0xffe2a0 })); bulb.position.set(0, 3.0, -1.5); CELLAR.add(bulb);
  P(CELLAR, new THREE.CylinderGeometry(0.02, 0.02, 0.4, 4), mat(0x222222), 0, 3.25, -1.5);
})();
// Taschenlampe (rechte Hand = el[1]) + Lichtkegel, Snacktüte (linke Hand = el[0])
const TORCH = new THREE.Group(); ben.el[1].add(TORCH); TORCH.position.set(0, -0.62, 0.1);
P(TORCH, new THREE.CylinderGeometry(0.09, 0.11, 0.5, 10), mat(0x2a2a2e, { metalness: 0.5, roughness: 0.4 }), 0, 0, 0.2).rotation.x = PI / 2;
const BEAM = new THREE.Mesh(new THREE.CylinderGeometry(0.1, 1.1, 4.5, 20, 1, true), new THREE.MeshBasicMaterial({ color: 0xfff0b0, transparent: true, opacity: 0.16, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide, fog: false }));
BEAM.rotation.x = PI / 2; BEAM.position.set(0, 0, 2.7); TORCH.add(BEAM);
const BAG = new THREE.Group(); ben.el[0].add(BAG); BAG.position.set(0, -0.7, 0.18);
P(BAG, rbox(0.46, 0.62, 0.16, 0.05), mat(0xd02a22, { roughness: 0.5 }), 0, 0, 0); P(BAG, rbox(0.48, 0.12, 0.17, 0.02, 1), mat(0xf2c21a), 0, 0.12, 0);

/* =========================================================
   BEN
   ========================================================= */
const SCAR = new THREE.Group(); ben.head.add(SCAR);
(function(){ const m = mat(0xa8463f, { roughness: 0.7 }); const s = new THREE.Mesh(rbox(0.075, 0.72, 0.03, 0.012, 1), m); s.position.set(0.25, 0.55, 0.522); s.rotation.z = -0.13; SCAR.add(s);
  for (const y of [0.36, 0.55, 0.74]){ const c = new THREE.Mesh(rbox(0.16, 0.035, 0.03, 0.01, 1), m); c.position.set(0.25 + (y - 0.55) * 0.13, y, 0.528); c.rotation.z = -0.13; SCAR.add(c); } })();
// Hook-Pose: Ben steht im Feld, stemmt sich gegen den Sog (lehnt nach vorn = +z, weg vom Tornado)
function windBen(t){ bRest(ben, t, 0); place(ben, 0, 0, 0, 0); const w = Math.sin(t * 5.5); ben.torso.rotation.x = 0.3 + 0.05 * w; ben.legs[0].rotation.x = 0.35; ben.legs[1].rotation.x = -0.25;
  ben.sh[0].rotation.set(-1.0 + 0.15 * w, 0, -0.5); ben.sh[1].rotation.set(-1.0 - 0.15 * w, 0, 0.5); ben.el[0].rotation.x = -0.6; ben.el[1].rotation.x = -0.6; ben.head.rotation.x = -0.1; eyeS = 1.4; bFace(ben, -0.9, 0.45); }

/* =========================================================
   KAMERA + Zustand
   ========================================================= */
const cL = new THREE.Vector3();
let blurAmt = 0, fadeBlk = 0, T = 0, flashA = 0, eyeS = 1, talk = 0, dT = 0;
let spdK = 0, liftK = 0, debK = 0, ruleK = 0, dustK = 0;
function camW(p, a, b){ cam.position.set(lerp(a[0], b[0], p), lerp(a[1], b[1], p), lerp(a[2], b[2], p)); cL.set(lerp(a[3], b[3], p), lerp(a[4], b[4], p), lerp(a[5], b[5], p)); cam.fov = lerp(a[6], b[6], p); }
function camFin(sh){ cam.position.x += Math.sin(dT * 0.7) * 0.02; cam.position.y += Math.sin(dT * 0.9 + 1) * 0.015; if (sh){ cam.position.x += Math.sin(T * 23) * sh; cam.position.y += Math.cos(T * 17) * sh; } cam.up.set(0, 1, 0); cam.lookAt(cL); cam.updateProjectionMatrix(); cam.updateMatrixWorld(); }
const HOOK = [[2.0, 2.6, 8.5, -1.0, 2.45, 0, 50], [1.6, 2.4, 7.4, -1.0, 2.45, 0, 50]];
function base(){ show(ben); DEBG.visible = false; TORCH.visible = false; BAG.visible = false; doors(1); leaves(false); }
function hookBen(t){ windBen(t); }

/* =========================================================
   SZENEN (Sprecherspur Tempo 1,2)
   ========================================================= */
const SCN = [
  { t: 0, set: FIELD, mood: MOOD.storm, hook: 1,
    upd(lt){ dT = T; base(); leaves(true); torUpd(-7, -42); hookBen(T); camW(E.io(seg(lt, 0, 2.98)), HOOK[0], HOOK[1]); camFin(0.012); } },
  { t: 2.98, set: FIELD, mood: MOOD.storm, hud: () => ['ÜBER 400 KM/H', 'DIE STÄRKSTEN TORNADOS'],
    upd(lt){ dT = T; base(); leaves(true); torUpd(-7, -42 + 3 * seg(T, 3, 6.5)); windBen(T); spdK = E.out(seg(T, 3.2, 3.5)) * (1 - seg(T, 6.32, 6.52));
      camW(E.io(seg(lt, 0, 3.54)), [9, 2.2, 13, -5, 14, -40, 50], [7, 2.0, 11, -5, 15, -40, 50]); camFin(); } },
  { t: 6.52, set: FIELD, mood: MOOD.storm, hud: () => ['AB CA. 200 KM/H', 'HEBT ES MENSCHEN AN'],
    upd(lt){ dT = T; base(); leaves(true); torUpd(-7, -9); bRest(ben, T, 0); const up = E.io(seg(T, 6.9, 9.9)), x = lerp(0, -1.5, up), y = 5.5 * up;
      place(ben, x, y, 0, 0.9 * Math.sin(T * 1.1) * up); ben.root.rotation.z = 0.35 * up * Math.sin(T * 1.6); ben.root.rotation.x = 0.25 * up * Math.sin(T * 1.3);
      ben.sh[0].rotation.set(-0.4, 0, -1.6 - 0.3 * Math.sin(T * 7)); ben.sh[1].rotation.set(-0.4, 0, 1.6 + 0.3 * Math.sin(T * 7)); ben.legs[0].rotation.x = 0.5 * Math.sin(T * 6) * up; ben.legs[1].rotation.x = -0.5 * Math.sin(T * 6) * up;
      eyeS = 1.45; bFace(ben, -1, 0.6); liftK = E.out(seg(T, 6.8, 7.1)) * (1 - seg(T, 9.92, 10.12));
      camW(E.io(seg(lt, 0, 3.6)), [6.5, 2.2, 12, -1.5, 3.2, -2, 52], [5.5, 4.5, 11, -1.5, 6.8, -2, 52]); camFin(0.02); } },
  { t: 10.12, set: FIELD, mood: MOOD.storm, hud: () => ['GEFAHR NR. 1', 'FLIEGENDE TRÜMMER'],
    upd(lt){ dT = T; base(); torUpd(-7, -9); DEBG.visible = true; bRest(ben, T, 0); const by = 5.5 + 0.3 * Math.sin(T * 1.4);
      place(ben, -1.5, by, 0, 0.9 * Math.sin(T * 1.1)); ben.root.rotation.z = 0.35 * Math.sin(T * 1.6); ben.root.rotation.x = 0.25 * Math.sin(T * 1.3);
      ben.sh[0].rotation.set(-2.4, 0, -0.5); ben.sh[1].rotation.set(-2.4, 0, 0.5); ben.el[0].rotation.x = -1.4; ben.el[1].rotation.x = -1.4; ben.legs[0].rotation.x = 0.4 * Math.sin(T * 6); ben.legs[1].rotation.x = -0.4 * Math.sin(T * 6);
      eyeS = 1.45; bFace(ben, -1, 0.55); debUpd(-1.5, by, 0); debK = E.out(seg(T, 14.2, 14.4)) * (1 - seg(T, 17.1, 17.3));
      camW(E.io(seg(lt, 0, 7.18)), [5.5, 7.2, 10, -1.5, 6.0, 0, 55], [4.0, 6.6, 11.5, -1.5, 5.8, 0, 58]); camFin(0.02 + 0.06 * bump(T, 15.1, 15.4) + 0.08 * bump(T, 16.45, 16.8)); } },
  { t: 17.3, set: FIELD, mood: MOOD.storm, hud: () => ['DARUM:', 'AB IN DEN KELLER!'],
    upd(lt){ dT = T; base(); leaves(true); torUpd(-9, -36 + 6 * seg(T, 17.3, 20.3)); bRest(ben, T, 0); const run = seg(T, 17.35, 18.55), dn = E.io(seg(T, 18.55, 19.2));
      const x = lerp(-3, 4, run), z = lerp(8, 3, run); place(ben, x, -2.8 * dn, z, Math.atan2(7, -5)); if (run < 1) wlk(ben, T * 13, 1); ben.torso.rotation.x = 0.2;
      doors(1 - E.io(seg(T, 19.25, 19.5))); eyeS = 1.3; bFace(ben, -0.8, 0.3); ruleK = E.out(seg(T, 17.5, 17.8)) * (1 - seg(T, 20.07, 20.27));
      camW(E.io(seg(lt, 0, 2.97)), [9, 4.2, 14, 1.5, 1.6, 3, 50], [8, 3.6, 12.5, 2.5, 1.4, 3, 50]); camFin(0.05 * bump(T, 19.48, 19.8)); } },
  { t: 20.27, set: CELLAR, mood: MOOD.cel, hud: () => ['UND BEN?', 'SICHER IM KELLER'],
    upd(lt){ dT = T; base(); TORCH.visible = true; BAG.visible = true; bRest(ben, T, 0); place(ben, 0, 0, -3.15, 0); sit(ben, 0.56); ben.legs[0].rotation.x = -1.5; ben.legs[1].rotation.x = -1.5;
      ben.sh[1].rotation.set(-1.0, 0, 0.1); ben.el[1].rotation.x = -0.35; ben.sh[0].rotation.set(-0.5, 0, -0.15); ben.el[0].rotation.x = -0.9 - 0.5 * Math.max(0, Math.sin(T * 3));
      ben.head.rotation.x = 0.05 * Math.sin(T * 6); eyeS = 1; bFace(ben, 0.6, 0.12 + 0.12 * Math.max(0, Math.sin(T * 8))); dustK = E.out(seg(T, 20.3, 20.8));
      camW(E.io(seg(lt, 0, 3.2)), [3.4, 2.2, 3.0, 0, 1.9, -3.1, 45], [2.9, 2.1, 2.4, 0, 1.9, -3.1, 45]); camFin(0.012 + 0.012 * Math.sin(T * 2.3)); } },
  { t: 23.45, set: FIELD, mood: MOOD.storm, loopin: 1,
    upd(lt){ dT = T - END; base(); leaves(true); torUpd(-7, -42); hookBen(T - END); camW(0, HOOK[0], HOOK[1]); camFin(0.012); } },
];
const SUBS = __SUBS__;
