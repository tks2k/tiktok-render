/* =========================================================
   TEXT (neues Format: fett, Großbuchstaben, aktives Wort gelb)
   ========================================================= */
const SANS = '"Arial Black", "Helvetica Neue", Arial, system-ui, sans-serif', SERIF = SANS;
const band = document.createElement('canvas'); band.width = 8; band.height = 512;
(function(){ const x = band.getContext('2d'), g = x.createLinearGradient(0, 0, 0, 512); g.addColorStop(0, 'rgba(10,14,24,0)'); g.addColorStop(0.5, 'rgba(10,14,24,0.42)'); g.addColorStop(1, 'rgba(10,14,24,0)'); x.fillStyle = g; x.fillRect(0, 0, 8, 512); })();
function boldLines(words, cy, size, maxW, act, pop, col){
  g2.save(); g2.font = `900 ${size}px ${SANS}`; g2.textBaseline = 'middle'; g2.lineJoin = 'round';
  const spc = size * 0.28, lines = [[]]; let lw = 0;
  words.forEach((w, i) => { const wd = g2.measureText(w).width; if (lw + wd > maxW && lines[lines.length - 1].length){ lines.push([]); lw = 0; } lines[lines.length - 1].push({ w, wd, i }); lw += wd + spc; });
  const lh = size * 1.12, y0 = cy - (lines.length - 1) * lh / 2;
  lines.forEach((ln, li) => { const tw = ln.reduce((a, b) => a + b.wd, 0) + spc * (ln.length - 1); let x = W / 2 - tw / 2;
    ln.forEach(tk => { const on = tk.i === act, s = on ? 1 + 0.08 * pop : 1, y = y0 + li * lh;
      g2.save(); g2.translate(x + tk.wd / 2, y); g2.scale(s, s);
      g2.lineWidth = size * 0.2; g2.strokeStyle = '#0b1220'; g2.strokeText(tk.w, -tk.wd / 2, 0);
      g2.fillStyle = on ? '#ffd23c' : (col || '#ffffff'); g2.fillText(tk.w, -tk.wd / 2, 0); g2.restore(); x += tk.wd + spc; }); });
  g2.restore();
}
function fitSize(text, size, maxW){ g2.font = `900 ${size}px ${SANS}`; const w = g2.measureText(text).width; return w > maxW ? size * maxW / w : size; }
function drawHook(a, sc){
  if (a <= 0) return; g2.save(); g2.globalAlpha = a; g2.drawImage(band, 0, 340, W, 520);
  const s1 = fitSize('MEER PLÖTZLICH WEG?', 120, 960), s2 = fitSize('WAS NUN?', 120, 900);
  g2.translate(W / 2, 600); g2.scale(sc, sc); g2.translate(-W / 2, -600);
  boldLines(['MEER', 'PLÖTZLICH', 'WEG?'], 535, s1, 1000, -1, 0); boldLines(['WAS', 'NUN?'], 670, s2, 940, -1, 0, '#ffd23c');
  g2.restore();
}
function drawSubs(){
  let cur = null; for (const s of SUBS) if (T >= s.s && T < s.e) cur = s; if (!cur) return;
  let act = 0; cur.w.forEach((w, i) => { if (T >= w[1]) act = i; });
  const pop = clamp01(1 - (T - cur.w[act][1]) / 0.18), age = T - cur.s, a = E.out(clamp01(age / 0.08));
  g2.save(); g2.globalAlpha = a; g2.drawImage(band, 0, 1060, W, 400);
  const yy = 1260 + (1 - a) * 14;
  if (cur.ben){ boldLines(cur.w.map(w => w[0]), yy, 112, 880, act, pop, '#ffffff'); g2.font = `900 34px ${SANS}`; g2.textAlign = 'center'; g2.fillStyle = '#ffd23c'; g2.strokeStyle = '#0b1220'; g2.lineWidth = 8; g2.strokeText('— BEN', W / 2, yy + 100); g2.fillText('— BEN', W / 2, yy + 100); }
  else boldLines(cur.w.map(w => w[0]), yy, 78, 880, act, pop);
  g2.restore();
}
function drawHud(h){
  if (!h) return; g2.save(); g2.textAlign = 'center'; g2.textBaseline = 'middle'; g2.lineJoin = 'round';
  const big = fitSize(h[0], 140, 880); g2.font = `900 ${big}px ${SANS}`; g2.lineWidth = 24; g2.strokeStyle = '#0b1220'; g2.strokeText(h[0], W / 2, 400); g2.fillStyle = '#ffffff'; g2.fillText(h[0], W / 2, 400);
  if (h[1]){ g2.font = `900 40px ${SANS}`; g2.lineWidth = 10; g2.strokeText(h[1], W / 2, 500); g2.fillStyle = '#ffd23c'; g2.fillText(h[1], W / 2, 500); }
  g2.restore();
}
function glowDot(x, y, r, col, a){ if (a <= 0) return; const g = g2.createRadialGradient(x, y, 0, x, y, r); g.addColorStop(0, 'rgba(255,255,255,' + Math.min(1, a) + ')'); g.addColorStop(0.25, col.replace('A', Math.min(1, a) * 0.9)); g.addColorStop(1, col.replace('A', 0)); g2.fillStyle = g; g2.fillRect(x - r, y - r, 2 * r, 2 * r); }
function wp(x, y, z){ return proj(new THREE.Vector3(x, y, z)); }
function txt(s, x, y, size, col, al){ g2.font = `900 ${size}px ${SANS}`; g2.textAlign = al || 'center'; g2.textBaseline = 'middle'; g2.lineJoin = 'round'; g2.lineWidth = size * 0.22; g2.strokeStyle = '#0b1220'; g2.strokeText(s, x, y); g2.fillStyle = col; g2.fillText(s, x, y); }
const _p = new THREE.Vector3();
function wl(o, x, y, z){ o.updateWorldMatrix(true, false); return proj(o.localToWorld(_p.set(x, y, z))); }
function along(P, f){ let L = 0; const sg = []; for (let i = 1; i < P.length; i++){ const q = Math.hypot(P[i][0] - P[i - 1][0], P[i][1] - P[i - 1][1]); sg.push(q); L += q; } let r = f * L;
  for (let i = 0; i < sg.length; i++){ if (r <= sg[i]){ const k = r / sg[i]; return [lerp(P[i][0], P[i + 1][0], k), lerp(P[i][1], P[i + 1][1], k)]; } r -= sg[i]; } return P[P.length - 1]; }
function path(P){ g2.beginPath(); g2.moveTo(P[0][0], P[0][1]); for (let i = 1; i < P.length; i++) g2.lineTo(P[i][0], P[i][1]); }
function star(x, y, r){ g2.beginPath(); for (let k = 0; k < 3; k++){ const a = k * PI / 3; g2.moveTo(x - Math.cos(a) * r, y - Math.sin(a) * r); g2.lineTo(x + Math.cos(a) * r, y + Math.sin(a) * r); } g2.stroke(); }
function flame(x, y, s, a){ g2.save(); g2.globalAlpha = a; g2.translate(x, y); const w = 1 + 0.08 * Math.sin(T * 14);
  g2.beginPath(); g2.moveTo(0, -1.1 * s * w); g2.bezierCurveTo(0.7 * s, -0.4 * s, 0.6 * s, 0.5 * s, 0, 0.55 * s); g2.bezierCurveTo(-0.6 * s, 0.5 * s, -0.7 * s, -0.4 * s, 0, -1.1 * s * w); g2.fillStyle = '#ff5a1f'; g2.fill();
  g2.beginPath(); g2.moveTo(0, -0.5 * s * w); g2.bezierCurveTo(0.35 * s, -0.1 * s, 0.3 * s, 0.4 * s, 0, 0.45 * s); g2.bezierCurveTo(-0.3 * s, 0.4 * s, -0.35 * s, -0.1 * s, 0, -0.5 * s * w); g2.fillStyle = '#ffd23c'; g2.fill(); g2.restore(); }

function chip(x, y, w, h){ g2.fillStyle = 'rgba(11,22,36,0.66)'; g2.beginPath(); g2.roundRect(x - w / 2, y - h / 2, w, h, 26); g2.fill(); }
function warnTri(x, y, s){ g2.beginPath(); g2.moveTo(x, y - s); g2.lineTo(x + s * 1.1, y + s * 0.8); g2.lineTo(x - s * 1.1, y + s * 0.8); g2.closePath(); g2.fillStyle = '#ffd23c'; g2.fill(); g2.lineWidth = 8; g2.strokeStyle = '#0b1220'; g2.stroke(); txt('!', x, y + s * 0.2, s * 1.1, '#0b1220'); }
function drawWarn(a){ if (a <= 0) return; g2.save(); g2.globalAlpha = a; const cy = 1690; chip(W / 2, cy, 860, 200); warnTri(W / 2 - 320, cy, 62 * (1 + 0.06 * Math.sin(T * 9)));
  txt('TSUNAMI-WARNZEICHEN', W / 2 + 70, cy - 30, 48, '#ffffff'); txt('MEER ZIEHT SICH ZURÜCK', W / 2 + 70, cy + 36, 36, '#ffd23c'); g2.restore(); }
function plane2(x, y, s){ g2.save(); g2.translate(x, y); g2.fillStyle = '#ffffff'; g2.strokeStyle = '#0b1220'; g2.lineWidth = 5;
  g2.beginPath(); g2.moveTo(-1.0 * s, -0.08 * s); g2.lineTo(0.9 * s, -0.1 * s); g2.quadraticCurveTo(1.15 * s, 0, 0.9 * s, 0.1 * s); g2.lineTo(-1.0 * s, 0.08 * s); g2.closePath(); g2.fill(); g2.stroke();
  g2.beginPath(); g2.moveTo(0.1 * s, 0); g2.lineTo(-0.35 * s, 0.7 * s); g2.lineTo(-0.55 * s, 0.7 * s); g2.lineTo(-0.3 * s, 0); g2.closePath(); g2.fill(); g2.stroke();
  g2.beginPath(); g2.moveTo(-0.8 * s, 0); g2.lineTo(-1.0 * s, -0.4 * s); g2.lineTo(-1.1 * s, -0.4 * s); g2.lineTo(-1.0 * s, 0); g2.closePath(); g2.fill(); g2.stroke(); g2.restore(); }
function drawDia(a){ if (a <= 0) return; g2.save(); g2.globalAlpha = a; const x0 = 60, x1 = 1020, y0 = 580, y1 = 1010, sy = 720; chip(W / 2, (y0 + y1) / 2, x1 - x0, y1 - y0);
  const fl = x => x < 640 ? 960 : x < 900 ? lerp(960, 740, (x - 640) / 260) : 740 - (x - 900) * 0.6;
  let px, amp, wd, lab;
  if (T < 11.12){ const k = seg(T, 5.9, 11.0); px = lerp(110, 640, k); amp = 14; wd = 90; lab = '700+ KM/H'; }
  else { const k = E.out(seg(T, 11.12, 13.6)); px = lerp(640, 875, k); amp = lerp(14, 160, k); wd = lerp(90, 42, k); lab = '≈ 40 KM/H'; }
  const surf = x => sy - amp * Math.exp(-Math.pow((x - px) / wd, 2));
  g2.beginPath(); g2.moveTo(x0 + 20, surf(x0 + 20)); for (let x = x0 + 20; x <= 930; x += 6) g2.lineTo(x, Math.min(surf(x), fl(x))); for (let x = 930; x >= x0 + 20; x -= 6) g2.lineTo(x, fl(x)); g2.closePath(); g2.fillStyle = '#2c8fbd'; g2.fill();
  g2.beginPath(); g2.moveTo(x0 + 20, 990); for (let x = x0 + 20; x <= x1 - 20; x += 6) g2.lineTo(x, Math.min(990, Math.max(fl(x), 600))); g2.lineTo(x1 - 20, 990); g2.closePath(); g2.fillStyle = '#c9a86a'; g2.fill();
  g2.lineWidth = 6; g2.strokeStyle = '#0b1220'; g2.beginPath(); for (let x = x0 + 20; x <= 930; x += 6){ const y = Math.min(surf(x), fl(x)); x === x0 + 20 ? g2.moveTo(x, y) : g2.lineTo(x, y); } g2.stroke();
  txt('OZEAN: TIEF', 230, 900, 34, '#ffffff'); txt('KÜSTE', 930, 640, 34, '#ffffff');
  if (T < 11.12) plane2(px, surf(px) - 80, 66); txt(lab, Math.min(px, 820), surf(px) - (T < 11.12 ? 150 : 50), 48, '#ffd23c');
  g2.restore(); }
function drawMin(a){ if (a <= 0) return; g2.save(); g2.globalAlpha = a; const cy = 1690, cx = W / 2 - 320; chip(W / 2, cy, 860, 200);
  g2.fillStyle = '#f4f4f8'; g2.beginPath(); g2.arc(cx, cy, 62, 0, 2 * PI); g2.fill(); g2.lineWidth = 8; g2.strokeStyle = '#0b1220'; g2.stroke();
  const an = (T - 14) * 2.2; g2.lineCap = 'round'; g2.strokeStyle = '#e0302a'; g2.lineWidth = 8; g2.beginPath(); g2.moveTo(cx, cy); g2.lineTo(cx + Math.sin(an) * 46, cy - Math.cos(an) * 46); g2.stroke();
  txt('NUR WENIGE MINUTEN', W / 2 + 70, cy - 30, 48, '#ffffff'); txt('SO HOCH WIE MÖGLICH', W / 2 + 70, cy + 36, 36, '#ffd23c'); g2.restore(); }
function drawWaves(a){ if (a <= 0) return; g2.save(); g2.globalAlpha = a; const cy = 1690; chip(W / 2, cy, 880, 200);
  ['WELLE 1', 'WELLE 2', 'WELLE 3'].forEach((l, i) => txt(l, W / 2 - 280 + i * 280, cy - 32, 46, i === 0 ? '#8a96a8' : i === 1 ? '#ffd23c' : '#ffffff'));
  txt('DIE ERSTE IST OFT NICHT DIE GRÖSSTE', W / 2, cy + 40, 34, '#ff8a6a'); g2.restore(); }

function heart(x, y, s){ g2.beginPath(); g2.moveTo(x, y + 0.35 * s); g2.bezierCurveTo(x - 1.1 * s, y - 0.35 * s, x - 0.45 * s, y - 1.0 * s, x, y - 0.45 * s); g2.bezierCurveTo(x + 0.45 * s, y - 1.0 * s, x + 1.1 * s, y - 0.35 * s, x, y + 0.35 * s); g2.closePath(); }
function drawHeart(a){ if (a <= 0) return; const ph = (T * 2.5) % 1, beat = ph < 0.15 ? Math.sin(ph / 0.15 * PI) : 0, s = 70 * (1 + 0.22 * beat);
  g2.save(); g2.globalAlpha = a; heart(W / 2, 660, s); g2.fillStyle = '#ff3b3b'; g2.fill(); g2.lineWidth = 10; g2.strokeStyle = '#0b1220'; g2.stroke(); g2.restore(); }
const vig = document.createElement('canvas'); vig.width = 270; vig.height = 480;
(function(){ const x = vig.getContext('2d'), g = x.createRadialGradient(135, 240, 120, 135, 240, 330); g.addColorStop(0, 'rgba(0,0,0,0)'); g.addColorStop(1, 'rgba(0,0,0,0.38)'); x.fillStyle = g; x.fillRect(0, 0, 270, 480); })();
function draw2D(sc, lt, dur){
  g2.globalAlpha = 1; g2.globalCompositeOperation = 'source-over'; g2.drawImage(renderer.domElement, 0, 0, W, H);
  g2.globalAlpha = 1; g2.globalCompositeOperation = 'source-over'; g2.drawImage(vig, 0, 0, W, H);
  if (flashA > 0){ g2.fillStyle = `rgba(255,250,240,${Math.min(1, flashA)})`; g2.fillRect(0, 0, W, H); }
  if (fadeBlk > 0){ g2.fillStyle = `rgba(0,0,0,${fadeBlk})`; g2.fillRect(0, 0, W, H); }
  drawWarn(warnK); drawDia(diaK); drawMin(minK); drawWaves(wavK);
  if (sc.hud) drawHud(sc.hud());
  if (sc.hook) drawHook(clamp01((dur - lt) / 0.15), 1);
  if (sc.loopin){ const k = clamp01((T - (END - 0.14)) / 0.14); drawHook(k, 1 + 0.25 * (1 - k)); }
  if (!sc.hook) drawSubs();
}
