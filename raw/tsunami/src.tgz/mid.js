/* =========================================================
   STIMMUNG: Strand (statischer Himmel)
   ========================================================= */
function sky(){
  const c = document.createElement('canvas'); c.width = 4; c.height = 512; const x = c.getContext('2d'), g = x.createLinearGradient(0, 0, 0, 512);
  g.addColorStop(0, '#4a9fe0'); g.addColorStop(0.55, '#9fd0f2'); g.addColorStop(1, '#e8f4fb'); x.fillStyle = g; x.fillRect(0, 0, 4, 512);
  const t = new THREE.CanvasTexture(c); t.encoding = THREE.sRGBEncoding; return t;
}
const MOOD = { beach: { sky: sky(), fog: [0xd6ebf7, 90, 420], hemi: [0xeaf6ff, 0xc8b48a, 0.95], sun: [0xfff3dc, 1.2], sp: [8, 22, 14] } };
const SR = 16; { const c = sun.shadow.camera; c.left = -SR; c.right = SR; c.top = SR; c.bottom = -SR; c.near = 1; c.far = 90; c.updateProjectionMatrix(); }
function setMood(m){
  scene.background = m.sky; scene.fog.color.set(m.fog[0]); scene.fog.near = m.fog[1]; scene.fog.far = m.fog[2]; scene.environment = envDay;
  hemi.color.set(m.hemi[0]); hemi.groundColor.set(m.hemi[1]); hemi.intensity = m.hemi[2]; sun.color.set(m.sun[0]); sun.intensity = m.sun[1];
  sun.position.set(m.sp[0], m.sp[1], m.sp[2]); sun.target.position.set(0, 0, 0); fill.color.set(0xffffff); fill.intensity = 0.3; fill.position.set(-14, 8, 20);
}

/* =========================================================
   SET: Strand, Meer, Haus, Welle
   ========================================================= */
const BEACH = new THREE.Group(); scene.add(BEACH); const SETS = [BEACH];
function plane(par, w, d, col, x, y, z, o){ const m = new THREE.Mesh(new THREE.PlaneGeometry(w, d), new THREE.MeshStandardMaterial(Object.assign({ color: col, roughness: 1 }, o || {}))); m.rotation.x = -PI / 2; m.position.set(x, y, z); m.receiveShadow = true; par.add(m); return m; }
plane(BEACH, 600, 600, 0xe6cf98, 0, 0, 0);
plane(BEACH, 600, 120, 0xb89a62, 0, 0.004, -64);
const SEAP = plane(BEACH, 600, 600, 0x2c8fbd, 0, 0.06, -304, { roughness: 0.15, metalness: 0.1, envMapIntensity: 1.1 });
const FOAM = plane(BEACH, 600, 0.9, 0xf4fbff, 0, 0.07, -4, { roughness: 0.6 });
function sea(zs, y){ SEAP.position.set(0, y, zs - 300); FOAM.position.set(0, y + 0.012, zs - 0.2); }
const HOUSE = new THREE.Group(); BEACH.add(HOUSE); HOUSE.position.set(9, 0, 3);
(function(){ const c = mat(0xd9d4cc, { roughness: 0.9 }), w = mat(0x3d5a73, { roughness: 0.3, metalness: 0.2 }), r = mat(0x8a8580);
  P(HOUSE, rbox(5, 11, 5, 0.08), c, 0, 5.5, 0); P(HOUSE, rbox(5.3, 0.3, 5.3, 0.05), r, 0, 11.1, 0);
  for (let f = 0; f < 4; f++) for (let k = -1; k <= 1; k++){ P(HOUSE, rbox(1.0, 1.3, 0.08, 0.03, 1), w, k * 1.5, 1.6 + f * 2.6, 2.52); P(HOUSE, rbox(0.08, 1.3, 1.0, 0.03, 1), w, -2.52, 1.6 + f * 2.6, k * 1.5); }
  P(HOUSE, rbox(0.1, 2.0, 1.2, 0.03, 1), mat(0x6b4a2e), -2.53, 1.0, 1.5);
  [[-2.5, 0], [2.5, 0], [0, -2.5], [0, 2.5]].forEach(([x, z]) => P(HOUSE, rbox(x ? 0.12 : 5.2, 0.7, z ? 0.12 : 5.2, 0.04), r, x, 11.6, z)); })();
(function(){ const tr = mat(0x8a6a48), lf = mat(0x3f9a4a, { roughness: 0.9 });
  [[-9, -1], [-12.5, 3], [-7, 6]].forEach(([x, z], i) => { const t = P(BEACH, new THREE.CylinderGeometry(0.22, 0.32, 6, 8), tr, x, 3, z); t.rotation.z = 0.12 * (i % 2 ? 1 : -1);
    for (let k = 0; k < 6; k++){ const l = P(BEACH, rbox(2.6, 0.12, 0.7, 0.05), lf, x + Math.cos(k) * 1.1, 6.0, z + Math.sin(k) * 1.1); l.rotation.set(0, -k, -0.4); } }); })();
const CASTLE = new THREE.Group(); BEACH.add(CASTLE); CASTLE.position.set(1.25, 0, 1.25);
(function(){ const s = mat(0xd8bd85, { roughness: 1 }); P(CASTLE, rbox(1.4, 0.45, 0.9, 0.05), s, 0, 0.22, 0);
  [[-0.55, -0.3], [0.55, -0.3], [-0.55, 0.3], [0.55, 0.3]].forEach(([x, z]) => { P(CASTLE, new THREE.CylinderGeometry(0.2, 0.24, 0.8, 12), s, x, 0.4, z); P(CASTLE, new THREE.ConeGeometry(0.24, 0.32, 12), s, x, 0.96, z); });
  P(CASTLE, new THREE.CylinderGeometry(0.28, 0.32, 1.1, 12), s, 0, 0.55, 0); P(CASTLE, new THREE.ConeGeometry(0.32, 0.4, 12), s, 0, 1.3, 0);
  const b = P(CASTLE, new THREE.CylinderGeometry(0.35, 0.25, 0.5, 12), mat(0xe8452c), 1.3, 0.25, 0.3); P(CASTLE, rbox(0.06, 0.6, 0.06, 0.02, 1), mat(0x333333), 1.3, 0.75, 0.3); })();
const FISH = [];
[[-3, -8], [2.5, -10], [5.5, -7], [-6.5, -12]].forEach(([x, z]) => { const f = new THREE.Group(); f.position.set(x, 0.18, z); BEACH.add(f);
  const b = P(f, new THREE.SphereGeometry(1, 16, 10), mat(0xf08a2a, { roughness: 0.5 }), 0, 0, 0); b.scale.set(0.45, 0.2, 0.12); const t = P(f, new THREE.ConeGeometry(0.18, 0.3, 4), mat(0xf08a2a), -0.5, 0, 0); t.rotation.z = PI / 2; t.scale.z = 0.4; FISH.push(f); });
function WAVEG(){ const G = new THREE.Group(); const body = P(G, new THREE.BoxGeometry(600, 1, 16), mat(0x1d6d93, { roughness: 0.25, metalness: 0.1 }), 0, 0.5, -2);
  const cr = P(G, new THREE.CylinderGeometry(1, 1, 600, 24), mat(0x2f9bc4, { roughness: 0.2 }), 0, 1, 5.2); cr.rotation.z = PI / 2;
  const fo = P(G, new THREE.CylinderGeometry(1, 1, 600, 24), mat(0xf2fbff, { roughness: 0.6 }), 0, 1, 5.2); fo.rotation.z = PI / 2;
  G.userData = { body, cr, fo }; BEACH.add(G); return G; }
const W1 = WAVEG(), W2 = WAVEG();
function wave(G, z, H){ if (H <= 0.01){ G.visible = false; return; } G.visible = true; G.position.set(0, 0, z); const u = G.userData; u.body.scale.y = H; u.body.position.y = H / 2;
  const r = Math.max(0.3, H * 0.28); u.cr.scale.set(r, 1, r); u.cr.position.set(0, H - r * 0.2, 6 - 8 + r * 0.5); u.fo.scale.set(r * 0.55, 1, r * 0.55); u.fo.position.set(0, H + r * 0.55, 6 - 8 + r * 0.7); }

/* =========================================================
   BEN
   ========================================================= */
const SCAR = new THREE.Group(); ben.head.add(SCAR);
(function(){ const m = mat(0xa8463f, { roughness: 0.7 }); const s = new THREE.Mesh(rbox(0.075, 0.72, 0.03, 0.012, 1), m); s.position.set(0.25, 0.55, 0.522); s.rotation.z = -0.13; SCAR.add(s);
  for (const y of [0.36, 0.55, 0.74]){ const c = new THREE.Mesh(rbox(0.16, 0.035, 0.03, 0.01, 1), m); c.position.set(0.25 + (y - 0.55) * 0.13, y, 0.528); c.rotation.z = -0.13; SCAR.add(c); } })();
function sitPat(r, t){ sit(r, 0.1); const p = Math.max(0, Math.sin(t * 5)); r.sh[0].rotation.set(-1.0 - 0.25 * p, 0, -0.1); r.sh[1].rotation.set(-1.0 - 0.25 * Math.max(0, Math.sin(t * 5 + 1.6)), 0, 0.1); r.el[0].rotation.x = -0.5; r.el[1].rotation.x = -0.5; r.torso.rotation.x = 0.3; r.head.rotation.x = 0.25; }

/* =========================================================
   KAMERA + Zustand
   ========================================================= */
const cL = new THREE.Vector3();
let blurAmt = 0, fadeBlk = 0, T = 0, flashA = 0, eyeS = 1, talk = 0, dT = 0;
let warnK = 0, diaK = 0, minK = 0, wavK = 0;
function camW(p, a, b){ cam.position.set(lerp(a[0], b[0], p), lerp(a[1], b[1], p), lerp(a[2], b[2], p)); cL.set(lerp(a[3], b[3], p), lerp(a[4], b[4], p), lerp(a[5], b[5], p)); cam.fov = lerp(a[6], b[6], p); }
function camFin(sh){ cam.position.x += Math.sin(dT * 0.7) * 0.02; cam.position.y += Math.sin(dT * 0.9 + 1) * 0.015; if (sh){ cam.position.x += Math.sin(T * 23) * sh; cam.position.y += Math.cos(T * 17) * sh; } cam.up.set(0, 1, 0); cam.lookAt(cL); cam.updateProjectionMatrix(); cam.updateMatrixWorld(); }
const imp = at => T >= at ? Math.exp(-(T - at) * 3) : 0;
const HOOK = [[1.4, 6.2, 12.5, 0.5, 2.0, -6, 40], [1.2, 5.9, 11.4, 0.5, 1.9, -6, 40]];
function base(){ show(ben); W1.visible = W2.visible = false; sea(-4, 0.06); FISH.forEach(f => f.visible = false); CASTLE.visible = true; HOUSE.visible = true; }
function recede(t){ return -4 - 26 * E.io(seg(t, 0.3, 4.6)); }
function fishes(zs, t){ FISH.forEach((f, i) => { f.visible = f.position.z > zs + 0.5; f.rotation.set(0, i * 1.3, 0.5 * Math.sin(t * 7 + i * 2)); f.position.y = 0.18 + 0.12 * Math.max(0, Math.sin(t * 7 + i * 2)); }); }
function hookBen(t){ bRest(ben, t, 0); place(ben, 0, 0, 0, 0); sitPat(ben, t); const lk = E.io(seg(t, 1.6, 2.4)); ben.head.rotation.y = -1.2 * lk; ben.torso.rotation.y = -0.25 * lk; if (lk > 0.3){ ben.sh[0].rotation.x *= 0.5; ben.sh[1].rotation.x *= 0.5; } eyeS = 1 + 0.3 * lk; bFace(ben, -0.4 * lk, 0.25 * lk); }

/* =========================================================
   SZENEN (Sprecherspur Tempo 1,2)
   ========================================================= */
const SCN = [
  { t: 0, set: BEACH, mood: MOOD.beach, hook: 1,
    upd(lt){ dT = T; base(); hookBen(T); const zs = recede(T); sea(zs, 0.06); fishes(zs, T); camW(E.io(seg(lt, 0, 3.27)), HOOK[0], HOOK[1]); camFin(); } },
  { t: 3.27, set: BEACH, mood: MOOD.beach, hud: () => ['WARNZEICHEN!', 'TSUNAMI MÖGLICH'],
    upd(lt){ dT = T; base(); const zs = recede(T); sea(zs, 0.06); fishes(zs, T); bRest(ben, T, 0); const up = E.io(seg(T, 3.3, 3.9));
      place(ben, 0, 0, 0, PI * 0.82 * up); if (up < 1){ sit(ben, 0.1 + 0.82 * up); ben.legs[0].rotation.x *= 1 - up; ben.legs[1].rotation.x *= 1 - up; ben.body.position.y = lerp(0.28, 1, up); }
      eyeS = 1.3; bFace(ben, -0.6, 0.3); warnK = E.out(seg(T, 3.6, 3.9)) * (1 - seg(T, 5.5, 5.67));
      camW(E.io(seg(lt, 0, 2.4)), [1.6, 4.4, 13.5, 0, 1.0, -14, 40], [1.4, 4.6, 12.5, 0, 0.9, -16, 40]); camFin(); } },
  { t: 5.67, set: BEACH, mood: MOOD.beach, hud: () => ['ÜBER 700 KM/H', 'SO SCHNELL WIE EIN FLUGZEUG'],
    upd(lt){ dT = T; base(); sea(-30, 0.06); fishes(-30, T); bRest(ben, T, 0); place(ben, 0, 0, 0, PI * 0.82); eyeS = 1.3; bFace(ben, -0.6, 0.3);
      diaK = E.out(seg(T, 5.8, 6.1)); camW(E.io(seg(lt, 0, 5.45)), [1.5, 9, 22, 0, 3, -40, 40], [1.2, 8.6, 20, 0, 3, -40, 40]); camFin(); } },
  { t: 11.12, set: BEACH, mood: MOOD.beach, hud: () => ['AM UFER LANGSAMER', 'UND VIEL HÖHER'],
    upd(lt){ dT = T; base(); sea(-30, 0.06); fishes(-30, T); bRest(ben, T, 0); place(ben, 0, 0, 0, PI * 0.82); eyeS = 1.4; bFace(ben, -0.9, 0.5);
      const k = seg(T, 11.12, 13.88); wave(W1, lerp(-230, -70, k), lerp(2, 9, E.io(k))); diaK = 1 - seg(T, 13.6, 13.88);
      camW(E.io(seg(lt, 0, 2.76)), [1.2, 8.6, 20, 0, 3, -40, 40], [1.0, 7.6, 18, 0, 3.6, -40, 40]); camFin(); } },
  { t: 13.88, set: BEACH, mood: MOOD.beach, hud: () => T < 17.2 ? ['NUR MINUTEN!', 'SOFORT WEG – NACH OBEN'] : ['HOCH IN EIN FESTES HAUS', 'ODER BERGAUF'],
    upd(lt){ dT = T; base(); minK = E.out(seg(T, 14.0, 14.3)) * (1 - seg(T, 18.9, 19.17)); const k = seg(T, 13.88, 19.17);
      const br = E.out(seg(T, 18.2, 19.0)), wz = lerp(-70, -6, E.io(seg(T, 13.88, 18.2))) + 16 * br, wh = lerp(lerp(9, 14, E.io(seg(T, 13.88, 18.2))), 1.6, br); wave(W1, wz, wh); sea(T < 18.2 ? -30 + 24 * seg(T, 16.5, 18.2) : wz, 0.06 + 1.6 * br);
      bRest(ben, T, 0);
      if (T < 16.8){ const r = E.io(seg(T, 14.1, 16.6)); place(ben, lerp(0, 6.0, r), 0, lerp(0, 3.0, r), lerp(PI * 0.82, 1.1, seg(T, 14.1, 14.4))); if (T > 14.2 && T < 16.6) wlk(ben, T * 13, 1); eyeS = 1.3; bFace(ben, -0.8, 0.5);
        camW(E.io(seg(T, 13.88, 16.8)), [-6, 5.5, 16, 2, 1.6, -1, 40], [-1, 6.5, 19, 6, 2.0, 1, 40]); camFin(); }
      else { CASTLE.visible = false; const up = E.out(seg(T, 16.8, 17.5)); place(ben, 8.6, 11.25 - 1.2 * (1 - up), 3.6, 0.2); bFace(ben, -0.7, 0.4); eyeS = 1.3;
        ben.sh[0].rotation.set(-0.3, 0, -0.5); ben.sh[1].rotation.set(-0.3, 0, 0.5);
        camW(E.io(seg(T, 16.8, 19.17)), [10.4, 12.8, 21, 8.4, 11.6, -12, 40], [10.2, 12.6, 19.6, 8.4, 11.6, -12, 40]); camFin(0.04 * seg(T, 18.2, 19.0)); } } },
  { t: 19.17, set: BEACH, mood: MOOD.beach, hud: () => ['NICHT ZURÜCK!', 'OFT KOMMEN MEHRERE WELLEN'],
    upd(lt){ dT = T; base(); CASTLE.visible = false; sea(60, 1.66 + 0.15 * Math.sin(T * 1.3)); wave(W2, lerp(-140, -70, seg(T, 19.17, 21.92)), 9); bRest(ben, T, 0); place(ben, 8.6, 11.25, 3.6, 0.2);
      ben.sh[1].rotation.set(-2.6, 0, 0.3 + 0.25 * Math.sin(T * 8)); eyeS = 1.2; bFace(ben, -0.5, 0.2); wavK = E.out(seg(T, 19.5, 19.8)) * (1 - seg(T, 21.7, 21.92));
      camW(E.io(seg(lt, 0, 2.75)), [10.2, 12.6, 19.6, 8.4, 11.6, -12, 40], [10.0, 12.4, 18.6, 8.4, 11.6, -12, 40]); camFin(); } },
  { t: 21.92, set: BEACH, mood: MOOD.beach, hud: () => ['UND BEN?', 'NÄCHSTE SANDBURG'],
    upd(lt){ dT = T - END; base(); hookBen(T - END); camW(E.io(seg(T, 21.92, 23.95)), [4.5, 5.0, 11.0, 0.4, 1.6, -4, 40], HOOK[0]); camFin(); } },
  { t: 24.0, set: BEACH, mood: MOOD.beach, loopin: 1,
    upd(lt){ dT = T - END; base(); hookBen(T - END); camW(0, HOOK[0], HOOK[1]); camFin(); } },
];
const SUBS = __SUBS__;
