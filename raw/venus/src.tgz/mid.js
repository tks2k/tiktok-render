/* =========================================================
   STIMMUNG: Venus (dichter orange Dunst, dämmrig) + Zuhause
   ========================================================= */
function sky(stops){
  const c = document.createElement('canvas'); c.width = 4; c.height = 256; const x = c.getContext('2d'), g = x.createLinearGradient(0, 0, 0, 256);
  stops.forEach(s => g.addColorStop(s[0], s[1])); x.fillStyle = g; x.fillRect(0, 0, 4, 256); const t = new THREE.CanvasTexture(c); t.encoding = THREE.sRGBEncoding; return t;
}
const MOOD = { ven: { sky: sky([[0, '#6a3a12'], [0.45, '#b8641e'], [1, '#e89a3a']]), fog: [0xc87a30, 14, 80], hemi: [0xffd8a0, 0x4a2a10, 0.95], sun: [0xffc880, 0.7] },
  home: { sky: sky([[0, '#e8d8c0'], [1, '#e8d8c0']]), fog: [0xe8d8c0, 40, 120], hemi: [0xfff6ea, 0x8a7a68, 1.0], sun: [0xfff2e0, 0.9] } };
const SR = 14; { const c = sun.shadow.camera; c.left = -SR; c.right = SR; c.top = SR; c.bottom = -SR; c.near = 1; c.far = 120; c.updateProjectionMatrix(); }
function setMood(m){
  scene.background = m.sky; scene.fog.color.set(m.fog[0]); scene.fog.near = m.fog[1]; scene.fog.far = m.fog[2]; scene.environment = envDay;
  hemi.color.set(m.hemi[0]); hemi.groundColor.set(m.hemi[1]); hemi.intensity = m.hemi[2]; sun.color.set(m.sun[0]); sun.intensity = m.sun[1];
  sun.position.set(-10, 26, 14); sun.target.position.set(0, 0, 0); fill.color.set(0xffc890); fill.intensity = 0.35; fill.position.set(10, 8, 20);
}

/* =========================================================
   SET: Venus – flache Basaltplatten, Vulkane im Dunst, Wolkendecke
   ========================================================= */
const VEN = new THREE.Group(); scene.add(VEN);
(function(){
  const g = new THREE.Mesh(new THREE.PlaneGeometry(300, 300), mat(0x5a4030, { roughness: 1 })); g.rotation.x = -PI / 2; g.receiveShadow = true; VEN.add(g);
  const pm = [mat(0x6a4a34, { roughness: 1, flatShading: true }), mat(0x4a3426, { roughness: 1, flatShading: true })];
  for (let i = 0; i < 60; i++){ const x = (hsh(i) - 0.5) * 46, z = -1 - hsh(i + 9) * 36 + (hsh(i + 3) < 0.25 ? 26 : 0); if (Math.abs(z) < 4 && Math.abs(x) < 7) continue;
    const s = P(VEN, new THREE.CylinderGeometry(0.6 + hsh(i + 5) * 1.4, 0.8 + hsh(i + 5) * 1.4, 0.12, 5 + (i % 3)), pm[i % 2], x, 0.06, z); s.rotation.y = hsh(i) * 3; }
  const vm = mat(0x6a3a20, { roughness: 1, flatShading: true });
  for (let i = 0; i < 6; i++){ const h = 10 + hsh(i * 4) * 8; P(VEN, new THREE.ConeGeometry(16 + hsh(i) * 8, h, 7), vm, -60 + i * 24, h / 2 - 1, -55 - hsh(i * 2) * 15); }
  // Wolkendecke aus Schwefelsäure
  const cm = new THREE.MeshStandardMaterial({ color: 0xe8c060, roughness: 1, transparent: true, opacity: 0.92, fog: false });
  for (let i = 0; i < 40; i++){ const c = new THREE.Mesh(new THREE.SphereGeometry(5 + hsh(i) * 5, 12, 8), cm); c.position.set((hsh(i + 1) - 0.5) * 90, 34 + hsh(i + 2) * 4, -10 - hsh(i + 3) * 60); c.scale.y = 0.4; VEN.add(c); }
})();
// Tropfen, die unterwegs verdampfen (Virga)
const DROPS = []; { const dm = new THREE.MeshBasicMaterial({ color: 0xf2e08a, transparent: true, opacity: 0.8, fog: false }); for (let i = 0; i < 40; i++){ const d = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 1.6, 5), dm.clone()); VEN.add(d); DROPS.push(d); } }
function drops(on, t){ DROPS.forEach((d, i) => { d.visible = on; if (!on) return; const ph = (t * 0.45 + hsh(i * 7)) % 1, y = 33 - ph * 20; d.position.set((hsh(i * 3) - 0.5) * 40, y, -8 - hsh(i * 5) * 30); d.material.opacity = 0.85 * clamp01(1 - ph * 1.25); d.scale.y = 1 - ph * 0.7; }); }
const LND = new THREE.Group(); VEN.add(LND); const LX = -3.4, LZ = -1.8;
(function(){ const w = mat(0xe8e8ec, { roughness: 0.4, metalness: 0.3 }), d = mat(0x3a3a44, { metalness: 0.5, roughness: 0.4 }), gd = mat(0xd8a830, { metalness: 0.7, roughness: 0.3 });
  P(LND, new THREE.CylinderGeometry(1.3, 1.5, 1.6, 12), gd, 0, 1.6, 0); P(LND, new THREE.CylinderGeometry(0.6, 1.3, 1.2, 12), w, 0, 3.0, 0);
  [0, 1, 2, 3].forEach(k => { const a = k * PI / 2 + PI / 4; rod(LND, d, [Math.cos(a) * 1.2, 1.2, Math.sin(a) * 1.2], [Math.cos(a) * 2.0, 0.08, Math.sin(a) * 2.0], 0.07); P(LND, new THREE.CylinderGeometry(0.28, 0.3, 0.08, 10), d, Math.cos(a) * 2.0, 0.04, Math.sin(a) * 2.0); });
  P(LND, rbox(0.9, 1.2, 0.1, 0.03), d, 0, 1.6, 1.47); })();
const FLM = new THREE.Mesh(new THREE.ConeGeometry(0.6, 2.2, 14, 1, true), new THREE.MeshBasicMaterial({ color: 0xffb050, transparent: true, opacity: 0.7, blending: THREE.AdditiveBlending, depthWrite: false, fog: false })); FLM.rotation.x = PI; FLM.position.y = -0.1; LND.add(FLM);
// Getränkedose (wird vom Druck zerquetscht)
const CAN = new THREE.Group(); VEN.add(CAN);
(function(){ P(CAN, new THREE.CylinderGeometry(0.33, 0.33, 0.9, 18), mat(0xd03030, { metalness: 0.6, roughness: 0.3 }), 0, 0.45, 0); P(CAN, new THREE.CylinderGeometry(0.3, 0.33, 0.06, 18), mat(0xc8c8cc, { metalness: 0.8, roughness: 0.3 }), 0, 0.93, 0); })();
// Venera-Sonde (raucht)
const PRB = new THREE.Group(); VEN.add(PRB);
(function(){ const s = mat(0xb8b8bc, { metalness: 0.6, roughness: 0.4 }), dk = mat(0x3a3a40, { metalness: 0.4, roughness: 0.5 });
  P(PRB, new THREE.TorusGeometry(1.5, 0.22, 8, 24), dk, 0, 0.25, 0).rotation.x = PI / 2; P(PRB, new THREE.SphereGeometry(1.1, 18, 12), s, 0, 1.35, 0);
  P(PRB, new THREE.CylinderGeometry(0.35, 0.5, 0.9, 12), s, 0, 2.6, 0); P(PRB, new THREE.CylinderGeometry(0.9, 0.9, 0.08, 18), dk, 0, 3.1, 0);
  for (let k = 0; k < 6; k++){ const a = k * PI / 3; P(PRB, rbox(0.1, 0.5, 0.35, 0.03, 1), dk, Math.cos(a) * 1.5, 0.55, Math.sin(a) * 1.5).rotation.y = -a; } })();
const SMK = []; { const sm = new THREE.MeshStandardMaterial({ color: 0x4a4038, transparent: true, opacity: 0.5, roughness: 1, depthWrite: false }); for (let i = 0; i < 14; i++){ const m = new THREE.Mesh(new THREE.SphereGeometry(0.4, 10, 8), sm.clone()); PRB.add(m); SMK.push(m); } }
function smoke(t){ SMK.forEach((m, i) => { const ph = (t * 0.35 + i / SMK.length) % 1; m.position.set(Math.sin(i * 2.1) * 0.4 + ph * 1.2, 3.1 + ph * 5, Math.cos(i * 1.7) * 0.3); m.scale.setScalar(0.6 + ph * 2.2); m.material.opacity = 0.55 * Math.sin(PI * ph); }); }
// Zuhause: Wohnzimmer
const HOME = new THREE.Group(); scene.add(HOME);
(function(){ const fl = new THREE.Mesh(new THREE.PlaneGeometry(40, 40), mat(0xb8885a, { roughness: 0.8 })); fl.rotation.x = -PI / 2; fl.receiveShadow = true; HOME.add(fl);
  const wl = mat(0xe8dcc8, { roughness: 1 }); P(HOME, rbox(20, 9, 0.3, 0.02, 1), wl, 0, 4.5, -4);
  P(HOME, rbox(4.0, 3.0, 0.2, 0.04, 1), mat(0x5a3a22), 4.2, 4.6, -3.8); P(HOME, rbox(3.6, 2.6, 0.1, 0.02, 1), new THREE.MeshBasicMaterial({ color: 0x8ac8f0 }), 4.2, 4.6, -3.68);
  const so = mat(0x3a6a9a, { roughness: 0.9 }); P(HOME, rbox(4.4, 0.9, 1.8, 0.2), so, 0, 0.75, -2.2); P(HOME, rbox(4.4, 1.6, 0.5, 0.2), so, 0, 1.6, -2.95); [-1, 1].forEach(s => P(HOME, rbox(0.5, 1.3, 1.8, 0.18), so, s * 2.2, 1.0, -2.2));
  P(HOME, rbox(1.6, 0.12, 1.6, 0.06), mat(0xe8b860), -3.6, 0.9, -1.2); P(HOME, new THREE.CylinderGeometry(0.1, 0.1, 0.85, 8), mat(0x5a3a22), -3.6, 0.42, -1.2);
  const pz = P(HOME, new THREE.CylinderGeometry(0.7, 0.7, 0.06, 6, 1, false, 0, PI * 2 * 5 / 6), mat(0xe8a040), -3.6, 1.0, -1.2); P(HOME, new THREE.CylinderGeometry(0.6, 0.6, 0.07, 6, 1, false, 0, PI * 2 * 5 / 6), mat(0xd04a2a), -3.6, 1.02, -1.2);
  const lp = mat(0xd8d0c0); P(HOME, new THREE.CylinderGeometry(0.08, 0.08, 3.4, 8), lp, 3.4, 1.7, -2.6); P(HOME, new THREE.ConeGeometry(0.6, 0.7, 14, 1, true), mat(0xf2e8c8), 3.4, 3.6, -2.6);
})();
const SLICE = new THREE.Group(); ben.el[1].add(SLICE);
(function(){ const s = new THREE.Mesh(new THREE.CylinderGeometry(0.6, 0.6, 0.06, 3, 1, false, 0, PI / 3), mat(0xe8a040)); s.rotation.set(PI / 2, 0, 0); s.position.set(0, -0.66, 0.25); SLICE.add(s); })();
const SETS = [VEN, HOME];

/* =========================================================
   BEN: Narbe, Raumanzug (glüht bei Hitze)
   ========================================================= */
const SCAR = new THREE.Group(); ben.head.add(SCAR);
(function(){ const m = mat(0xa8463f, { roughness: 0.7 }); const s = new THREE.Mesh(rbox(0.075, 0.72, 0.03, 0.012, 1), m); s.position.set(0.25, 0.55, 0.522); s.rotation.z = -0.13; SCAR.add(s);
  for (const y of [0.36, 0.55, 0.74]){ const c = new THREE.Mesh(rbox(0.16, 0.035, 0.03, 0.01, 1), m); c.position.set(0.25 + (y - 0.55) * 0.13, y, 0.528); c.rotation.z = -0.13; SCAR.add(c); } })();
const SUIT = new THREE.Group(); const HELM = new THREE.Group(); ben.head.add(HELM); ben.torso.add(SUIT);
const PACKM = new THREE.MeshStandardMaterial({ color: 0xe8e8ec, roughness: 0.5, emissive: 0xff4a10, emissiveIntensity: 0 });
(function(){ const gl = new THREE.Mesh(new THREE.SphereGeometry(0.98, 24, 18), new THREE.MeshStandardMaterial({ color: 0xcfeaff, transparent: true, opacity: 0.22, roughness: 0.05, metalness: 0.2, depthWrite: false })); gl.position.y = 0.58; gl.renderOrder = 3; HELM.add(gl);
  const ring = new THREE.Mesh(new THREE.TorusGeometry(0.62, 0.1, 10, 28), PACKM); ring.rotation.x = PI / 2; ring.position.y = -0.08; HELM.add(ring);
  P(SUIT, rbox(0.9, 0.95, 0.42, 0.08), PACKM, 0, 0.55, -0.5); P(SUIT, rbox(0.5, 0.18, 0.06, 0.03, 1), mat(0xd04030), 0, 0.85, -0.73);
  rod(SUIT, mat(0x8a8a90), [0.3, 0.95, -0.4], [0.3, 1.25, 0.0], 0.05); })();
function suit(on){ SUIT.visible = on; HELM.visible = on; }
function crouch(k){ ben.legs[0].rotation.x = -0.6 * k; ben.legs[1].rotation.x = -0.6 * k; ben.body.position.y = 1 - 0.18 * k; ben.torso.rotation.x = 0.25 * k; }
const GV = 17.7;   // Venus-Schwerkraft 8,87 m/s² ≈ 17,7 E/s²

/* =========================================================
   KAMERA + Zustand
   ========================================================= */
const cL = new THREE.Vector3();
let blurAmt = 0, fadeBlk = 0, T = 0, flashA = 0, eyeS = 1, talk = 0, dT = 0;
let heatK = 0, presK = 0, acidK = 0, probK = 0, homeK = 0, warmK = 0;
function camW(p, a, b){ cam.position.set(lerp(a[0], b[0], p), lerp(a[1], b[1], p), lerp(a[2], b[2], p)); cL.set(lerp(a[3], b[3], p), lerp(a[4], b[4], p), lerp(a[5], b[5], p)); cam.fov = lerp(a[6], b[6], p); }
function camFin(sh){ cam.position.x += Math.sin(dT * 0.7) * 0.03; cam.position.y += Math.sin(dT * 0.9 + 1) * 0.02; if (sh){ cam.position.x += Math.sin(T * 23) * sh; cam.position.y += Math.cos(T * 17) * sh; } cam.up.set(0, 1, 0); cam.lookAt(cL); cam.updateProjectionMatrix(); cam.updateMatrixWorld(); }
const TD = 1.3, TJ = 2.1;
const HOOK = [[1.6, 4.2, 12.5, -2.0, 4.4, -1.4, 48], [1.4, 4.0, 12.2, -2.0, 4.0, -1.4, 48]];
const BX = LX + 2.6, BZ = LZ + 1.9;
function base(){ show(ben); suit(true); SLICE.visible = false; LND.position.set(LX, 0, LZ); FLM.visible = false; CAN.position.set(BX + 1.6, 0, BZ + 0.6); CAN.scale.set(1, 1, 1); PRB.position.set(BX - 6.5, 0, BZ - 4.0); PACKM.emissiveIntensity = 0; drops(false, 0); }
function hookScene(t){ const ld = E.out(seg(t, -0.4, TD)); LND.position.y = 7 * (1 - ld); FLM.visible = t < TD + 0.1; FLM.scale.set(1, 0.8 + 0.25 * Math.sin(t * 9), 1);
  bRest(ben, t, 0); const s = t - TJ;
  if (s < 0){ ben.root.visible = t > TJ - 0.5; place(ben, LX, 0.9 + LND.position.y, LZ + 1.0, 0); crouch(seg(t, TJ - 0.5, TJ)); }
  else { const v = 1.6, tf = (v + Math.sqrt(v * v + 2 * GV * 0.9)) / GV, k = Math.min(s, tf), y = Math.max(0, 0.9 + v * k - GV / 2 * k * k);
    place(ben, LX + 2.6 * Math.min(1, k / tf), y, LZ + 1.0 + 0.9 * Math.min(1, k / tf), 0.3); if (s < tf){ ben.sh[0].rotation.set(-0.3, 0, -1.0); ben.sh[1].rotation.set(-0.3, 0, 1.0); ben.legs[0].rotation.x = -0.4; ben.legs[1].rotation.x = 0.2; } else crouch(0.7 * Math.exp(-(s - tf) * 5)); }
  eyeS = 1.2; bFace(ben, 0.6, 0.2); }

/* =========================================================
   SZENEN (Sprecherspur Tempo 1,0)
   ========================================================= */
const SCN = [
  { t: 0, set: VEN, mood: MOOD.ven, hook: 1,
    upd(lt){ dT = T; base(); hookScene(T); camW(E.io(seg(lt, 0, 3.68)), HOOK[0], [1.2, 2.8, 10.2, -1.4, 1.8, -0.6, 48]); camFin(0.03 * bump(T, TD, TD + 0.4)); } },
  { t: 3.68, set: VEN, mood: MOOD.ven, hud: () => ['465 °C', 'HEISSER ALS EIN PIZZAOFEN'],
    upd(lt){ dT = T; base(); bRest(ben, T, 0); place(ben, BX, 0, BZ, 0.25); const h = seg(T, 4.0, 8.0); PACKM.emissiveIntensity = 0.55 * h;
      ben.sh[0].rotation.set(-0.4, 0, -0.5 - 0.15 * Math.sin(T * 5)); ben.sh[1].rotation.set(-0.4, 0, 0.5 + 0.15 * Math.sin(T * 5)); eyeS = 1.3; bFace(ben, -0.8, 0.5); ben.torso.rotation.z = 0.04 * Math.sin(T * 3);
      heatK = E.out(seg(T, 3.9, 4.2)) * (1 - seg(T, 8.5, 8.68)); warmK = 0.35 * h * (1 - seg(T, 8.5, 8.68));
      camW(E.io(seg(lt, 0, 5.0)), [BX + 2.8, 2.6, BZ + 7.6, BX, 2.2, BZ, 46], [BX + 1.8, 2.4, BZ + 5.8, BX, 2.3, BZ, 46]); camFin(); } },
  { t: 8.68, set: VEN, mood: MOOD.ven, hud: () => ['90-FACHER DRUCK', 'WIE 900 M UNTER WASSER'],
    upd(lt){ dT = T; base(); bRest(ben, T, 0); PACKM.emissiveIntensity = 0.45; const c = E.out(seg(T, 9.4, 10.3)); CAN.scale.set(1 + 0.35 * c, 1 - 0.72 * c, 1 + 0.25 * c);
      const sq = seg(T, 10.6, 11.6); place(ben, BX, 0, BZ, 0.25); crouch(0.55 * sq + 0.05 * Math.sin(T * 8) * sq); ben.sh[0].rotation.set(-0.2, 0, -0.9); ben.sh[1].rotation.set(-0.2, 0, 0.9);
      eyeS = 1.4 - 0.6 * sq; bFace(ben, -1, 0.3 + 0.4 * sq); presK = E.out(seg(T, 8.9, 9.2)) * (1 - seg(T, 14.05, 14.2));
      camW(E.io(seg(lt, 0, 5.52)), [BX + 4.2, 1.6, BZ + 5.4, BX + 0.8, 1.2, BZ + 0.3, 46], [BX + 3.4, 2.2, BZ + 6.6, BX + 0.6, 1.6, BZ, 46]); camFin(0.012 * bump(T, 9.4, 10.3)); } },
  { t: 14.2, set: VEN, mood: MOOD.ven, hud: () => ['WOLKEN AUS SCHWEFELSÄURE', 'REGEN VERDAMPFT IN DER HITZE'],
    upd(lt){ dT = T; base(); bRest(ben, T, 0); PACKM.emissiveIntensity = 0.45; drops(true, T); place(ben, BX, 0, BZ, 0.25); crouch(0.55); lookUpB(0.9); eyeS = 1.3; bFace(ben, -0.6, 0.4);
      acidK = E.out(seg(T, 14.4, 14.7)) * (1 - seg(T, 16.7, 16.86));
      camW(E.io(seg(lt, 0, 2.66)), [BX + 2.6, 1.0, BZ + 6.0, BX - 1, 8, BZ - 10, 52], [BX + 2.6, 0.9, BZ + 6.4, BX - 1, 14, BZ - 14, 58]); camFin(); } },
  { t: 16.86, set: VEN, mood: MOOD.ven, hud: () => ['RAUMSONDEN?', 'HIELTEN NUR GUT 2 STUNDEN'],
    upd(lt){ dT = T; base(); bRest(ben, T, 0); PACKM.emissiveIntensity = 0.45; smoke(T); place(ben, BX, 0, BZ, -1.3); crouch(0.55); ben.head.rotation.y = -0.5; eyeS = 1.4; bFace(ben, -0.9, 0.5);
      probK = E.out(seg(T, 17.1, 17.4)) * (1 - seg(T, 20.3, 20.48));
      camW(E.io(seg(lt, 0, 3.62)), [BX + 3.0, 3.0, BZ + 6.5, BX - 3.6, 1.8, BZ - 2.4, 48], [BX + 2.0, 2.6, BZ + 5.2, BX - 3.8, 1.8, BZ - 2.6, 48]); camFin(); } },
  { t: 20.48, set: HOME, mood: MOOD.home, hud: () => ['UND BEN?', 'BLEIBT AUF DER ERDE'],
    upd(lt){ dT = T; show(ben); suit(false); SLICE.visible = true; bRest(ben, T, 0); place(ben, 0.2, 0, -2.0, 0); sit(ben, 1.1); ben.sh[1].rotation.set(-1.5 + 0.25 * Math.sin(T * 3), 0, 0.2); ben.el[1].rotation.x = -0.9;
      eyeS = 1; bFace(ben, 0.7, 0.15 + 0.1 * Math.sin(T * 6)); homeK = E.out(seg(T, 21.0, 21.3)) * (1 - seg(T, 22.75, 22.9));
      camW(E.io(seg(lt, 0, 2.42)), [1.4, 2.6, 6.2, 0.4, 1.8, -2.0, 46], [1.1, 2.4, 5.4, 0.3, 1.8, -2.0, 46]); camFin(); } },
  { t: 22.9, set: VEN, mood: MOOD.ven, loopin: 1,
    upd(lt){ dT = T - END; base(); hookScene(T - END); camW(0, HOOK[0], HOOK[1]); camFin(); } },
];
function lookUpB(k){ ben.head.rotation.x = -0.55 * k; }
const SUBS = __SUBS__;
