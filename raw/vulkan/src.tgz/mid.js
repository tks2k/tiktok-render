/* =========================================================
   STIMMUNG: Krater (dunkel, Lava leuchtet)
   ========================================================= */
function sky(){
  const c = document.createElement('canvas'); c.width = 4; c.height = 512; const x = c.getContext('2d'), g = x.createLinearGradient(0, 0, 0, 512);
  g.addColorStop(0, '#1a1418'); g.addColorStop(0.6, '#4a2a22'); g.addColorStop(1, '#8a4a2a'); x.fillStyle = g; x.fillRect(0, 0, 4, 512);
  const t = new THREE.CanvasTexture(c); t.encoding = THREE.sRGBEncoding; return t;
}
const MOOD = { vol: { sky: sky(), fog: [0x3a2420, 40, 160], hemi: [0x8a7a80, 0xff7a2a, 0.9], sun: [0xffb070, 0.8], sp: [6, 14, 10] } };
const SR = 14; { const c = sun.shadow.camera; c.left = -SR; c.right = SR; c.top = SR; c.bottom = -SR; c.near = 1; c.far = 60; c.updateProjectionMatrix(); }
function setMood(m){
  scene.background = m.sky; scene.fog.color.set(m.fog[0]); scene.fog.near = m.fog[1]; scene.fog.far = m.fog[2]; scene.environment = envNight;
  hemi.color.set(m.hemi[0]); hemi.groundColor.set(m.hemi[1]); hemi.intensity = m.hemi[2]; sun.color.set(m.sun[0]); sun.intensity = m.sun[1];
  sun.position.set(m.sp[0], m.sp[1], m.sp[2]); sun.target.position.set(0, 0, 0); fill.color.set(0xff8a40); fill.intensity = 0.6; fill.position.set(0, -6, 6);
}

/* =========================================================
   SET: Krater + Lavasee
   ========================================================= */
const CRATER = new THREE.Group(); scene.add(CRATER); const SETS = [CRATER];
const LAVAX = (function(){ const c = document.createElement('canvas'); c.width = c.height = 512; const x = c.getContext('2d'); x.fillStyle = '#7a1208'; x.fillRect(0, 0, 512, 512);
  let sd = 5; const r = () => { sd = (sd * 16807) % 2147483647; return sd / 2147483647; };
  for (let i = 0; i < 60; i++){ const px = r() * 512, py = r() * 512, q = 30 + r() * 70, g = x.createRadialGradient(px, py, 0, px, py, q); g.addColorStop(0, r() < 0.5 ? 'rgba(255,210,80,0.9)' : 'rgba(255,120,30,0.85)'); g.addColorStop(1, 'rgba(255,80,20,0)'); x.fillStyle = g; x.fillRect(px - q, py - q, 2 * q, 2 * q); }
  const t = new THREE.CanvasTexture(c); t.encoding = THREE.sRGBEncoding; t.wrapS = t.wrapT = THREE.RepeatWrapping; t.repeat.set(3, 3); return t; })();
const LAVA = new THREE.Mesh(new THREE.CircleGeometry(16, 64), new THREE.MeshBasicMaterial({ map: LAVAX, fog: false })); LAVA.rotation.x = -PI / 2; CRATER.add(LAVA);
(function(){ const rk = mat(0x3a302e, { roughness: 1, flatShading: true }), rk2 = mat(0x4a3a34, { roughness: 1, flatShading: true });
  const wall = new THREE.Mesh(new THREE.CylinderGeometry(22, 15.5, 9, 28, 2, true), new THREE.MeshStandardMaterial({ color: 0x3e3230, roughness: 1, flatShading: true, side: THREE.BackSide })); wall.position.y = 4.4; wall.receiveShadow = true; CRATER.add(wall);
  P(CRATER, new THREE.CylinderGeometry(2.0, 2.8, 6.2, 9), rk, 0, 3.1, 15.0); P(CRATER, new THREE.CylinderGeometry(2.6, 3.0, 0.8, 10), rk2, 0, 0.4, 9.5);
  [[-8, 0.3, -6, 1.6], [7, 0.4, -9, 2.2], [-11, 0.4, 4, 1.8], [10, 0.3, 3, 1.4]].forEach(([x, y, z, s]) => P(CRATER, new THREE.DodecahedronGeometry(s, 0), rk2, x, y, z));
})();
const STICK = new THREE.Group(); ben.el[1].add(STICK); STICK.position.set(0, -0.62, 0.1); P(STICK, rbox(0.06, 0.06, 3.4, 0.02, 1), mat(0x7a5232), 0, 0, 1.7); P(STICK, rbox(0.2, 0.2, 0.26, 0.06), mat(0xf6f0e6, { roughness: 0.9 }), 0, 0, 3.4);

/* =========================================================
   BEN
   ========================================================= */
const SCAR = new THREE.Group(); ben.head.add(SCAR);
(function(){ const m = mat(0xa8463f, { roughness: 0.7 }); const s = new THREE.Mesh(rbox(0.075, 0.72, 0.03, 0.012, 1), m); s.position.set(0.25, 0.55, 0.522); s.rotation.z = -0.13; SCAR.add(s);
  for (const y of [0.36, 0.55, 0.74]){ const c = new THREE.Mesh(rbox(0.16, 0.035, 0.03, 0.01, 1), m); c.position.set(0.25 + (y - 0.55) * 0.13, y, 0.528); c.rotation.z = -0.13; SCAR.add(c); } })();
// Rand: Ben steht auf dem Felsen (12.5 / y 6.2), schaut zur Lava (-z)
function rimBen(t){ bRest(ben, t, 0); place(ben, 0, 6.2, 13.4, PI); const w = Math.sin(t * 3.2); ben.root.rotation.x = 0.1 * w; ben.sh[0].rotation.set(0, 0, -1.2 - 0.3 * w); ben.sh[1].rotation.set(0, 0, 1.2 - 0.3 * w); ben.torso.rotation.x = 0.2; ben.head.rotation.x = 0.35; eyeS = 1.35; bFace(ben, -0.8, 0.45); }

/* =========================================================
   KAMERA + Zustand
   ========================================================= */
const cL = new THREE.Vector3();
let blurAmt = 0, fadeBlk = 0, T = 0, flashA = 0, eyeS = 1, talk = 0, dT = 0;
let tempK = 0, densK = 0, honK = 0, heatK = 0, gasK = 0;
function camW(p, a, b){ cam.position.set(lerp(a[0], b[0], p), lerp(a[1], b[1], p), lerp(a[2], b[2], p)); cL.set(lerp(a[3], b[3], p), lerp(a[4], b[4], p), lerp(a[5], b[5], p)); cam.fov = lerp(a[6], b[6], p); }
function camFin(sh){ cam.position.x += Math.sin(dT * 0.7) * 0.02; cam.position.y += Math.sin(dT * 0.9 + 1) * 0.015; if (sh){ cam.position.x += Math.sin(T * 23) * sh; cam.position.y += Math.cos(T * 17) * sh; } cam.up.set(0, 1, 0); cam.lookAt(cL); cam.updateProjectionMatrix(); cam.updateMatrixWorld(); }
const HOOK = [[5.6, 9.4, 2.0, 0, 8.9, 13.4, 45], [5.0, 9.2, 3.1, 0, 8.9, 13.4, 45]];
function base(){ show(ben); STICK.visible = false; LAVAX.offset.set(0.012 * dT, 0.008 * dT); }
function hookBen(t){ rimBen(t); }

/* =========================================================
   SZENEN (Sprecherspur Tempo 1,1)
   ========================================================= */
const SCN = [
  { t: 0, set: CRATER, mood: MOOD.vol, hook: 1,
    upd(lt){ dT = T; base(); hookBen(T); camW(E.io(seg(lt, 0, 2.69)), HOOK[0], HOOK[1]); camFin(); } },
  { t: 2.69, set: CRATER, mood: MOOD.vol, hud: () => ['BIS 1200 °C', 'FLÜSSIGES GESTEIN'],
    upd(lt){ dT = T; base(); rimBen(T); tempK = E.out(seg(T, 2.9, 3.2)) * (1 - seg(T, 5.4, 5.6)); camW(E.io(seg(lt, 0, 2.91)), [6, 10, -2, 0, 6.0, 11, 45], [5, 9.5, -0.5, 0, 6.3, 12, 45]); camFin(); } },
  { t: 5.6, set: CRATER, mood: MOOD.vol, hud: () => T < 7.45 ? ['VERSINKT ER?', 'NEIN!'] : ['LAVA: FAST 3× SO DICHT', 'WIE WASSER'],
    upd(lt){ dT = T; base(); bRest(ben, T, 0); const f = seg(T, 5.8, 6.9), y = lerp(6.2, 0.32, f * f), z = lerp(13.4, 4.5, f), lie = E.io(seg(T, 6.0, 6.9));
      place(ben, 0, y, z, PI); ben.root.rotation.x = -PI / 2 * lie; ben.sh[0].rotation.set(-2.5 * (1 - lie), 0, -0.8); ben.sh[1].rotation.set(-2.5 * (1 - lie), 0, 0.8); ben.legs[0].rotation.x = 0.3 * Math.sin(T * 10) * (1 - lie); ben.legs[1].rotation.x = -0.3 * Math.sin(T * 10) * (1 - lie);
      if (f >= 1) ben.root.position.y = 0.32 + 0.04 * Math.sin(T * 2.5); eyeS = 1.4; bFace(ben, -0.9, 0.5); densK = E.out(seg(T, 7.5, 7.8)) * (1 - seg(T, 9.55, 9.73));
      camW(E.io(seg(lt, 0.2, 1.7)), [9, 7.5, 9, 0, 5.5, 11, 50], [1.5, 9, 0, 0, -1, 6.5, 45]); camFin(0.05 * bump(T, 6.85, 7.2)); } },
  { t: 9.73, set: CRATER, mood: MOOD.vol, hud: () => ['ER BLEIBT OBEN', 'WIE AUF ZÄHEM HONIG'],
    upd(lt){ dT = T; base(); bRest(ben, T, 0); place(ben, 0, 0.32 + 0.04 * Math.sin(T * 2.5), 4.5, PI); ben.root.rotation.x = -PI / 2; ben.sh[0].rotation.set(0, 0, -0.8 - 0.15 * Math.sin(T * 3)); ben.sh[1].rotation.set(0, 0, 0.8 + 0.15 * Math.sin(T * 3));
      eyeS = 1.3; bFace(ben, -0.6, 0.3); honK = E.out(seg(T, 10.0, 10.3)) * (1 - seg(T, 12.6, 12.8)); camW(E.io(seg(lt, 0, 3.07)), [1.5, 9, 0, 0, -1, 6.5, 45], [1.2, 8.4, 0.8, 0, -1, 6.5, 45]); camFin(); } },
  { t: 12.8, set: CRATER, mood: MOOD.vol, hud: () => ['STRAHLUNGSHITZE', 'GEFÄHRLICH SCHON AUS METERN'],
    upd(lt){ dT = T; base(); bRest(ben, T, 0); const back = E.io(seg(T, 14.6, 15.8)); place(ben, 0, 0.8, lerp(8.0, 10.5, back), PI); ben.sh[0].rotation.set(-1.4, 0, -0.2); ben.sh[1].rotation.set(-1.4, 0, 0.2); ben.el[0].rotation.x = -1.2; ben.el[1].rotation.x = -1.2; ben.torso.rotation.x = -0.1;
      if (T > 14.6 && T < 15.8) wlk(ben, -T * 10, 0.8); eyeS = 1.3; bFace(ben, -0.8, 0.3); heatK = E.out(seg(T, 13.0, 13.3)) * (1 - seg(T, 17.25, 17.44));
      camW(E.io(seg(lt, 0, 4.64)), [4, 2.4, 0.8, 0, 1.1, 8.0, 45], [4, 2.4, 3.2, 0, 1.1, 10.5, 45]); camFin(); } },
  { t: 17.44, set: CRATER, mood: MOOD.vol, hud: () => ['GIFTIGE GASE', 'AM KRATERRAND'],
    upd(lt){ dT = T; base(); bRest(ben, T, 0); place(ben, 0, 0.8, 10.5, PI); const c = E.io(seg(T, 17.9, 18.4)); ben.sh[1].rotation.set(lerp(0, -2.3, c), 0, lerp(0.07, -0.4, c)); ben.el[1].rotation.x = lerp(-0.1, -1.6, c); eyeS = 0.7; bFace(ben, -0.8, 0);
      gasK = E.out(seg(T, 17.5, 17.9)) * (1 - seg(T, 20.35, 20.55)); camW(E.io(seg(lt, 0, 3.11)), [-4, 2.6, 3.4, 0, 1.1, 10.5, 45], [-3.6, 2.8, 4.0, 0, 1.1, 10.5, 45]); camFin(); } },
  { t: 20.55, set: CRATER, mood: MOOD.vol, hud: () => ['UND BEN?', 'MARSHMALLOWS – MIT ABSTAND'],
    upd(lt){ dT = T; base(); STICK.visible = true; bRest(ben, T, 0); place(ben, 0, 0.8, 9.5, PI); sit(ben, 0.05); ben.legs[0].rotation.x = -1.4; ben.legs[1].rotation.x = -1.4; ben.sh[1].rotation.set(-0.6, 0, 0.1); ben.el[1].rotation.x = -0.2; STICK.rotation.x = 0.35; eyeS = 1; bFace(ben, 0.6, 0.2);
      camW(E.io(seg(lt, 0, 2.8)), [10, 4.2, 6.2, 0, 1.7, 7.9, 55], [9.4, 4.0, 6.8, 0, 1.7, 7.9, 55]); camFin(); } },
  { t: 23.4, set: CRATER, mood: MOOD.vol, loopin: 1,
    upd(lt){ dT = T - END; base(); hookBen(T - END); camW(0, HOOK[0], HOOK[1]); camFin(); } },
];
const SUBS = __SUBS__;
