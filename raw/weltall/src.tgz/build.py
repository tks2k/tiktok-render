L=open('/home/claude/airbag.html').read().split('\n')
def idx(f):
    for i,l in enumerate(L):
        if f(l): return i
st=idx(lambda l:'STIMMUNGEN' in l)-1; ab=idx(lambda l:l.strip()=='ABLAUF')-1
pre='\n'.join(L[:st]); suf='\n'.join(L[ab:])
pre=pre.replace("powerPreference: 'high-performance' });","powerPreference: 'high-performance', logarithmicDepthBuffer: true });")
pre=pre.replace('END = 52.4','END = 22.4').replace('W / H, 0.1, 600)','W / H, 0.2, 3000)').replace('Was passiert, wenn dein Airbag auslöst?','Was wäre Ben? – Weltall ohne Anzug')
mid=open('mid.js').read().replace('__SUBS__',open('subs.json').read())
draw=open('draw.js').read()
helpers='''function proj(v){ V3.copy(v).project(cam); return V3.z < 1 ? [(V3.x + 1) / 2 * W, (1 - V3.y) / 2 * H] : null; }
function benMark(){ if (eyeS !== null) ben.eyes[0].scale.y = eyeS; ben.eyes[1].scale.y = 0.12; ben.eyes[1].position.y = 0.53; }
'''
A="curS = sc; curLt = T - sc.t; sc.upd(curLt);"
assert A in suf
suf=suf.replace(A,"talk = 0; skinK = boilK = lungK = timK = saveK = tethK = 0; ben.root.rotation.set(0, 0, 0); ben.head.rotation.set(0, 0, 0); curS = sc; curLt = T - sc.t; sc.upd(curLt); benMark();")
suf=suf.replace('airbag.$','was-waere-ben-weltall.$').replace('Was passiert, wenn dein Airbag auslöst?','Was wäre Ben? – Weltall ohne Anzug').replace('ca. 52 s','ca. 23 s')
html=pre+'\n'+mid+'\n'+helpers+draw+'\n'+suf
for k in ['logarithmicDepthBuffer','END = 22.4','0.2, 3000','benMark();']: assert k in html,k
open('video.html','w').write(html)
