/* =========================================================
   STIMMUNG: Weltraum (statischer Sternenhimmel)
   ========================================================= */
function sky(){
  const c = document.createElement('canvas'); c.width = 540; c.height = 960; const x = c.getContext('2d'), g = x.createLinearGradient(0, 0, 0, 960);
  g.addColorStop(0, '#02030a'); g.addColorStop(0.6, '#060a18'); g.addColorStop(1, '#0a1022'); x.fillStyle = g; x.fillRect(0, 0, 540, 960);
  let sd = 19; const r = () => { sd = (sd * 16807) % 2147483647; return sd / 2147483647; };
  for (let i = 0; i < 240; i++){ const px = r() * 540, py = r() * 960, s = 0.7 + r() * 1.4; x.globalAlpha = 0.3 + 0.55 * r(); x.fillStyle = '#ffffff'; x.beginPath(); x.arc(px, py, s, 0, 7); x.fill(); }
  x.globalAlpha = 1; const t = new THREE.CanvasTexture(c); t.encoding = THREE.sRGBEncoding; return t;
}
const MOOD = { space: { sky: sky(), fog: [0x000000, 900, 3000], hemi: [0x8090c0, 0x202838, 0.5], sun: [0xffffff, 1.6], sp: [12, 9, 14] } };
const SR = 14; { const c = sun.shadow.camera; c.left = -SR; c.right = SR; c.top = SR; c.bottom = -SR; c.near = 1; c.far = 90; c.updateProjectionMatrix(); }
function setMood(m){
  scene.background = m.sky; scene.fog.color.set(m.fog[0]); scene.fog.near = m.fog[1]; scene.fog.far = m.fog[2]; scene.environment = envNight;
  hemi.color.set(m.hemi[0]); hemi.groundColor.set(m.hemi[1]); hemi.intensity = m.hemi[2]; sun.color.set(m.sun[0]); sun.intensity = m.sun[1];
  sun.position.set(m.sp[0], m.sp[1], m.sp[2]); sun.target.position.set(0, 0, 0); fill.color.set(0x9fb4ff); fill.intensity = 0.45; fill.position.set(-12, 4, 14);
}

/* =========================================================
   SET: Raumstation + Erde
   ========================================================= */
const SPACE = new THREE.Group(); scene.add(SPACE); const SETS = [SPACE];
const HATCH = new THREE.Group();
(function(){
  const hull = mat(0xdfe3ea, { roughness: 0.45, metalness: 0.3 }), dark = mat(0x9aa2ae, { roughness: 0.5, metalness: 0.4 });
  const c = P(SPACE, new THREE.CylinderGeometry(3, 3, 18, 48), hull, -2, 1.2, -6); c.rotation.z = PI / 2;
  [-8, -2, 4].forEach(x => { const r = P(SPACE, new THREE.TorusGeometry(3.02, 0.12, 10, 48), dark, x, 1.2, -6); r.rotation.y = PI / 2; });
  const e = P(SPACE, new THREE.CylinderGeometry(2.2, 3, 2, 40), dark, 8, 1.2, -6); e.rotation.z = -PI / 2;
  const sp = mat(0x1f3f8a, { roughness: 0.35, metalness: 0.5 }), fr = mat(0xb08a3a, { roughness: 0.5, metalness: 0.6 });
  [-1, 1].forEach(s => { P(SPACE, rbox(0.3, 0.3, 9, 0.05, 1), dark, -7, 1.2, -6 + s * 7.5); for (let k = 0; k < 2; k++){ P(SPACE, rbox(3.2, 0.08, 4.0, 0.03, 1), sp, -8.8 + k * 3.6, 1.2, -6 + s * 8.2); P(SPACE, rbox(3.3, 0.1, 0.12, 0.03, 1), fr, -8.8 + k * 3.6, 1.2, -6 + s * 8.2); } });
  const ring = P(SPACE, new THREE.TorusGeometry(1.35, 0.2, 12, 40), dark, 1.6, 1.4, -2.98);
  const hole = new THREE.Mesh(new THREE.CircleGeometry(1.3, 40), new THREE.MeshBasicMaterial({ color: 0x14171d })); hole.position.set(1.6, 1.4, -2.9); SPACE.add(hole);
  HATCH.position.set(1.6 - 1.35, 1.4, -2.75); SPACE.add(HATCH); const hd = P(HATCH, new THREE.CylinderGeometry(1.3, 1.3, 0.18, 40), hull, 1.35, 0, 0); hd.rotation.x = PI / 2;
  P(HATCH, rbox(0.5, 0.12, 0.12, 0.04, 1), dark, 1.35, 0, 0.14);
  const ea = new THREE.Mesh(new THREE.SphereGeometry(90, 64, 40), new THREE.MeshStandardMaterial({ color: 0x2f6fd0, roughness: 0.7, fog: false })); ea.position.set(-10, -112, -70); SPACE.add(ea);
  [[0.35, 0.5, 26], [-0.2, 0.55, 20], [0.1, 0.38, 16], [-0.45, 0.42, 14]].forEach(([a, b, r]) => { const l = new THREE.Mesh(new THREE.SphereGeometry(r, 24, 16), new THREE.MeshStandardMaterial({ color: 0x4f9a52, roughness: 0.9, fog: false }));
    const d = new THREE.Vector3(Math.sin(a), Math.cos(a) * Math.cos(b), Math.cos(a) * Math.sin(b)).normalize(); l.position.copy(ea.position).addScaledVector(d, 90 - r * 0.28); l.scale.set(1, 0.35, 1); l.lookAt(ea.position); l.rotateX(PI / 2); SPACE.add(l); });
})();
function hatch(open){ HATCH.rotation.y = -1.9 * open; }

/* =========================================================
   BEN
   ========================================================= */
const SCAR = new THREE.Group(); ben.head.add(SCAR);
(function(){ const m = mat(0xa8463f, { roughness: 0.7 }); const s = new THREE.Mesh(rbox(0.075, 0.72, 0.03, 0.012, 1), m); s.position.set(0.25, 0.55, 0.522); s.rotation.z = -0.13; SCAR.add(s);
  for (const y of [0.36, 0.55, 0.74]){ const c = new THREE.Mesh(rbox(0.16, 0.035, 0.03, 0.01, 1), m); c.position.set(0.25 + (y - 0.55) * 0.13, y, 0.528); c.rotation.z = -0.13; SCAR.add(c); } })();
function floatPose(r, t, w){ w = w === undefined ? 1 : w; const a = Math.sin(t * 1.3), b = Math.sin(t * 1.1 + 1);
  r.sh[0].rotation.set(0.25 * a * w, 0, -0.75 - 0.15 * b * w); r.sh[1].rotation.set(-0.25 * a * w, 0, 0.75 + 0.15 * b * w); r.el[0].rotation.set(-0.35, 0, 0); r.el[1].rotation.set(-0.35, 0, 0);
  r.legs[0].rotation.set(0.2 * b * w, 0, -0.12); r.legs[1].rotation.set(-0.2 * b * w, 0, 0.12); r.torso.rotation.x = 0.04 * a; }

/* =========================================================
   KAMERA + Zustand
   ========================================================= */
const cL = new THREE.Vector3();
let blurAmt = 0, fadeBlk = 0, T = 0, flashA = 0, eyeS = 1, talk = 0, dT = 0;
let skinK = 0, boilK = 0, lungK = 0, timK = 0, saveK = 0, tethK = 0, puffT = -9;
function camW(p, a, b){ cam.position.set(lerp(a[0], b[0], p), lerp(a[1], b[1], p), lerp(a[2], b[2], p)); cL.set(lerp(a[3], b[3], p), lerp(a[4], b[4], p), lerp(a[5], b[5], p)); cam.fov = lerp(a[6], b[6], p); }
function camFin(sh){ cam.position.x += Math.sin(dT * 0.7) * 0.015; cam.position.y += Math.sin(dT * 0.9 + 1) * 0.012; if (sh){ cam.position.x += Math.sin(T * 23) * sh; cam.position.y += Math.cos(T * 17) * sh; } cam.up.set(0, 1, 0); cam.lookAt(cL); cam.updateProjectionMatrix(); cam.updateMatrixWorld(); }
const HOOK = [[5.0, 2.9, 15.5, 1.3, 2.6, -1, 40], [4.4, 2.8, 14.2, 1.3, 2.5, -1, 40]];
function base(){ show(ben); ben.root.scale.set(1, 1, 1); ben.head.scale.set(1, 1, 1); hatch(1); }
// z-Position vor der Schleuse: t<0 kommt Ben heraus, t>0 treibt er nach vorn
function bz(t){ return t < 0 ? -3.6 + 2.0 * E.io(seg(t, -2.9, -0.2)) : -1.6 + 2.4 * E.io(seg(t, 0, 3.2)); }
function benAt(t, z){ bRest(ben, t, 0); place(ben, 1.6, -0.35 + 0.1 * Math.sin(t * 1.2), z, 0.2 * Math.sin(t * 0.5)); ben.root.rotation.z = 0.12 * Math.sin(t * 0.8); floatPose(ben, t); }
function hookBen(t){ benAt(t, bz(t)); eyeS = 1.3; bFace(ben, -0.7, 0.3); }

/* =========================================================
   SZENEN (Sprecherspur Tempo 1,05)
   ========================================================= */
const SCN = [
  { t: 0, set: SPACE, mood: MOOD.space, hook: 1,
    upd(lt){ dT = T; base(); hookBen(T); camW(E.io(seg(lt, 0, 3.07)), HOOK[0], HOOK[1]); camFin(); } },
  { t: 3.07, set: SPACE, mood: MOOD.space, hud: () => ['PLATZT ER?', 'NEIN – DIE HAUT HÄLT'],
    upd(lt){ dT = T; base(); benAt(T, bz(T)); eyeS = 1.2; bFace(ben, -0.4, 0.15); skinK = E.out(seg(T, 3.3, 3.6)) * (1 - seg(T, 6.0, 6.21));
      camW(E.io(seg(lt, 0, 3.14)), HOOK[1], [3.0, 2.2, 12.5, 1.5, 1.7, 0, 40]); camFin(); } },
  { t: 6.21, set: SPACE, mood: MOOD.space, hud: () => T < 7.4 ? ['ER SCHWILLT AN', 'BIS ZU DOPPELT SO DICK'] : ['SPUCKE KOCHT', 'KOCHT SCHON BEI 37 °C'],
    upd(lt){ dT = T; base(); benAt(T, bz(T)); const sw = E.io(seg(T, 6.3, 7.3)); ben.root.scale.set(1 + 0.1 * sw, 1 + 0.04 * sw, 1 + 0.12 * sw); ben.head.scale.set(1 + 0.08 * sw, 1 + 0.04 * sw, 1 + 0.08 * sw);
      eyeS = 1.3; bFace(ben, -0.6, 0.45 * seg(T, 7.6, 8.0)); boilK = E.out(seg(T, 7.7, 8.0)) * (1 - seg(T, 9.85, 10.06));
      camW(E.io(seg(lt, 0, 3.85)), [3.0, 2.2, 12.5, 1.5, 1.7, 0, 40], [2.3, 3.4, 8.2, 1.6, 2.7, 0, 40]); camFin(); } },
  { t: 10.06, set: SPACE, mood: MOOD.space, hud: () => ['LUFT ANHALTEN?', 'BLOSS NICHT!'],
    upd(lt){ dT = T; base(); benAt(T, bz(T)); ben.root.scale.set(1.1, 1.04, 1.12); const pf = bump(T, 10.1, 11.4); ben.head.scale.set(1.08 + 0.16 * pf, 1.04, 1.08 + 0.1 * pf);
      eyeS = 1.2 - 0.5 * pf; bFace(ben, -0.8 * pf, pf > 0.2 ? 0 : 0.5 * seg(T, 11.4, 11.6)); lungK = E.out(seg(T, 10.9, 11.2)) * (1 - seg(T, 12.7, 12.93));
      camW(E.io(seg(lt, 0, 2.87)), [2.3, 3.4, 8.2, 1.6, 2.7, 0, 40], [2.6, 3.2, 9.6, 1.6, 2.5, 0, 40]); camFin(); } },
  { t: 12.93, set: SPACE, mood: MOOD.space, hud: () => ['NACH CA. 15 SEKUNDEN', 'BEWUSSTLOS'],
    upd(lt){ dT = T; base(); benAt(T, bz(T)); const lp = E.io(seg(T, 14.6, 15.4)); ben.root.scale.set(1.1, 1.04, 1.12); ben.head.scale.set(1.08, 1.04, 1.08);
      ben.sh[0].rotation.z = lerp(ben.sh[0].rotation.z, -0.35, lp); ben.sh[1].rotation.z = lerp(ben.sh[1].rotation.z, 0.35, lp); ben.head.rotation.x = 0.35 * lp; ben.head.rotation.z = 0.25 * lp; ben.root.rotation.z += 0.35 * lp;
      eyeS = lerp(1.0, 0.1, lp); bFace(ben, 0.2 * lp, 0.25); timK = E.out(seg(T, 13.0, 13.3)) * (1 - seg(T, 15.4, 15.6));
      camW(E.io(seg(lt, 0, 2.67)), [2.6, 3.2, 9.6, 1.6, 2.5, 0, 40], [3.6, 2.6, 12.0, 1.6, 1.8, 0, 40]); camFin(); } },
  { t: 15.6, set: SPACE, mood: MOOD.space, hud: () => T < 18.6 ? ['ZURÜCK IN UNTER 90 S', 'DANN KANN ER ÜBERLEBEN'] : ['GERETTET', 'DRUCK IST WIEDER DA'],
    upd(lt){ dT = T; base(); const pl = E.io(seg(T, 15.9, 18.3)), z0 = bz(15.6), z = lerp(z0, -4.4, pl); benAt(T, z); ben.root.scale.set(1.1 - 0.1 * seg(T, 18.6, 19.2), 1.04 - 0.04 * seg(T, 18.6, 19.2), 1.12 - 0.12 * seg(T, 18.6, 19.2));
      ben.sh[0].rotation.z = -0.35; ben.sh[1].rotation.z = 0.35; ben.head.rotation.x = 0.35; ben.root.rotation.z += 0.35; eyeS = 0.1; bFace(ben, 0.2, 0.25);
      hatch(1 - E.io(seg(T, 18.5, 19.1))); tethK = 1 - seg(T, 18.0, 18.4); saveK = E.out(seg(T, 15.8, 16.1)) * (1 - seg(T, 19.1, 19.28));
      camW(E.io(seg(lt, 0, 3.68)), [3.6, 2.6, 12.0, 1.6, 1.8, 0, 40], [5.4, 3.0, 15.0, 1.4, 1.6, -2, 40]); camFin(); } },
  { t: 19.28, set: SPACE, mood: MOOD.space, hud: () => ['UND BEN?', 'NÄCHSTE LUFTSCHLEUSE …'],
    upd(lt){ dT = T - END; base(); hatch(E.io(seg(T, 19.4, 19.9))); hookBen(T - END); camW(E.io(seg(T, 19.28, 21.8)), [5.4, 3.0, 15.0, 1.4, 1.6, -2, 40], HOOK[0]); camFin(); } },
  { t: 22.1, set: SPACE, mood: MOOD.space, loopin: 1,
    upd(lt){ dT = T - END; base(); hookBen(T - END); camW(0, HOOK[0], HOOK[1]); camFin(); } },
];
const SUBS = __SUBS__;
