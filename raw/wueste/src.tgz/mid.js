/* =========================================================
   STIMMUNG: Wüste (Tag) + Wüstennacht
   ========================================================= */
function sky(a, b, c, stars){
  const cv = document.createElement('canvas'); cv.width = 512; cv.height = 512; const x = cv.getContext('2d'), g = x.createLinearGradient(0, 0, 0, 512);
  g.addColorStop(0, a); g.addColorStop(0.6, b); g.addColorStop(1, c); x.fillStyle = g; x.fillRect(0, 0, 512, 512);
  if (stars){ let sd = 3; const r = () => { sd = (sd * 16807) % 2147483647; return sd / 2147483647; }; for (let i = 0; i < 260; i++){ x.fillStyle = 'rgba(255,255,255,' + (0.4 + 0.6 * r()) + ')'; const s = r() < 0.1 ? 2 : 1; x.fillRect(r() * 512, r() * 300, s, s); } }
  const t = new THREE.CanvasTexture(cv); t.encoding = THREE.sRGBEncoding; return t;
}
const MOOD = {
  day: { sky: sky('#4a8ed8', '#a8d0ee', '#f4e6c8'), fog: [0xf0dcb4, 60, 260], hemi: [0xfff4e0, 0xc8a070, 0.9], sun: [0xfff0d0, 1.6], sp: [12, 20, 8], fl: 0.3 },
  night: { sky: sky('#050a1e', '#0e1a3e', '#1e2a50', true), fog: [0x141e3a, 40, 200], hemi: [0x6a80c0, 0x2a2a40, 0.55], sun: [0xa8c0ff, 0.6], sp: [-8, 16, 6], fl: 0.15 },
};
MOOD.shade = Object.assign({}, MOOD.day, { sp: [-12, 14, -6], hemi: [0xfff4e0, 0xc8a070, 0.8] });
const SR = 12; { const c = sun.shadow.camera; c.left = -SR; c.right = SR; c.top = SR; c.bottom = -SR; c.near = 1; c.far = 70; c.updateProjectionMatrix(); }
function setMood(m){
  scene.background = m.sky; scene.fog.color.set(m.fog[0]); scene.fog.near = m.fog[1]; scene.fog.far = m.fog[2]; scene.environment = envDay || envNight;
  hemi.color.set(m.hemi[0]); hemi.groundColor.set(m.hemi[1]); hemi.intensity = m.hemi[2]; sun.color.set(m.sun[0]); sun.intensity = m.sun[1];
  sun.position.set(m.sp[0], m.sp[1], m.sp[2]); sun.target.position.set(0, 0, 0); fill.color.set(0xffffff); fill.intensity = m.fl; fill.position.set(-5, 6, 10);
}

/* =========================================================
   SET: Dünen, Felsen, Kaktus
   ========================================================= */
const DES = new THREE.Group(); scene.add(DES); const SETS = [DES];
(function(){ const sm = mat(0xe4c28c, { roughness: 1 });
  const gr = new THREE.Mesh(new THREE.PlaneGeometry(600, 600), sm); gr.rotation.x = -PI / 2; gr.receiveShadow = true; DES.add(gr);
  [[-18, -30, 14, 4], [10, -38, 18, 5], [30, -20, 12, 3.5], [-35, -12, 12, 3], [0, -60, 30, 7], [22, 10, 10, 2.5], [-24, 12, 9, 2.2]].forEach(([x, z, r, h]) => { const d = new THREE.Mesh(new THREE.SphereGeometry(1, 32, 16), sm); d.scale.set(r, h, r * 0.7); d.position.set(x, 0, z); d.receiveShadow = true; DES.add(d); });
  const rk = mat(0xa8603a, { roughness: 1, flatShading: true });
  P(DES, new THREE.DodecahedronGeometry(2.6, 0), rk, -3.2, 1.6, -2.4).scale.set(1.2, 1.1, 1); P(DES, new THREE.DodecahedronGeometry(1.2, 0), rk, -1.4, 0.6, -3.2);
  P(DES, new THREE.DodecahedronGeometry(0.6, 0), rk, 5, 0.3, 2); P(DES, new THREE.DodecahedronGeometry(0.8, 0), rk, -6, 0.4, 3);
  // Kaktus bei (3.6, 0, -1.2)
  const cm = mat(0x4a8a46, { roughness: 0.8 }); const C = new THREE.Group(); C.position.set(3.6, 0, -1.2); DES.add(C);
  P(C, new THREE.CylinderGeometry(0.42, 0.48, 4.2, 12), cm, 0, 2.1, 0); P(C, new THREE.SphereGeometry(0.42, 12, 8), cm, 0, 4.2, 0);
  P(C, new THREE.CylinderGeometry(0.28, 0.28, 1.0, 10), cm, -0.75, 1.9, 0).rotation.z = PI / 2; P(C, new THREE.CylinderGeometry(0.28, 0.28, 1.4, 10), cm, -1.2, 2.5, 0); P(C, new THREE.SphereGeometry(0.28, 10, 8), cm, -1.2, 3.2, 0);
  P(C, new THREE.CylinderGeometry(0.26, 0.26, 0.9, 10), cm, 0.7, 2.5, 0).rotation.z = PI / 2; P(C, new THREE.CylinderGeometry(0.26, 0.26, 1.2, 10), cm, 1.1, 3.0, 0); P(C, new THREE.SphereGeometry(0.26, 10, 8), cm, 1.1, 3.6, 0);
})();
// Requisiten an Ben: leere Flasche (rechte Hand), große Wasserflasche, Rucksack
const EMPTY = new THREE.Group(), FULL = new THREE.Group(), PACK = new THREE.Group(), SWEAT = [];
(function(){ ben.el[1].add(EMPTY); EMPTY.position.set(0, -0.72, 0.1);
  const gm = new THREE.MeshStandardMaterial({ color: 0xd8eef8, roughness: 0.1, transparent: true, opacity: 0.45, depthWrite: false });
  P(EMPTY, new THREE.CylinderGeometry(0.13, 0.13, 0.55, 12), gm, 0, 0, 0); P(EMPTY, new THREE.CylinderGeometry(0.06, 0.06, 0.12, 8), mat(0x2a6ab0), 0, 0.33, 0);
  ben.el[0].add(FULL); FULL.position.set(0, -0.72, 0.12);
  P(FULL, new THREE.CylinderGeometry(0.17, 0.17, 0.75, 14), new THREE.MeshStandardMaterial({ color: 0x4aa8e8, roughness: 0.15, transparent: true, opacity: 0.85 }), 0, 0, 0); P(FULL, new THREE.CylinderGeometry(0.08, 0.08, 0.14, 8), mat(0x1a4a8a), 0, 0.44, 0);
  ben.torso.add(PACK); P(PACK, rbox(0.85, 0.95, 0.4, 0.1), mat(0x3a6a4a, { roughness: 0.9 }), 0, 0.55, -0.48);
  const dm = new THREE.MeshStandardMaterial({ color: 0xa8dcff, roughness: 0.05, transparent: true, opacity: 0.85 });
  for (let i = 0; i < 3; i++){ const d = new THREE.Mesh(new THREE.SphereGeometry(0.055, 10, 8), dm); ben.head.add(d); SWEAT.push(d); }
})();
function sweat(k){ SWEAT.forEach((d, i) => { const ph = (dT * 0.7 + i / 3) % 1; d.visible = k > 0.01; d.scale.setScalar(Math.max(0.01, k * Math.sin(PI * ph))); d.position.set([-0.38, 0.4, 0.05][i], 0.95 - ph * 0.55, [0.35, 0.3, 0.52][i]); }); }

/* =========================================================
   BEN
   ========================================================= */
const SCAR = new THREE.Group(); ben.head.add(SCAR);
(function(){ const m = mat(0xa8463f, { roughness: 0.7 }); const s = new THREE.Mesh(rbox(0.075, 0.72, 0.03, 0.012, 1), m); s.position.set(0.25, 0.55, 0.522); s.rotation.z = -0.13; SCAR.add(s);
  for (const y of [0.36, 0.55, 0.74]){ const c = new THREE.Mesh(rbox(0.16, 0.035, 0.03, 0.01, 1), m); c.position.set(0.25 + (y - 0.55) * 0.13, y, 0.528); c.rotation.z = -0.13; SCAR.add(c); } })();
// Hook: schüttelt die leere Flasche über dem Kopf
function bottleBen(t){ bRest(ben, t, 0); place(ben, 0, 0, 0, 0.15); EMPTY.visible = true; ben.sh[1].rotation.set(-2.7, 0, 0.15); ben.el[1].rotation.x = -0.2 + 0.25 * Math.sin(t * 11); EMPTY.rotation.x = PI;
  ben.head.rotation.x = -0.35; ben.sh[0].rotation.set(0, 0, -0.25); eyeS = 0.85; bFace(ben, -0.8, 0.35); sweat(0.8); }

/* =========================================================
   KAMERA + Zustand
   ========================================================= */
const cL = new THREE.Vector3();
let blurAmt = 0, fadeBlk = 0, T = 0, flashA = 0, eyeS = 1, talk = 0, dT = 0;
let swK = 0, pfK = 0, ctK = 0, shK = 0, warmK = 0;
function camW(p, a, b){ cam.position.set(lerp(a[0], b[0], p), lerp(a[1], b[1], p), lerp(a[2], b[2], p)); cL.set(lerp(a[3], b[3], p), lerp(a[4], b[4], p), lerp(a[5], b[5], p)); cam.fov = lerp(a[6], b[6], p); }
function camFin(sh){ cam.position.x += Math.sin(dT * 0.7) * 0.02; cam.position.y += Math.sin(dT * 0.9 + 1) * 0.015; if (sh){ cam.position.x += Math.sin(T * 23) * sh; cam.position.y += Math.cos(T * 17) * sh; } cam.up.set(0, 1, 0); cam.lookAt(cL); cam.updateProjectionMatrix(); cam.updateMatrixWorld(); }
const HOOK = [[1.2, 3.2, 8.5, 0, 3.3, 0, 50], [1.0, 3.1, 7.6, 0, 3.3, 0, 50]];
function base(){ show(ben); EMPTY.visible = false; FULL.visible = false; EMPTY.rotation.x = 0; }
function hookBen(t){ bottleBen(t); }

/* =========================================================
   SZENEN (Sprecherspur Tempo 1,0)
   ========================================================= */
const SCN = [
  { t: 0, set: DES, mood: MOOD.day, hook: 1,
    upd(lt){ dT = T; base(); warmK = 0.35; hookBen(T); camW(E.io(seg(lt, 0, 4.08)), HOOK[0], HOOK[1]); camFin(); } },
  { t: 4.08, set: DES, mood: MOOD.day, hud: () => ['ÜBER 40 °C', 'SCHWITZEN OHNE ENDE'],
    upd(lt){ dT = T; base(); warmK = 0.4; bRest(ben, T, 0); place(ben, lerp(-3, 0.5, seg(T, 4.08, 8.08)), 0, 1.0, PI / 2); wlk(ben, T * 8, 0.8); ben.head.rotation.x = 0.15; eyeS = 0.7; bFace(ben, -0.6, 0.3); sweat(1);
      swK = E.out(seg(T, 4.3, 4.6)) * (1 - seg(T, 7.9, 8.08)); camW(E.io(seg(lt, 0, 4.0)), [-2.6, 3.0, 11.5, -1.6, 2.9, 1.0, 48], [1.8, 3.0, 11.0, 0.4, 2.9, 1.0, 48]); camFin(); } },
  { t: 8.08, set: DES, mood: MOOD.day, hud: () => ['2 % WASSERVERLUST', 'LEISTUNG SINKT'],
    upd(lt){ dT = T; base(); warmK = 0.5; bRest(ben, T, 0); const sl = seg(T, 8.1, 12.4); place(ben, lerp(0.5, 1.9, sl), 0, lerp(1.0, 0.2, sl), PI / 2 - 0.3); wlk(ben, T * 5, 0.5); ben.torso.rotation.x = 0.35; ben.head.rotation.x = 0.35;
      ben.root.rotation.z = 0.08 * Math.sin(T * 2.5); eyeS = 0.45; bFace(ben, -0.5, 0.45); sweat(1); pfK = E.out(seg(T, 8.3, 8.6)) * (1 - seg(T, 12.25, 12.42));
      camW(E.io(seg(lt, 0, 4.34)), [8.0, 3.2, 9.0, 1.0, 2.7, 0.6, 46], [7.4, 3.1, 8.3, 1.6, 2.6, 0.3, 46]); camFin(); } },
  { t: 12.42, set: DES, mood: MOOD.day, hud: () => ['KAKTUS ANZAPFEN?', 'MEIST UNGENIESSBAR'],
    upd(lt){ dT = T; base(); warmK = 0.5; bRest(ben, T, 0); const bk = E.io(seg(T, 14.0, 14.5)); place(ben, lerp(1.9, 1.5, bk), 0, -0.9, PI / 2);
      const pk = bump(T, 12.9, 13.8); ben.sh[1].rotation.set(-1.6 * (pk > 0 ? 1 : 0.2) - 0.1 * pk, 0, 0.1); ben.el[1].rotation.x = -0.2;
      eyeS = lerp(1.0, 0.5, bk); bFace(ben, lerp(0.2, -1, bk), lerp(0.1, 0.5, bk)); ben.head.rotation.y = 0.4 * bk; ben.torso.rotation.x = -0.15 * bk; sweat(0.8);
      ctK = E.out(seg(T, 12.6, 12.9)) * (1 - seg(T, 16.5, 16.7)); camW(E.io(seg(lt, 0, 4.28)), [5.4, 3.3, 8.0, 2.6, 3.0, -1.0, 50], [5.0, 3.2, 7.3, 2.6, 2.9, -1.0, 50]); camFin(); } },
  { t: 16.7, set: DES, mood: MOOD.shade, hud: () => ['BESSER:', 'TAGS SCHATTEN, NACHTS LAUFEN'],
    upd(lt){ dT = T; base(); warmK = 0.2; bRest(ben, T, 0); place(ben, 0.7, 0, -1.4, 0.3); sit(ben, 0.05); ben.legs[0].rotation.x = -1.4; ben.legs[1].rotation.x = -1.4; ben.sh[0].rotation.set(-0.6, 0, -0.2); ben.sh[1].rotation.set(-0.6, 0, 0.2);
      eyeS = 0.9; bFace(ben, 0.2, 0.1); sweat(0.3); shK = E.out(seg(T, 16.9, 17.2));
      camW(E.io(seg(lt, 0, 2.14)), [3.6, 2.6, 6.2, -0.4, 1.9, -1.6, 50], [3.2, 2.5, 5.6, -0.4, 1.9, -1.6, 50]); camFin(); } },
  { t: 18.84, set: DES, mood: MOOD.night, hud: () => ['BESSER:', 'TAGS SCHATTEN, NACHTS LAUFEN'],
    upd(lt){ dT = T; base(); warmK = 0; bRest(ben, T, 0); place(ben, lerp(-1, 2.5, seg(T, 18.84, 20.72)), 0, 1.0, PI / 2); wlk(ben, T * 10, 1); eyeS = 1; bFace(ben, 0.4, 0.1);
      sweat(0); shK = 1 - seg(T, 20.55, 20.72); camW(E.io(seg(lt, 0, 1.88)), [-1.0, 2.3, 8.0, 0.2, 2.8, 1.0, 50], [1.6, 2.3, 7.6, 1.4, 2.8, 1.0, 50]); camFin(); } },
  { t: 20.72, set: DES, mood: MOOD.day, hud: () => ['UND BEN?', 'HAT GENUG WASSER DABEI'],
    upd(lt){ dT = T; base(); warmK = 0.2; bRest(ben, T, 0); place(ben, 0, 0, 0, 0.15); FULL.visible = true; const dr = E.io(seg(T, 21.6, 22.0));
      ben.sh[0].rotation.set(lerp(-0.9, -2.5, dr), 0, lerp(-0.2, -0.1, dr)); ben.el[0].rotation.x = lerp(-0.8, -0.9, dr); FULL.rotation.x = lerp(0, -1.6, dr); ben.head.rotation.x = -0.3 * dr;
      ben.sh[1].rotation.set(0, 0, 0.5); eyeS = lerp(1.1, 0.25, dr); bFace(ben, 0.8, lerp(0.15, 0.1, dr)); sweat(0);
      camW(E.io(seg(lt, 0, 2.73)), [1.6, 3.0, 8.0, 0, 3.0, 0, 48], [1.2, 3.0, 7.0, 0, 3.0, 0, 48]); camFin(); } },
  { t: 23.45, set: DES, mood: MOOD.day, loopin: 1,
    upd(lt){ dT = T - END; base(); warmK = 0.35; hookBen(T - END); camW(0, HOOK[0], HOOK[1]); camFin(); } },
];
const SUBS = __SUBS__;
